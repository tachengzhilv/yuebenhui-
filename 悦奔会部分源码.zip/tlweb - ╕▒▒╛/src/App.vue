<template>
  <div id="app">

    <router-view></router-view>

  </div>
</template>

<script>
  import appHeader from  './views/shopCenter/CommonHeader/appheader'
  import appLeft from  './views/shopCenter/CommonLeft/navLeft'
  export default {
    name: 'App',
    components:{
      appHeader,
      appLeft
    },
    watch:{
      '$route':'getPath'
    },
    methods: {
      getPath(){
        console.log(this.$route.path);
        if(this.$route.path == '/ClientIndex'){
          sessionStorage.removeItem('getVal')
        }
      }
    }
  }
</script>

<style scoped>
  .el-header{
    padding: 0;
  }
</style>

<template>
  <div class="authCode">
    <el-button style="margin-left: 11px"  v-show="sendAuthCode" @click="getAuthCode(mobile)" >发送验证码</el-button>
    <el-button style="margin-left: 11px"  v-show="!sendAuthCode" >剩余{{auth_time}}秒后</el-button>
  </div>
</template>

<script>
  export default {
      name: "authCode",
      props:['mobile'],
      data() {
        return {
          sendAuthCode: true,
          auth_time: 0
        }
      },
    methods:{
    // 发送验证码的
      async getAuthCode(mobile){
        let that = this
        let send = await that.$http.post('/common/smsSend',{
          mobile: mobile
        }).then(function (res) {
            console.log(res)
            if (res.code == 1) {
              that.sendAuthCode = false;
              that.auth_time = 60;
                var auth_timetimer =  setInterval(()=>{
                  that.auth_time--;
                  if(that.auth_time<=0){
                    that.sendAuthCode = true;
                    clearInterval(auth_timetimer);
                  }
                }, 1000);
            }else {
              that.$message({
                message:res.data.message,
                duration:1500,
                type: 'error'
              })
            }
          })
        }
      }
    }
</script>

<style scoped>
.authCode{
  position: absolute;
  right: 38px;
  top: 0px;
}
.el-input  {
  width: 90%;
}
</style>

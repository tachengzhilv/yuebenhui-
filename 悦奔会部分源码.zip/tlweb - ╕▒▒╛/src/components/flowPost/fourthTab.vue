<template>
    <div>
      <h3>发布使用</h3>
      <div style="marign-top:30px">
        <ul class="uls">
          <li @click="firstTab">第一步</li>
          <li @click="secondTab">第二步</li>
          <li @click="thirdTab">第三步</li>
          <li class="activit">第四步</li>
          <li>第五步</li>
        </ul>
      </div>
      <div class="firstTab">
        <p class="labelTip">增值服务</p>
        <div class="firstShop">
             <el-checkbox-group v-model="checkList" @change="checkLists">
               <p><el-checkbox  v-for="(item,index) in arrLIst" :key="index" :label="item.id" >{{item.name}}:{{item.integral}}{{item.rule}} </el-checkbox></p>
             </el-checkbox-group>
            <div class="shopAbs">
              <p class="ShopTime">
                <span>每间隔</span><el-input v-model="time"  class="times"></el-input>小时，通过<el-input v-model="num" class="times"></el-input>份
              </p>
              <p class="ShopTime">
                <span>人群选择:</span>
                <el-select class="sex" v-model="sexs">
                  <el-option  v-for="(item,index) in sexList" :key="index" :label="item.element_value" :value="item.id"></el-option>
                </el-select>
                <el-select class="age"  v-model="ages">
                  <el-option  v-for="(item,index) in ageList" :key="index" :label="item.element_value" :value="item.id"></el-option>
                </el-select>
                <el-select class="role" placeholder="角色随机"  v-model="roles">
                  <el-option  v-for="(item,index) in roleList" :key="index" :label="item.names" :value="item.ids"></el-option>
                </el-select>
              </p>
            </div>
            <el-input v-model="keyWords" class="keyWords" v-if="isFalse == true" placeholder = '请输入打标关键字'></el-input>
          <div class="btn">
            <img src="./../../assets/webIndex/next.png" @click="next" v-if="isShow"/>
            <img src="./../../assets/webIndex/nextDisabled.png" v-else/>
          </div>
        </div>
      </div>
    </div>
</template>

<script>
    export default {
        name: "fourthTab",
        data() {
            return {
              radio: '1',
              time: '',
              num:'',
              classSpc: '',
              spcRecom: '',
              isShow: true,
              arrLIst:[],
              checkList: [],
              sexList:[],
              ageList:[],
              roleList: [],
              sexs:'',
              ages:'',
              roles:'',
              ids: '',
              spcId:'',
              mun: '',
              jifeng: [],
              someNum:'',
              arrCheck:[],
              keyWords:'',
              isFalse: true
            }
        },
        mounted(){
          this.serviceList()
          this.sex()
          this.age()
          this.role()
          if (sessionStorage.getItem('sessionFourth')) {
            let sessions = JSON.parse(sessionStorage.getItem('sessionFourth'))
            this.checkList = sessions
          }
          let sessionFourth =  JSON.parse(sessionStorage.getItem('objFourth'))
          this.time = sessionFourth.time
          this.num = sessionFourth.num
          this.sexs = sessionFourth.sexs
          this.ages = sessionFourth.ages
          this.roles = sessionFourth.roles
          if (sessionStorage.getItem('FourthkeyWords')){
            this.keyWords  = sessionStorage.getItem('FourthkeyWords')
          }

        },
        methods: {
          firstTab(){
            this.$router.push({path:'/firstTab'})
          },
          secondTab(){
            this.$router.push({path:'/secondTab'})
          },
          thirdTab(){
            this.$router.push({path:'/thirdTab'})
          },
          serviceList(){
            this.$http.post('/merchant/terrace/serviceNumber',{}).then(res=>{
              if (res.code == 1) {
                console.log(res)
                this.arrLIst = res.datas
                this.ids = this.arrLIst[0].id
                this.mun = this.arrLIst[0].integral
              }
            })
          },
          // 性别
          sex(){
            this.$http.post('/common/getCacheEnums',{
              key:'sex'
            }).then(res=>{
              if (res.code == 1) {
                this.sexList = res.datas
                console.log(res.datas)
              }
            })
          },

          // 年龄
          age(){
            this.$http.post('/common/getCacheEnums',{
              key:'age_id'
            }).then(res=>{
              if (res.code == 1) {
                this.ageList = res.datas
                console.log(res.datas)
              }
            })
          },
          //角色
          role(){
            this.$http.post('/merchant/terrace/roleMeter').then(res=>{
              if (res.code == 1) {
                this.roleList = res.datas
                console.log(res.datas)
              }
            })
          },
          checkLists (){
            console.log(this.checkList)
            this.arrCheck = this.checkList
            sessionStorage.setItem('sessionFourth',JSON.stringify(this.arrCheck))
            // 获取增值积分
            let nums = []
            let totalOne
            let total
            let totalTwo
            for (let i=0 ; i<this.arrLIst.length;i++){
              for (let j=0;j<this.checkList.length;j++) {
                if (this.checkList[j] == this.arrLIst[i].id){
                  let objSecond = JSON.parse(sessionStorage.getItem('objSecond'));
                  let data =objSecond.date
                  let secondNum =objSecond.num;
                  this.jifeng=[]
                  if (this.ages !== ''){
                    this.jifeng.push(this.ages)

                  }
                  if (this.sexs !== '') {
                    this.jifeng.push(this.sexs)
                  }
                  if (this.roles !== '') {
                    this.jifeng.push(this.roles)
                  }
                  if ( this.ids  == this.arrLIst[i].id){
                    totalOne = this.mun*secondNum*this.jifeng.length;
                     nums.push(totalOne)

                  }
                  if (this.arrLIst[i].rule.indexOf('/份')!=-1) {
                    total = this.arrLIst[i].integral * secondNum;
                    nums.push(total)

                  }
                  if (this.arrLIst[i].rule.indexOf('/天')!=-1){
                    totalTwo = this.arrLIst[i].integral*data
                    nums.push(totalTwo)
                  }

                  this.someNum = nums.reduce(this.getSum)
                  console.log( this.someNum)
                }else {
                }
              }
            }
          },
          next(){
            for (let i=0 ;i < this.checkList.length; i++) {

              if (this.checkList.length == 0) {
                this.$message.error('请选择增值服务')
              }
              if (this.checkList[i] == 3) {
                if (this.keyWords == '') {
                  this.$message.error('请填写打标关键字')
                  this.$router.push({path:'./fourthTab'})
                }else if (this.keyWords != '') {
                   sessionStorage.setItem('FourthkeyWords', this.keyWords)
                }
              }else {
                sessionStorage.setItem('FourthkeyWords','')
              }
              // 判断是否选了第一个
              if(this.checkList[i] == this.ids){
                if (this.time == '' && this.num == '' ) {
                  this.$message.error('数据填写不完整')
                }else if (this.ages == '' && this.sexs == '' && this.roles == '' ) {
                  this.$message.error('人群范围请选择一个')
                }else{
                  this.checkLists ()
                   console.log(this.ages)
                  let objFourth = {
                    time: this.time,
                    num: this.num,
                    sexs: this.sexs,
                    ages: this.ages,
                    roles: this.roles
                  }
                  sessionStorage.setItem('objFourth',JSON.stringify(objFourth))
                  sessionStorage.setItem('total',this.someNum)
                  let obj = {orderServiceEven:this.arrCheck}
                  sessionStorage.setItem('objFourths' ,JSON.stringify(obj))
                  this.$router.push({path:'./fifthTab'})
                }
              }
            }

          },
          getSum(total, num) {
            return total + num;
          }
        }

    }
</script>

<style scoped>
  .uls{
    width: 98%;
    border-bottom: 1px solid #dddddd;
    margin-top: 10px;
  }
  .uls li{
    width: 78px;
    height: 36px;
    line-height: 36px;
    border-radius: 5px 5px 0px 0px;
    display: inline-block;
    margin-left: 11px;
    background: #f2f2f2;
    text-align: center;
    cursor: pointer;
  }
  .activit{
    background: #f28b1d !important;
    color: #fff;
  }
 .ShopTime,auto{
   color: #666666;
   font-size: 16px;
   margin-top: 24px;
   height: 40px;
   line-height: 40px;
 }
.times{
  width: 60px;
  height: 40px;
  margin: 0 5px 0 5px;
}
.btn{
  display: flex;
  justify-content: center;
  margin: 280px auto;
  margin-bottom: 0;
}
.btn img{
  margin-left: 50px;
}
.sex,.age,.role{
  width: 100px;
  height: 40px;
}
.firstShop .el-checkbox-group{
  height: 40px;
  line-height: 40px;
}
.firstShop .el-checkbox:nth-of-type(1){
  height: 180px;
}
.firstShop{
  position: relative;
}
.firstShop .el-checkbox{
  display: block;
}
.shopAbs{
  position: absolute;
  top: 25px;
}
.keyWords{
  width: 200px;
  position: absolute;
  left: 222px;
  top: 179px;
}
</style>

<template>
    <div>
      <h3>发布试用</h3>
      <div style="margin-top: 30px">
        <ul class="uls">
          <li @click="firstTab">第一步</li>
          <li @click="secondTab">第二步</li>
          <li class="activit">第三步</li>
          <li>第四步</li>
          <li>第五步</li>
        </ul>
      </div>
      <div class="firstTab" >
        <p class="labelTip">下单入口</p>
        <div class="firstShop">
          <el-form :model="ruleForm" :rules="rules" ref="ruleForm"  label-width="120px">
            <el-form-item label="下单类型:" prop="orderStyle">
              <el-radio-group v-model="ruleForm.orderStyle" @change="radioChange">
                <el-radio v-for="item in radiosArr" :key="item.id" :label="item.id" >{{item.element_value}}</el-radio>
              </el-radio-group>
            </el-form-item>
            <el-form-item label="结果提示图:" prop="imageUrl" class="imgOne">
              <el-upload
                class="avatar-uploader"
                action="http://upload-z2.qiniup.com"
                :data="qn"
                :show-file-list="false"
                :on-success="handleAvatarSuccess"
                :before-upload="beforeAvatarUpload">
                <img v-if="ruleForm.imageUrl" :src="ruleForm.imageUrl" class="avatar">
                <i v-else class="el-icon-plus avatar-uploader-icon">
                  <p class="uploadTip">上传照片</p>
                  <p class="uploadAsk">搜索结包含：主图、旺旺、显示价格、商品名称等</p>
                </i>
              </el-upload>
              <p class="lookTip" @click="dialogVisible = true">查看示例图</p>
            </el-form-item>
            <el-form-item class="imgTwo" prop="imageUrls">
              <el-upload
                class="avatar-uploader"
                action="http://upload-z2.qiniup.com"
                :data="qn"
                :show-file-list="false"
                :on-success="handleAvatar"
                :before-upload="beforeAvatar">
                <img v-if="ruleForm.imageUrls" :src="ruleForm.imageUrls" class="avatar">
                <i v-else class="el-icon-plus avatar-uploader-icon">
                  <p class="uploadTip">上传照片</p>
                  <p class="uploadAsk">800*1200图</p>
                </i>
              </el-upload>
              <p class="lookTips" @click="dialogDisplay=true">查看示例图</p>
            </el-form-item>
            <el-form-item  prop="keyWords"
                           v-for="(domain, index) in ruleForm.domains"
                           :label="'搜索关键字'+ (index+1)+':'"
                           :key="domain.key"
                           :prop="'domains.' + index + '.option'"
                           :rules="{
                            required: true, message: '搜索关键字内容不能为空', trigger: 'blur'
                          }"
            >
              <el-select v-model="domain.value" placeholder="所有宝贝" style="width: 100px">
                <el-option
                  v-for="item in serchAll"
                  :label="item.element_value"
                  :key="item.element_value"
                  :value="item.element_key">
                </el-option>
              </el-select>
               <el-select v-model="domain.option" placeholder="综合" style="width: 100px">
                 <el-option
                   v-for="item in searchType"
                   :label="item.element_value"
                   :key="item.element_value"
                   :value="item.element_key">
                 </el-option>
               </el-select>
              <el-input placeholder="请填写关键词" v-model="domain.keyWords" style="width: 125px"></el-input>
              <el-input placeholder="筛选条件,如价格筛选60-80" v-model="domain.filter" style="width: 230px"></el-input>
              <el-button @click.prevent="removeDomain(domain)" style="width: 100px" v-if="ruleForm.domains.length > 1 ? isShow= true : isShow=false " >删除关键字</el-button>
            </el-form-item>
            <el-button class="addBtn" @click="addBtn(ruleForm.domains)" v-if="isBtn">增加关键字</el-button>
            <el-form-item label="商家要求:" prop="require" style="margin-top: 36px">
              <div class="edit_container">
                <quill-editor
                  v-model="ruleForm.require"
                  ref="myQuillEditor"
                  class="editer"
                  :options="editorOption"
                  @change="onEditorChange($event)"
                  @ready="onEditorReady($event)">
                </quill-editor>
              </div>
            </el-form-item>
          </el-form>
          <div class="btn">
            <img src="./../../assets/webIndex/next.png" @click="next" v-if="isDisplay"/>
            <img src="./../../assets/webIndex/nextDisabled.png" v-else/>
          </div>
        </div>
      </div>
      <el-dialog
        :visible.sync="dialogVisible"
        width="60%"
        height="1200px"
        :before-close="handleClose">
        <img src="./../../assets/webIndex/demo1.png" style="width: 100%">
      </el-dialog>
      <el-dialog
        :visible.sync="dialogDisplay"
        width="60%"
        height="1200px"
        :before-close="handleClose">
        <img src="./../../assets/webIndex/demo1.png" style="width: 100%">
      </el-dialog>
    </div>
</template>

<script>
  import {quillEditor} from 'vue-quill-editor' //调用编辑器
  import 'vue-quill-editor/node_modules/quill/dist/quill.core.css';
  import 'vue-quill-editor/node_modules/quill/dist/quill.snow.css';
  import  'vue-quill-editor/node_modules/quill/dist/quill.bubble.css'
    export default {
        name: "thirdTab",
        components: {quillEditor},
        data() {
            return {
              isShow: false,
              isBtn:true,
              isDisplay: true,
              dialogVisible:false,
              dialogDisplay:false,
              imageDataUrl:'',
              imageDataUrls:'',
              qn:{
                token: ''
              },
              ruleForm:{
                orderStyle: '',
                imageUrl: '',
                imageUrls: '',
                domains:[
                  {
                    value: '',
                    option:'',
                    keyWords: '',
                    filter: ''
                  }
                ],
                require: ''
              },
              serchAll: [],
              searchType:[],
              radiosArr:[],
              rules:{
                orderStyle: [
                  {required: true, message: '请选择下单类型', trigger: 'change'}
                ],
                imageUrl: [
                  {required: true, message: '请上传图片', trigger: 'change'}
                ],
                imageUrls: [
                  {required: true, message: '请上传图片', trigger: 'change'}
                ]
              },
              editorOption: {
                modules: {
                  toolbar: [
                    ['bold', 'italic', 'underline', 'strike', 'image'],        // toggled buttons
                    ['blockquote', 'code-block'],
                    [{'align': []}],
                    [{'color': []}, {'background': []}],
                    [{'header': [1, 2, 3, 4, 5, 6, false]}],     //几级标题
                  ]
                }
              }
            }
        },
        mounted (){
          this.getQiniuToken()
          this.searchAll()
          this.serchAllClass()
          this.radioFun()
          let objthirdTab = JSON.parse(sessionStorage.getItem('objthirdTab'))
          this.ruleForm.orderStyle = Number(sessionStorage.getItem('orderStyle'))
          this.ruleForm.imageUrl =objthirdTab.thirdImg
          this.ruleForm.imageUrls =objthirdTab.thirdImgs
          this.ruleForm.require = objthirdTab.require;
          let listArr = JSON.parse(sessionStorage.getItem('listAyy'))
          console.log(listArr.length)
          if (listArr.length == 3  ) {
            this.isBtn = false
          }
          if (listArr.length == 3 ) {
            this.ruleForm.domains.shift({
              value:'',
              option:'',
              keyWords: '',
              filter:''
            })
          }
          if (listArr.length == 2 ) {
            this.ruleForm.domains.shift({
              value:'',
              option:'',
              keyWords: '',
              filter:''
            })
          }
          if (listArr.length == 1) {
            this.ruleForm.domains.shift({
              value:'',
              option:'',
              keyWords: '',
              filter:''
            })
          }
          for (let i = 0; i<listArr.length; i++) {

            this.ruleForm.domains.push({
              value: listArr[i].search_type,
              option:listArr[i].search_sort,
              keyWords:listArr[i].keyword,
              filter:listArr[i].term
            })
          }
        },
        computed: {
           editor() {
            return this.$refs.myQuillEditor.quill
          }
        },
        methods: {
          //点击头部
          firstTab(){
            this.$router.push({path:'/firstTab'})
          },
          secondTab(){
            this.$router.push({path:'/secondTab'})
          },
          onEditorChange (e) { // 内容改变事件
            this.ruleForm.count = e.html
            console.log(this.ruleForm.count)
          },
          // 初始化富文本编辑器
          onEditorReady(editor) {
          },
          //上传图片
          handleAvatarSuccess(res, file) {
            this.ruleForm.imageUrl = URL.createObjectURL(file.raw);
            this.param = new FormData();
            this.param.append('file', file, file.name);
            this.imageDataUrl = "http://pqi8u88r7.bkt.clouddn.com/"+res.key  //上传图片的路径
            console.log(this.imageDataUrl)
            return false;
          },
          beforeAvatarUpload(file) {
            console.log(file)

          },
          handleAvatar(res, file) {
            this.ruleForm.imageUrls = URL.createObjectURL(file.raw);
            this.param = new FormData();
            this.param.append('file', file, file.name);
            this.imageDataUrls = "http://pqi8u88r7.bkt.clouddn.com/"+res.key  //上传图片的路径
            console.log(this.imageDataUrls)
            return false;
          },
          beforeAvatar(file) {
            console.log(file)
          },
          //下单类型
          radioFun(){
            this.$http.post('/common/getCacheEnums',{
              key:'lower_type'
            }).then(res=>{
              if (res.code == 1) {
                console.log(res)
                 this.radiosArr = res.datas
              }else{
                 this.$message.error(res.message)
              }

            })
          },
          // 改变下单类型
          radioChange(){
            console.log(this.ruleForm.orderStyle)
            sessionStorage.setItem('orderStyle',this.ruleForm.orderStyle )
          },
          // 新增关键字
          addBtn (){
            this.ruleForm.domains.push({
              value: '',
              option: '',
              keyWords: '',
              filter: '',
              key: Date.now()
            });
            if (this.ruleForm.domains.length >= 3) {
              this.isBtn = !this.isBtn
            }

          },
          // 删除关键字
          removeDomain(item) {
            var index = this.ruleForm.domains.indexOf(item)
            if (index !== -1) {
              this.ruleForm.domains.splice(index, 1)
              this.isBtn = true
            }
          },
          //搜索关键字
          searchAll(){
            this.$http.post('/common/getCacheEnums',{
              key:'search_type'
            }).then(res =>{
              console.log(res)
              if (res.code ==1 ){
                  this.serchAll = res.datas
              }

            })
          },
          serchAllClass(){
            this.$http.post('/common/getCacheEnums',{
              key:'search_sort'
            }).then(res =>{
              console.log(res)
              if (res.code ==1 ){
                this.searchType = res.datas
              }
            })
          },
          handleClose(done) {
            this.dialogVisible = false
            this.dialogDisplay = false
          },
          next(ruleForm){
            this.$refs.ruleForm.validate((valid )=>{
              if (valid) {

                let listAyy = [];

                for (let i= 0;i<this.ruleForm.domains.length;i++) {
                  listAyy.push({
                    search_type: this.ruleForm.domains[i].value,
                    search_sort: this.ruleForm.domains[i].option,
                    keyword : this.ruleForm.domains[i].keyWords,
                    term: this.ruleForm.domains[i].filter
                  })
                }
                let obj ={searchKeyword:listAyy}
                sessionStorage.setItem('objThird',JSON.stringify(obj))
              let objthirdTab ={
                    thirdImg: this.imageDataUrl,
                    thirdImgs: this.imageDataUrls,
                    require: this.ruleForm.require
                  }
                sessionStorage.setItem('objthirdTab',JSON.stringify(objthirdTab))
                sessionStorage.setItem('listAyy',JSON.stringify(listAyy))
                this.$router.push({path:'./fourthTab'})
              } else {

              }
            })
          },
          //获取上传图片的token
          getQiniuToken() {
            this.$http.post("/common/getQiNiuPicToken")
              .then(response => {
                if (response.code == 1) {
                  this.qn.token=response.datas;
                }
              })
              .catch(error => {
                console.log(error)
              });
          },
        }
    }
</script>

<style scoped>
  .firstShop{
    width: 800px;
    margin: 20px auto;
  }

  .labelTip{
    text-align: center;
    font-size: 20px;
    color: #333333;
    margin-top: 30px;
  }
  .uls{
    width: 98%;
    border-bottom: 1px solid #dddddd;
    margin-top: 10px;
  }
  .uls li{
    width: 78px;
    height: 36px;
    line-height: 36px;
    border-radius: 5px 5px 0px 0px;
    display: inline-block;
    margin-left: 11px;
    background: #f2f2f2;
    text-align: center;
    cursor: pointer;
  }
  .activit{
    background: #f28b1d !important;
    color: #fff;
  }
  .avatar-uploader {
    display: inline-block;
    margin-left: 20px;
  }
  .avatar-uploader .el-upload:hover {
    border-color: #409EFF;
  }
  .avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    margin-top: 21px;
    /*width: 178px;*/
    /*height: 178px;*/
    /*line-height: 178px;*/
    text-align: center;
  }
  .avatar {
    width: 178px;
    height: 178px;
    display: block;
  }
  .uploadTip {
    font-size: 14px;
    margin-top: 20px;
    color: #666666;
  }
  .uploadAsk{
    font-size: 12px;
    color: #888;
  }
  .lookTip,.lookTips{
    color: #1d76f2;
    text-align: center;
    font-size: 12px;
    cursor: pointer;
    width: 85%;
  }
  .lookTips{
    width: 43%;
    margin-left: 20px;
  }
  .imgOne.el-form-item,.imgTwo.el-form-item{
    width: 41%;
    display: inline-block;
  }
  .addBtn{
    width: 85px;
    height: 40px;
    padding: 0;
    font-weight: normal;
    line-height: 40px;
    margin-left: 34px;
  }
  .btn{
    display: flex;
    justify-content: center;
    margin: 70px auto;
  }
  .btn img{
    margin-left: 50px;

  }
</style>

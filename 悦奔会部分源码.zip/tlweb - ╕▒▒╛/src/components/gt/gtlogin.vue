<template>
    <div class="gtlogin">
      <el-form label-width="100px">
        <el-form-item label="人机验证:" prop="name">
          <div id="captch"></div>
          <p ></p>
        </el-form-item>
      </el-form>
    </div>
</template>

<script>
  import './../../assets/gt'

    export default {
        name: "gtlogin",
        data() {
            return {}
        },
        methods: {}
    }
</script>

<style scoped>
  .el-input  {
    width: 90%;
  }
</style>

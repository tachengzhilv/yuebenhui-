function  getBase(url) {
  if (url == 'login') {
    return 'http://192.168.0.112:8400'
  }
}
export default {
  getBase

}

import  axios from 'axios'
import  router from '@/router'
import  {Loading, Message } from "element-ui";
let loading
var instance = axios.create({
  baseURL: 'http://192.168.0.107:8400',
  timeout: 3000
})
let formdata = res =>{
  let Fdata = new FormData()
  for (let  i in  res) {
    Fdata.append(i,res[i])
    console.log(Fdata)
  }
  return  Fdata
}



// 添加请求拦截器
instance.interceptors.request.use((req) => {
  // 在发送请求之前做些什么

  if (sessionStorage.getItem('token')) {
      req.headers.token = sessionStorage.getItem('token')
  }
  loading = Loading.service({
    lock: true,
    text: '加载中……',
    background: 'rgba(0, 0, 0, 0.7)'
  })
  if (req.data) {
    if (!req.data.isJSON) {
      req.data = formdata(req.data)
    } else {
      req.data = req
    }
 }
  return req
}, function (error) {
  // 对请求错误做些什么
  return Promise.reject(error)
})

// 添加响应拦截器
instance.interceptors.response.use(function (res) {
  //   // 对响应数据做点什么
  loading.close()
  return res.data
}, function (error) {
  loading.close()
  // 对响应错误做点什么
  let str = error + ''
  if (str.search('timeout') !== -1) { // 请求超时
    Message.error('请求超时，请稍后再试')
    return false
  }
  if (error && error.response) {
    switch (error.response.status) {
      case 400:
        Message.error('错误请求')
        break
      case 401:
        Message({
            type: 'warning',
            message: '请先登录',
            onClose: () => {
              router.push({path: '/'})
              sessionStorage.clear()
            }
          })
        break
    }
  } else {
    Message.error('当前网络不可用，请稍后重试')
  }
  return error
})
// 在实例已创建后修改默认值
// instance.defaults.headers.common['Authorization'] = AUTH_TOKEN
export default instance

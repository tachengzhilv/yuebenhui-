<template>
    <div class="logIn">
        <div class="logInPwd">
          <el-form  label-width="100px" class="logInFrom" :model="ruleForms" :rules="rulesRest" ref="ruleForms">
            <el-form-item label="手机号码:" prop="tel">
              <el-input placeholder="请输入手机号" v-model="ruleForms.tel"></el-input>
            </el-form-item>
<!--            <el-gt  v-if="isCode==false"></el-gt>-->
            <el-form-item label="验 证 码 :" prop="code" v-if="isCode==false">
              <el-input placeholder="请输入验证码" v-model="ruleForms.code" style="width: 215px;"></el-input>
              <send-code></send-code>
            </el-form-item>
            <el-form-item label="密 码 :" prop="pwd" v-else class="passIn">
              <el-input placeholder="请输入密码" type="passWord" v-model="ruleForms.pwd" style="width: 215px;" show-password></el-input>
              <el-button style="margin-left: 11px" @click="isPwd">无密码登录</el-button>
            </el-form-item>
            <div class="loginBtn" @click="loginView(ruleForms)">
              <img src="./../assets/reg/dl.png">
            </div>
          </el-form>
          <p class="flexP" >
            <span  v-if="isCode==false" @click="loginPwd()">密码登录</span>
            <span></span>
            <span style="text-align: right" @click="forgetPwd">忘记密码？</span>
          </p>
        </div>
    </div>
</template>

<script>
  import  sendCode from './../components/authCode'
  // import  elGt from  './../components/gt/gtlogin'
    export default {
        name: "logIn",
        components:{
          sendCode
        },
        data(){
          // 判断手机号是否正确
          var checkPhone = (rule, value, callback) => {
            if (!value) {
              return callback(new Error('手机号不能为空'));
            } else {
              const reg = /^1[3|4|5|7|8][0-9]\d{8}$/
              console.log(reg.test(value));
              if (reg.test(value)) {
                callback();
              } else {
                return callback(new Error('请输入正确的手机号'));
              }
            }
          };
          // 判断密码是否正确
          var checkPwd = (rule, value, callback) => {
            if (!value) {
              return callback(new Error(' 请输入密码'));
            }else {
              const regPwd = /^(?=.*[a-zA-Z])(?=.*\d)(?=.*[~!@#$%^&*()_+`\-={}:";'<>?,.\/]).{6,25}$/
              console.log(regPwd.test(value))
              if (regPwd.test(value)) {
                if (this.ruleForms.checkPass!== '') {
                  this.$refs.ruleForms.validateField('checkPass');
                }
                callback();
              } else {
                return callback(new Error('密码由6-25个字符，有字母，数字特殊符号组成'));
              }
            }
          };
            return {
              ruleForms: {
                tel: '',
                code: '',
                pwd: ''
              },
              rulesRest:{
                tel:[
                  {validator: checkPhone, trigger: 'blur'}
                ],
                code:[
                  {message: '请输入验证码', trigger: 'blur' }
                ],
                pwd:[
                  { validator: checkPwd, trigger: 'blur' }
                ]
              },
              isShow:true,
              isCode: true
            }
        },
        methods:{
          // 登录
          loginView(ruleForms){
            this.$refs.ruleForms.validate((valid )=>{
              console.log(valid)
              let that = this
              if (valid){
                 that.$http.post('/merchant/login/logins',{
                  mobile :that.ruleForms.tel,
                  pass : that.ruleForms.pwd,
                  code : that.ruleForms.code
                }).then(function (res) {
                   console.log(res)
                   if(res.code == 1){
                     sessionStorage.setItem('id',res.datas.id)
                     sessionStorage.setItem('shopNum',res.datas.shopNumber)
                     let tokens =that.$md5(res.datas.token+'tlkj2019')
                     sessionStorage.setItem('token',tokens)
                     // this.$md5('holle')
                     that.$message({
                        message:res.message,
                        showClose: true,
                        type: 'success',
                        onClose:function () {
                          that.$router.push({path:'/firstTab'})
                          sessionStorage.setItem('userTel',that.ruleForms.tel);

                        }
                      })

                   }else if (res.code == 2) {
                     that.$message({
                       message:res.message,
                       showClose: true,
                       type: 'error'
                     })
                   }
                 }).then(function (err) {
                   console.log(err)
                 })
              }else {
                console.log('error submit!!');
                return false;
              }
            })
          },
          //判断是否是密码登录
          isPwd(){
            this.isCode= !this.isCode
            this.ruleForms.pwd = ''
          },
          // 如果不是密码登录可以切换为密码登录
          loginPwd(){
            this.isCode= !this.isCode
            this.ruleForms.code = '';
          },
          forgetPwd(){
            this.$router.push({path: '/stepPass'})
          }
      }
    }
</script>

<style scoped>
  .logInFrom{
    margin-top:141px;
  }
  .loginBtn {
    margin-top: 110px;
  }
  .flexP {
    display: flex;
    display: -webkit-flex;
    width: 90%;
    margin: 15px auto;
    font-size: 14px;
  }
  .flexP span{
    flex: 1;
    -webkit-flex: 1;
    cursor: pointer;
  }
  .flexP span:nth-of-type(1){
    color: #f28b1d;
  }
  .flexP span:nth-of-type(2){
    text-align: right;
  }
  .el-input  {
    width: 90%;
  }
</style>

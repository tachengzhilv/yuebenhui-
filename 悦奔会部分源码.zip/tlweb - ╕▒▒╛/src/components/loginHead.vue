<template>
    <div>
      <div class="header">
        <p class="Pleft">
          <img src="./../assets/reg/logo.png" class="logo">
        </p>
        <p class="Pright">
        <span @click="indexRouter" :class="isClient== true ? 'active': ''">
          <img src="./../assets/reg/index.png" class="index">
          <b>首页</b>
        </span>
          <span :class="isClient== false ? 'active': ''">
          <img src="./../assets/reg/shop.png" class="home">
          <b>商家中心</b>
        </span>
        </p>
      </div>
    </div>
</template>

<script>
    export default {
        name: "loginHead",
        data() {
            return {
              isClient:false
            }
        },
        methods: {
          // isShow(data){
          //   this.isClient = !this.isClient;
          //   this.$emit('isShow',this.isClient)
          // }
          indexRouter(){
            this.$router.push({path:'/ClientIndex'})
          }

        }
    }
</script>

<style scoped>
  .Pleft{
    display: inline-block;
    float: left;
  }
  .header{
    width: 60%;
    height: 95px;
    margin: 0 auto;
    margin-top: 20px;
  }
  .logo{
    display: inline-block;
    width: 243px;
    height: 95px;
    vertical-align: middle;
  }
  .Pright{
    float: right;
    color: #888888;
    font-size: 18px;
    cursor: pointer;
  }
  .Pright span{
    height: 21px;
    display: inline-block;
    line-height: 21px;
    margin-top: 38px;
  }
  .Pright span:nth-of-type(1){
    margin-right: 20px;
  }
  .Pright .index{
    display: inline-block;
    width: 19px;
    height: 20px;
    vertical-align: bottom;
  }
  .Pright .home{
    display: inline-block;
    width: 21px;
    height: 19px;
    vertical-align: bottom;
  }
  .Pright b{
    display: inline-block;
    line-height: 21px;
    font-weight: normal;
    margin-left: 10px;
  }
  .active {
    color:#f28b1d !important;
  }
</style>

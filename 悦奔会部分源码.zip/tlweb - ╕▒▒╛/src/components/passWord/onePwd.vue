<template>
    <div class="onePwd">
      <div class="head">
        <h4>找回密码</h4>
        <el-steps :active="1" align-center>
          <el-step title="输入手机号码"></el-step>
          <el-step title="验证信息"></el-step>
          <el-step title="设置密码"></el-step>
        </el-steps>
      </div>
      <div class="fromIphone">
        <el-form label-width="100px" class="PwdruleForm" :model="ruleForm" :rules="rules" ref="ruleForm" >
          <el-form-item label="手机号码:" prop="tel">
            <el-input placeholder="请输入手机号" v-model="ruleForm.tel"  @blur="onBlur"></el-input>
          </el-form-item>
<!--          <el-form-item label="人机验证:" prop="name">-->
<!--            <el-input ></el-input>-->
<!--          </el-form-item>-->
        </el-form>

      </div>

    </div>
</template>

<script>
    export default {
        name: "onePwd",
        data() {
          // 判断手机号是否正确
          var checkPhone = (rule, value, callback) => {
            if (!value) {
              return callback(new Error('手机号不能为空'));
            } else {
              const reg = /^1[3|4|5|7|8][0-9]\d{8}$/
              console.log(reg.test(value));
              if (reg.test(value)) {
                callback();
              } else {
                return callback(new Error('请输入正确的手机号'));
              }
            }
          };
            return {
              ruleForm: {
                tel: ''
              },
              rules:{
                tel:[
                  {validator: checkPhone, trigger: 'blur'}
                ]

              }
            }
        },
        methods: {
          onBlur (){
            if(this.ruleForm.tel === '') {
               this.$message({
                 message:'手机号不能为空',
                 showClose: true,
                 type: 'error',
               })
            }else{
              sessionStorage.setItem('pwdTel',this.ruleForm.tel)
            }

          }
        }
    }
</script>

<style scoped>
.onePwd{
  position: relative;

}
.head{
  position: absolute;
  width: 90%;
  top: 120px;
  left: 5%;
}
h4{
  font-size: 34px;
  color: #333;
  text-align: center;
}
.el-steps{
  margin-top: 78px;
}
.PwdruleForm{
    width: 69%;
    position: absolute;
    left:29%;
    top: 405px;

}
.el-input{
  width: 45%;
  margin:0 auto;
}

</style>

<template>
  <div class="twoPwd">
    <div class="head">
      <h4>找回密码</h4>
      <el-steps :active="3" align-center>
        <el-step title="输入手机号码"></el-step>
        <el-step title="验证信息"></el-step>
        <el-step title="设置密码"></el-step>
      </el-steps>
    </div>
    <div class="codePwd">
      <el-form label-width="100px" class="PwdruleForm" :model="ruleForm" :rules="rules" ref="ruleForm">
        <el-form-item label="密 码 :" prop="pwd">
          <el-input placeholder="请输入密码" type="passWord" v-model="ruleForm.pwd" @blur="onBlur"  show-password></el-input>
<!--          <i class="newLook"><img src="./../../assets/reg/ivew.png"> </i>-->
        </el-form-item>
        <el-form-item label="确认密码:" prop="checkPass">
          <el-input placeholder="请确认密码" type="passWord"  v-model="ruleForm.checkPass" @blur="checkPass"></el-input>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>

<script>
    export default {
        name: "threePwd.vue",
        data() {
          // 判断密码是否正确
          var checkPwd = (rule, value, callback) => {
            if (!value) {
              return callback(new Error(' 请输入密码'));
            }else {
              const regPwd = /^(?=.*[a-zA-Z])(?=.*\d)(?=.*[~!@#$%^&*()_+`\-={}:";'<>?,.\/]).{6,25}$/
              console.log(regPwd.test(value))
              if (regPwd.test(value)) {
                if (this.ruleForm.checkPass!== '') {
                  this.$refs.ruleForm.validateField('checkPass');
                }
                callback();
              } else {
                return callback(new Error('密码由6-25个字符，有字母，数字特殊符号组成'));
              }
            }
          };
          // 判断确认密码是否和第一次输入的一样
          var validatePass2 = (rule, value, callback) => {
            if (value === '') {
              callback(new Error('请再次输入密码'));
            } else if (value !== this.ruleForm.pwd) {
              callback(new Error('两次输入密码不一致!'));
            } else {
              callback();
            }
          };
          return {
            ruleForm: {
              pwd: '',
              checkPass: '',
            },
            rules:{
              pwd:[
                { validator: checkPwd, trigger: 'blur' }
              ],
              checkPass:[
                { validator: validatePass2, trigger: 'blur' }
              ]
            }
          }
        },
        methods: {
          onBlur(){
            sessionStorage.setItem('pwdPass',this.ruleForm.pwd)
          },
          checkPass(){
            sessionStorage.setItem('checkPass',this.ruleForm.checkPass)
          }
        }
    }
</script>

<style scoped>
  .twoPwd{
    position: relative;

  }
  .head{
    position: absolute;
    width: 90%;
    top: 120px;
    left: 5%;
  }
  h4{
    font-size: 34px;
    color: #333;
    text-align: center;
  }
  .el-steps{
    margin-top: 78px;
  }
  .codePwd{
    width: 69%;
    position: absolute;
    left:29%;
    top: 405px;
  }
  .el-input{
    width: 45%;
    margin:0 auto;
  }
  i{
    position: absolute;
    left: 310px;
    top: 2px;
  }
  i img{
    width: 20px;
  }
</style>

<template>
    <div class="twoPwd">
      <div class="head">
        <h4>找回密码</h4>
        <el-steps :active="2" align-center>
          <el-step title="输入手机号码"></el-step>
          <el-step title="验证信息"></el-step>
          <el-step title="设置密码"></el-step>
        </el-steps>
      </div>
      <div class="codePwd">
        <el-form label-width="100px" class="twoSpet" >
          <el-form-item label="验 证 码 :" >
            <el-input placeholder="请输入验证码" type="text" v-model="code"  @blur="onBlur"></el-input>
            <send-code class="sendCode"></send-code>
            <p class="sendP" v-if="sendCode">验证码已发送至您的手机，请注意查收</p>
          </el-form-item>
        </el-form>
      </div>
    </div>
</template>

<script>
  import  sendCode from './../authCode'
    export default {
        name: "twoPwd",
        components:{sendCode},
        data() {
            return {
              code: '',
              sendCode: false
            }
        },
        methods: {
          onBlur (){
            sessionStorage.setItem('pwdCode',this.code)
            this.sendCode = true
          }
        }
    }
</script>

<style scoped>
  .twoPwd{
    position: relative;

  }
  .head{
    position: absolute;
    width: 90%;
    top: 120px;
    left: 5%;
  }
  h4{
    font-size: 34px;
    color: #333;
    text-align: center;
  }
  .el-steps{
    margin-top: 78px;
  }
  .codePwd{
    width: 69%;
    position: absolute;
    left:29%;
    top: 405px;
  }
  .el-input{
    width: 45%;
    margin:0 auto;
  }
  .sendCode{
    position: absolute;
    right: 290px !important;
  }
  .sendP{
    color:#333333;
  }
</style>

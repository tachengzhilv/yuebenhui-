// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import ElementUI from  'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
import App from './App'
import router from './router'
import  './assets/publick.css'
import instance from "./components/http/http";
import getBase from "./components/http/getBaseUrl";
import {setCookie, getCookie, delCookie} from './components/http/cookie';
import md5 from 'js-md5'
import VueClipboard from 'vue-clipboard2'
import VueAwesomeSwiper from 'vue-awesome-swiper'
Vue.use(VueAwesomeSwiper)
import 'swiper/dist/css/swiper.min.css'

Vue.use(VueClipboard)

Vue.prototype.$md5 = md5;
Vue.prototype.$cookieStore = {
  setCookie,
  getCookie,
  delCookie
}
Vue.config.productionTip = false
Vue.prototype.$http = instance
Vue.prototype.$getBase = getBase
Vue.use(ElementUI);


router.beforeEach((to,from,next) => {

  if (to.meta.requireAuth) {
    if (sessionStorage.getItem('token')) {
      next()
    }else {
      next({
        path:'/',
        query:{
          redirect:to.fullPath // 将跳转的路由path作为参数，登录成功后跳转到该路由
        }
      })
    }
  }else {
    next()
  }

})
/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  components: { App },
  template: '<App/>'
})

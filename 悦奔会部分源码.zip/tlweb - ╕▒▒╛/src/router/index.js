import Vue from 'vue'
import Router from 'vue-router'
import Login from  '@/views/login'
import Index from './../views/shopCenter/index/index'

// 试客pc 的 首页，搜索，详情页
import mainIndex from './../views/clientCenter/index/main'
import ClientIndex from './../views/clientCenter/index/index'
import ClientProduct from './../views/clientCenter/index/search_product'
import ClientDeatil from  './../views/clientCenter/index/searchDetail'


import stepPass from  './../views/shopCenter/findPassWord/stepPass'
import addStore from  './../views/shopCenter/storeManage/addStore'
import storeList from  './../views/shopCenter/storeManage/storeList'
import storeEdit from  './../views/shopCenter/storeManage/storeEdit'
// import tradePost from  './../views/shopCenter/tradePost/tradePost'
import trialManage from './../views/shopCenter/activiteManage/trialManage'
import trialOrder from './../views/shopCenter/activiteManage/trialOrder'

import  blackList from  './../views/shopCenter/blacklist/blacklist'
import detailList from './../views/shopCenter/activiteManage/trialDetails/detailList'
import detailInfo from './../views/shopCenter/activiteManage/trialDetails/detailInfo'
import detailTrial from './../views/shopCenter/activiteManage/trialDetails/detailTrial'
import trialList from './../views/shopCenter/activiteManage/trialDetails/trialList'
import orderList from './../views/shopCenter/activiteManage/trialOrder/orderList'
import FirstTabs from './../views/shopCenter/activiteManage/FirstTab'
import SecondTabs from './../views/shopCenter/activiteManage/secondTab'
import ThirdTabs from './../views/shopCenter/activiteManage/thirdTab'
import FourthTabs from './../views/shopCenter/activiteManage/fourthTab'
import FifthTabs from './../views/shopCenter/activiteManage/fifthTab'

// 个人中心
import accountData from './../views/shopCenter/my/accountData'
import fundManage from './../views/shopCenter/my/fundManage'
import messageCenter from './../views/shopCenter/my/messageCenter'
import inviteRebate from './../views/shopCenter/my/inviteRebate'
import securityCenter from './../views/shopCenter/my/securityCenter'
import cardManage from './../views/shopCenter/my/cardManage'
import vip from './../views/shopCenter/my/vip'

import accountDetail from './../views/shopCenter/my/accountData/accountDetail'
import fundDetail from './../views/shopCenter/my/fundManage/fundDetail'
import messageDetail from './../views/shopCenter/my/messageCenter/messageDetail'
import inviteDetail from './../views/shopCenter/my/inviteRebate/inviteDetail'
import securityDetail from './../views/shopCenter/my/securityCenter/securityDetail'
import cardDetail from './../views/shopCenter/my/cardManage/cardDetail'
import vipDetail from './../views/shopCenter/my/vip/vipDetail'
import accountRecharge from './../views/shopCenter/my/fundManage/accountRecharge'
import applyCash from './../views/shopCenter/my/fundManage/applyCash'
import applyHistory from './../views/shopCenter/my/fundManage/applyHistory'
import balanceDetail from './../views/shopCenter/my/fundManage/balanceDetail'
import guaranteeMoney from './../views/shopCenter/my/fundManage/guaranteeMoney'
import integralDetail from './../views/shopCenter/my/fundManage/integralDetail'
import integralRecharge from './../views/shopCenter/my/fundManage/integralRecharge'
import vipIntroduction from './../views/shopCenter/my/vip/vipIntroduction'
import vipHistory from './../views/shopCenter/my/vip/vipHistory'
import vipBuy from './../views/shopCenter/my/vip/vipBuy'


import firstTab from  './../components/flowPost/firstTab'
import secondTab from  './../components/flowPost/secondTab'
import thirdTab from  './../components/flowPost/thirdTab'
import fourthTab from  './../components/flowPost/fourthTab'
import fifthTab from  './../components/flowPost/fifthTab'
Vue.use(Router)



export default new Router({
  routes: [
    {
      path: '/',
      name: 'Login',
      component: Login,
      hidden: true,
      meta: {
        keepAlive: false
      }

    },
    {
      path: '/stepPass',
      name: 'stepPass',
      component: stepPass,
      hidden: true,
      meta: {
        keepAlive: false
      }
    },
    {
      path: '/Index',
      name: 'Index',
      component: Index,
      hidden: true,
      meta: {
        keepAlive: true,
        requireAuth: true // 添加该字段，表示进入这个路由是需要登录的
      }
    },
    {
      path: '/mainIndex',
      name: 'mainIndex',
      component: mainIndex,
      hidden: true,
      meta: {
        keepAlive: true
      },
      children:[
        {
          path: '/ClientIndex',
          name: 'ClientIndex',
          hidden: true,
          component: ClientIndex,
          meta: {
            keepAlive: true
          }
        },
        {
          path: '/ClientProduct',
          name: 'ClientProduct',
          hidden: true,
          component: ClientProduct,
          meta: {
            keepAlive: true
          }
        },
        {
          path: '/ClientDeatil',
          name: 'ClientDeatil',
          hidden: true,
          component: ClientDeatil,
          meta: {
            keepAlive: true
          }
        }
      ]
    },

    {
      path:'/tradePost',
      name:'发布试用',
      component: Index,
      leaf:true,// 只有一个节点,
      meta:{keepAlive: true},
      children: [
        { path: '/firstTab', component: firstTab, name: '发布试用', meta: {
            requireAuth: true // 添加该字段，表示进入这个路由是需要登录的
          } },
        { path: '/secondTab', component: secondTab, name: '发布试用2', meta: {
            requireAuth: true // 添加该字段，表示进入这个路由是需要登录的
          } },
        { path: '/thirdTab', component: thirdTab, name: '发布试用3',meta: {
            requireAuth: true // 添加该字段，表示进入这个路由是需要登录的
          } },
        { path: '/fourthTab', component: fourthTab, name: '发布试用4',meta: {
            requireAuth: true // 添加该字段，表示进入这个路由是需要登录的
          } },
        { path: '/fifthTab', component: fifthTab, name: '发布试用5',meta: {
            requireAuth: true // 添加该字段，表示进入这个路由是需要登录的
          } }
      ]
    },
    {
      path:'/secondTab',
      name:'secondTab',
      component: Index,
      hidden: true,

    },
    {
      path: '/addStore',
      name: '店铺管理',
      component:Index,
      redirect: '/storeManage/addStore',
      children:[
        // 新建店铺
        {
          path:'/addStore',
          name:'新建店铺',
          component:addStore,
          meta: {
            requireAuth: true // 添加该字段，表示进入这个路由是需要登录的
          }
        },
        // 店铺列表
        {
          path:'/storeList',
          name:'店铺列表',
          component:storeList,
          meta: {
            requireAuth: true // 添加该字段，表示进入这个路由是需要登录的
          }
        }
        ,
        // 店铺列表修改
        {
          hidden: true,
          path:'/storeEdit',
          name:'店铺列表',
          component:storeEdit,
          meta: {
            requireAuth: true // 添加该字段，表示进入这个路由是需要登录的
          }
        }
      ]
    },
    {
      path: '/trialManage',
      name: '活动管理',
      component:Index,
      redirect: '/activiteManage/trialManage',
      children:[
        // 试用活动
        {
          path:'/trialManage',
          name:'试用活动',
          component:trialManage,
          children:[
            {path:'/trialManage',component: detailList,name:'试用活动',
              meta: {
                  requireAuth: true // 添加该字段，表示进入这个路由是需要登录的
                }
            },
            {path:'/detailInfo',component: detailInfo,name:'使用详情',meta: {
                requireAuth: true // 添加该字段，表示进入这个路由是需要登录的
              }},
            {path:'/detailTrial',component: detailTrial,name:'试客管理',meta: {
                requireAuth: true // 添加该字段，表示进入这个路由是需要登录的
              }},
            {path:'/trialManage',component: detailList,name:'试用活动',meta: {
              requireAuth: true // 添加该字段，表示进入这个路由是需要登录的
            }},
            {path:'/detailInfo',component: detailInfo,name:'使用详情',meta: {
              requireAuth: true // 添加该字段，表示进入这个路由是需要登录的
            }},
            {path:'/detailTrial',component: detailTrial,name:'试客管理',meta: {
              requireAuth: true // 添加该字段，表示进入这个路由是需要登录的
            }},
            {path:'/trialList',component: trialList,name:'试客列表',meta: {
              requireAuth: true // 添加该字段，表示进入这个路由是需要登录的
            }},
            {
              path:'/FirstTabs',component: FirstTabs,name:'发布第一步',
              meta:{
                requireAuth: true // 添加该字段，表示进入这个路由是需要登录的
              }
            }
            ,
            {
              path:'/SecondTabs',component: SecondTabs,name:'发布第二步',meta:{
                requireAuth: true // 添加该字段，表示进入这个路由是需要登录的
              }
            }
            ,
            {
              path:'/ThirdTabs',component: ThirdTabs,name:'发布第三步',meta:{
                requireAuth: true // 添加该字段，表示进入这个路由是需要登录的
              }
            }
            ,
            {
              path:'/FourthTabs',component: FourthTabs,name:'发布第四步',meta:{
                requireAuth: true // 添加该字段，表示进入这个路由是需要登录的
              }
            }
            ,
            {
              path:'/FifthTabs',component: FifthTabs,name:'发布第五步',meta:{
                requireAuth: true // 添加该字段，表示进入这个路由是需要登录的
              }
            }
          ]
        },
        // 试用订单
        {
          path:'/trialOrder',
          name:'试用订单',
          component:trialOrder,
          children:[
            {path:'/trialOrder',component: orderList,name:'试用订单',meta: {
              requireAuth: true // 添加该字段，表示进入这个路由是需要登录的
            }}
          ]
        }
      ]
    },
    {
      path:'/accountData',
      name:'账户资料',
      component: Index,
      redirect:'/my/accountData',
      children:[
        //账户资料
        {
          path:'/accountData',
          name:'账户资料',
          component:accountData,
          children:[
            {path:'/accountData',component: accountDetail,name:'账户资料',meta: {
              requireAuth: true // 添加该字段，表示进入这个路由是需要登录的
            }}
          ]
        },
        //资金管理
        {
          path:'/fundManage',
          name:'资金管理',
          component:fundManage,
          children:[
            {path:'/fundManage',component: fundDetail,name:'资金管理',meta: {
              requireAuth: true // 添加该字段，表示进入这个路由是需要登录的
            }},
            {path:'/accountRecharge',component:accountRecharge,name:'账户充值',meta: {
              requireAuth: true // 添加该字段，表示进入这个路由是需要登录的
            }},
            {path:'/applyCash',component:applyCash,name:'申请提现',meta: {
              requireAuth: true // 添加该字段，表示进入这个路由是需要登录的
            }},
            {path:'/applyHistory',component:applyHistory,name:'提现记录',meta: {
              requireAuth: true // 添加该字段，表示进入这个路由是需要登录的
            }},
            {path:'/balanceDetail',component:balanceDetail,name:'余额明细',meta: {
              requireAuth: true // 添加该字段，表示进入这个路由是需要登录的
            }},
            {path:'/guaranteeMoney',component:guaranteeMoney,name:'担保金额记录',meta: {
              requireAuth: true // 添加该字段，表示进入这个路由是需要登录的
            }},
            {path:'/integralDetail',component:integralDetail,name:'积分明细',meta: {
              requireAuth: true // 添加该字段，表示进入这个路由是需要登录的
            }},
            {path:'/integralRecharge',component:integralRecharge,name:'积分充值',meta: {
              requireAuth: true // 添加该字段，表示进入这个路由是需要登录的
            }},
            {path:'/vipIntroduction',component:vipIntroduction,name:'vip介绍',meta: {
              requireAuth: true // 添加该字段，表示进入这个路由是需要登录的
            }},
            {path:'/vipHistory',component:vipHistory,name:'VIP购买记录',meta: {
              requireAuth: true // 添加该字段，表示进入这个路由是需要登录的
            }},
            {path:'/vipBuy',component:vipBuy,name:'支付',meta: {
              requireAuth: true // 添加该字段，表示进入这个路由是需要登录的
            }}
          ]
        },
        //消息中心
        {
          path:'/messageCenter',
          name:'消息中心',
          component:messageCenter,
          children:[
            {path:'/messageCenter',component: messageDetail,name:'消息中心',meta: {
              requireAuth: true // 添加该字段，表示进入这个路由是需要登录的
            }}
          ]
        },
        //邀请返利
        {
          path:'/inviteRebate',
          name:'邀请返利',
          component:inviteRebate,
          children:[
            {path:'/inviteRebate',component: inviteDetail,name:'邀请返利',meta: {
              requireAuth: true // 添加该字段，表示进入这个路由是需要登录的
            }}
          ]
        },
        //安全中心
        {
          path:'/securityCenter',
          name:'安全中心',
          component:securityCenter,
          children:[
            {path:'/securityCenter',component: securityDetail,name:'安全中心',meta: {
              requireAuth: true // 添加该字段，表示进入这个路由是需要登录的
            }}
          ]
        },
        //银行卡管理
        {
          path:'/cardManage',
          name:'银行卡管理',
          component:cardManage,
          children:[
            {path:'/cardManage',component: cardDetail,name:'银行卡管理',meta: {
              requireAuth: true // 添加该字段，表示进入这个路由是需要登录的
            }}
          ]
        },
        //开通/续费VIP
        {
          path:'/vip',
          name:'开通/续费VIP',
          component:vip,
          children:[
            {path:'/vip',component: vipDetail,name:'开通/续费VIP',meta: {
              requireAuth: true // 添加该字段，表示进入这个路由是需要登录的
            }}
          ]
        }
      ]
    },
    {
      path: '/blackList',
      name: '黑名单管理',
      component:Index,
      redirect: '/blackList/blackList',
      children:[
        {
          path:'/blackList',
          name:'黑名单',
          component:blackList
        }

      ]
    }
  ]
})

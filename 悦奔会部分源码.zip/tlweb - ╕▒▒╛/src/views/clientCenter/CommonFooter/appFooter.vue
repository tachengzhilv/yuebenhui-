<template>
    <div class="foot">
        <div class="footerFirst">
          <p>
            <img src="./../../../assets/client/gw.png">
            <span>无忧返款</span>
          </p>
          <p>
            <img src="./../../../assets/client/gw.png">
            <span>无忧返款</span>
          </p>
          <p>
            <img src="./../../../assets/client/gw.png">
            <span>无忧返款</span>
          </p>
          <p>
            <img src="./../../../assets/client/gw.png">
            <span>无忧返款</span>
          </p>
        </div>
        <div class="footerUl">
            <ul>
              <li>
                <p>新手指南</p>
                <p>商家流程</p>
                <p>如何发布商品</p>
              </li>
              <li>
                <p>关于我们</p>
                <p>商家流程</p>
                <p>如何发布商品</p>
              </li>
              <li>
                <p>服务中心</p>
                <p>商家流程</p>
                <p>如何发布商品</p>
              </li>
            </ul>
        </div>
        <div class="footerP">
          <p>2017-2020 XXX.COM 版权所有：桐璐网络科技有限公司</p>
        </div>
    </div>
</template>

<script>
    export default {
        name: "appFooter.vue",
        data() {
            return {}
        },
        methods: {}

    }
</script>

<style scoped>
.foot{
  width: 100%;
  margin-top: 80px;
  background: #ffffff;
}
.footerFirst{
  display: flex;
  width: 90%;
  margin: 0 auto;
  padding-top: 63px;
}
.footerFirst p{
   flex: 1;
   color: #f28b1d;
   text-align: center;
}
.footerFirst p img{
   vertical-align: bottom;
}
.footerFirst p span{
  font-size: 28px;
  height: 50px;
}
.footerUl {
   width: 50%;
   margin: 0 auto;
   margin-top: 80px;
}
.footerUl ul{
  display: flex;
}
.footerUl ul li{
  flex: 1;
   text-align: center;
  line-height: 45px;
}
.footerUl ul li p{
  font-size: 16px;
  color: #666666;
}
.footerUl ul li p:nth-of-type(1){
  color: #333;
  font-size: 20px;
}
.footerP{
  text-align: center;
  font-size:12px;
  color: #666666;
  margin-top: 64px;
  margin-bottom: 10px;
}
</style>

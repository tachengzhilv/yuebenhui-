<template>
    <div id="appheader">
      <div class="boxMain">
        <div class="main">
          <p>
            <span class="index"><img src="./../../../assets/webIndex/index.png">首页</span>
            <span><img src="./../../../assets/webIndex/shop.png">商家中心</span>
          </p>
        </div>
      </div>
      <div class="logoMain">
        <p>
          <img src="./../../../assets/webIndex/logo.png">
        </p>
        <p class="searchMain">
          <img src="./../../../assets/webIndex/search.png" class="">
          <input type="text" v-model="input" placeholder="请输入关键字" @change="changeVal"/>
          <button @click="search">搜索</button>
        </p>
        <p class="keyWord">
          <span>睡衣</span>
          <span>充电宝</span>
          <span>手机</span>
          <span>连衣裙</span>
          <span>手机</span>
          <span>连衣裙</span>
          <span>睡衣</span>
          <span>充电宝</span>
        </p>
      </div>
      <div class="nav">
        <p class="el-dropdown">
          <img src="./../../../assets/webIndex/fl.png">
          <span>商品分类</span>
        </p>
        <p @click="index">首页</p>
        <p @click="tryShoping">试用</p>
      </div>

    </div>
</template>

<script>
    export default {
        name: "appheader",
        data (){
          return {
            input:'',
            isLeve: false
          }
        },
      mounted() {
          let getVal = sessionStorage.getItem('getVal')
          if (getVal !== '') {
            this.input = getVal
          }else if(getVal === null) {
            console.log(getVal)
            this.input = ''
          }
      },
      methods:{
        changeVal(){
          if (this.input == ''){
            sessionStorage.removeItem('getVal')
            this.$router.go(0)
          }
        },
        search(){
          this.$router.push({path:'/ClientProduct'})
          if (this.input !== '') {
            sessionStorage.setItem('getVal',this.input)
            this.$router.go(0)
          }else{
            sessionStorage.removeItem('getVal')
          }
        },
        index(){
          this.$router.push('/ClientIndex')
        },
        tryShoping(){
          this.$router.push('/ClientProduct')
        }
      }
    }
</script>

<style scoped>
#appheader{
  width: 100%;
  line-height: 30px;
}
.boxMain{
  width: 100%;
  background: #fff2e6;
}
.main,.logoMain {
  width: 1200px;
  margin: 0 auto;
}
.main p{
  font-size: 14px;
  color: #333;
  text-align: right;

}
.main p span{
  height: 30px;
  margin-right: 30px;
}
.main p span:nth-of-type(1){
  color: #f28b1d;
}
.main p span img{
  display: inline-block;
  margin-right: 5px;
  vertical-align: sub;
}
.logoMain{
  position: relative;
  margin-top: 49px;
}
.logoMain p{
  display: inline-block;
}
.keyWord {
   margin-left:164px;
}
.keyWord span{
  font-size: 14px;
  color: #CCCCCC;
  margin-right: 20px;
}
.logoMain .searchMain{
  position: absolute;
  left: 388px;
  top: 32px;
}
.searchMain input{
  width: 450px;
  height: 50px;
  border-radius: 5px 0 0 5px;
  border: 1px solid #f28b1d;
  padding-left: 50px;
  border-right: 0;

}
.searchMain img{
  position: relative;
  top: 7px;
  left: 40px;
}
.searchMain button{
  width: 140px;
  height: 52px;
  border-radius: 0 5px 5px 0;
  background:#f28b1d;
  line-height: 52px;
  color: #fff;
  border: 0;
  margin-left: -6px;
  font-size: 17px;
  cursor: pointer;
}
.nav{
  width: 1200px;
  margin: 0 auto;
  margin-top: 50px;
  line-height: 60px;
}
.nav p{
  display: inline-block;
  font-size: 16px;
  color: #333333;
  width: 115px;
  text-align: center;
}
.nav .el-dropdown{
  width:240px;
  background:#f28b1d;
  border-radius: 5px 5px 0 0;
  text-align: center;
  color: #fff;
  font-size: 16px;
  cursor: pointer;
}
.el-dropdown img{
  vertical-align: sub
}
.navList{
  position: relative;
}
.navList ul{
  width: 240px;
  height: 490px;
  position: absolute;
  z-index: 111;
  top: 0;
  left:0;
  background: rgba(255,255,255,0.7);
}
.navList ul li{
  line-height:45px;
  width: 80%;
  margin: 4px auto;
  text-align: center;

}
.navList ul li img{
    vertical-align: sub;
    margin-right: 10px;
  }
</style>

<template>
    <div class="navLeft">
      <el-aside width="200">左侧导航</el-aside>
    </div>
</template>

<script>
    export default {
        name: "navLeft.vue",
        data (){
          return {
            msg: ''
          }
        },
      mounted() {
        if (this.msg) {
          this.msg = '导航'
        }
      }
    }
</script>

<style scoped>

</style>

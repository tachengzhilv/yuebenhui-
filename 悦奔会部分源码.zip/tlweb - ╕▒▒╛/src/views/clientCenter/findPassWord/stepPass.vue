<template>
    <div>
      <loginHead @isShow="isLogin"></loginHead>
      <div class="count">
        <onePass-step v-if="this.active === 1"></onePass-step>
        <twoPass-step v-if="this.active === 2"></twoPass-step>
        <threePass-step v-if="this.active === 3"></threePass-step>
        <div class="fromIphone">
          <p class="pwdBtn" @click="nextBtn">
            <img src="./../../../assets/reg/next.png">
          </p>
        </div>
        <div class="success" v-if="isShow">
          <div class="pwdRight">
            <img src="./../../../assets/reg/success.png">
            <p>重置成功，正在跳转中...</p>
          </div>
        </div>
      </div>
      <!-- 首页底部-->
      <div class="footer">
        <p>简体| 繁体| English| 常见问题| 隐私政策 ©</p>
        <p> ©2017-2020 XXX.COM 版权所有：桐璐网络科技有限公司 </p>
      </div>
    </div>
</template>

<script>
import onePassStep from '@/components/passWord/onePwd'
import twoPassStep from '@/components/passWord/twoPwd'
import threePassStep from '@/components/passWord/threePwd'
import loginHead from  './../../../components/loginHead'
    export default {
        name: "stepPass",
        components:{onePassStep,twoPassStep,threePassStep,loginHead},
        data() {
            return {
              active:1,
              isShow:false,
              isClient :true
            }
        },
        methods: {
          nextBtn(){
            if (this.active++ >2){
              this.active = 3;
              this.isShow = true;
              setTimeout(() => {
                this.$router.push({path: '/'})
              },2000)
            };
          },
          isLogin(data){
            console.log(data)
            this.isClient = data
          }
        }
    }
</script>

<style scoped>
  body{
    width: 100%;
    background:#fafafa;
  }

  .footer{
    width: 100%;
    margin-top: 140px;
  }
  .footer p{
    text-align: center;
    line-height: 27px;
    color: #666;
    font-size: 12px;
  }

  .count{
     background: url("./../../../assets/reg/bg.png") no-repeat;
     width: 1240px;
     height: 750px;
     margin: 0 auto;
     margin-top: 20px;
     background-size: 100% 100%;
     position: relative;

  }
  .pwdBtn {
    width: 380px;
    height: 60px;
    position: absolute;
    top: 570px;
    left: 33%;
  }
  .success{
    position: relative;
    z-index: 11;
    display: flex;
    display: -webkit-flex;
    justify-content:center;
    top: 45%;
  }
  .pwdRight{
    width: 220px;
    height: 220px;
    border-radius:10px;
    background: rgba(0,0,0,0.5);

  }
  .pwdRight img{
    width: 100px;
    height: 80px;
    margin: 45px 60px ;
  }
  .pwdRight p{
    color:#ffffff;
    font-size: 16px;
    line-height: 21px;
    text-align: center;
  }
</style>

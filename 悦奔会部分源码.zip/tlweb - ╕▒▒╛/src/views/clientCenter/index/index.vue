<template>
  <div class="index">
    <!--导航-->
    <div class="navList">
      <ul>
        <li>
          <img src="./../../../assets/webIndex/hz.png">
          <span>服饰精选</span>
        </li>
        <li>
          <img src="./../../../assets/webIndex/hz.png">
          <span>服饰精选</span>
        </li>
        <li>
          <img src="./../../../assets/webIndex/hz.png">
          <span>服饰精选</span>
        </li>
        <li>
          <img src="./../../../assets/webIndex/hz.png">
          <span>服饰精选</span>
        </li>
        <li>
          <img src="./../../../assets/webIndex/hz.png">
          <span>服饰精选</span>
        </li>
        <li>
          <img src="./../../../assets/webIndex/hz.png">
          <span>服饰精选</span>
        </li>
        <li>
          <img src="./../../../assets/webIndex/hz.png">
          <span>服饰精选</span>
        </li>
        <li>
          <img src="./../../../assets/webIndex/hz.png">
          <span>服饰精选</span>
        </li>
        <li>
          <img src="./../../../assets/webIndex/hz.png">
          <span>服饰精选</span>
        </li>
        <li>
          <img src="./../../../assets/webIndex/hz.png">
          <span>服饰精选</span>
        </li>
      </ul>
    </div>
    <!--右侧登录-->
    <div class="navListRight">
      <img src="./../../../assets/client/1.png" class="tx">
      <p class="fs">悦奔会欢迎您！</p>
      <a class="push">商家入驻</a>
      <el-tabs type="card" class="el_tab">
        <el-tab-pane label="中奖直播">
          <div class="wordSwiper">
            <ul>
              <li v-for="(item,index) in noticeList" :key = 'index' @mouseenter="Stop()" @mouseleave="Up()">
                <p @click="routerPush">{{item.item}}</p>
              </li>
              <!--<li>-->
                <!--<img src="./../../../assets/client/1.png">-->
                <!--<p>-->
                  <!--<span>136*****12 成功领取了</span>-->
                  <!--<i>雅诗兰黛口红420倾慕唇膏</i>-->
                <!--</p>-->
              <!--</li>-->
              <!--<li>-->
                <!--<img src="./../../../assets/client/1.png">-->
                <!--<p>-->
                  <!--<span>136*****12 成功领取了</span>-->
                  <!--<i>雅诗兰黛口红420倾慕唇膏</i>-->
                <!--</p>-->
              <!--</li>-->
              <!--<li>-->
                <!--<img src="./../../../assets/client/1.png">-->
                <!--<p>-->
                  <!--<span>136*****12 成功领取了</span>-->
                  <!--<i>雅诗兰黛口红420倾慕唇膏</i>-->
                <!--</p>-->
              <!--</li>-->
              <!--<li>-->
                <!--<img src="./../../../assets/client/1.png">-->
                <!--<p>-->
                  <!--<span>136*****12 成功领取了</span>-->
                  <!--<i>雅诗兰黛口红420倾慕唇膏</i>-->
                <!--</p>-->
              <!--</li>-->
              <!--<li>-->
                <!--<img src="./../../../assets/client/1.png">-->
                <!--<p>-->
                  <!--<span>136*****12 成功领取了</span>-->
                  <!--<i>雅诗兰黛口红420倾慕唇膏</i>-->
                <!--</p>-->
              <!--</li>-->

            </ul>
          </div>
        </el-tab-pane>
        <el-tab-pane label="体验师相关">
          <ul class="tyUl">
            <li>1111</li>
            <li>2222</li>
            <li>3333</li>
          </ul>
        </el-tab-pane>
        <el-tab-pane label="商家相关">
          <ul class="tyUl">
            <li>1111</li>
            <li>2222</li>
            <li>3333</li>
          </ul>
        </el-tab-pane>
      </el-tabs>
    </div>
    <!--banner-->
    <div class="banner">
      <div class="swiper-container">
        <div class="swiper-wrapper">
          <div class="swiper-slide">Slide 1</div>
          <div class="swiper-slide">Slide 2</div>
          <div class="swiper-slide">Slide 3</div>
        </div>
        <!-- 如果需要分页器 -->
        <div class="swiper-pagination"></div>
      </div>
    </div>
    <!--count-->
    <div class="count">
      <ul class="countUl">
        <li>
         <p>
           <img src="./../../../assets/client/shop.png">
           <span>
             <i>58888888</i>
             <i>已入驻商家</i>
           </span>
         </p>
        </li>
        <li>
          <p>
            <img src="./../../../assets/client/shop.png">
            <span>
             <i>58888888个</i>
             <i>已上线活动</i>
           </span>
          </p>
        </li>
        <li>
          <p>
            <img src="./../../../assets/client/shop.png">
            <span>
             <i>58888888位</i>
             <i>已获得商品的体验师</i>
           </span>
          </p>
        </li>
        <li>
          <p>
            <img src="./../../../assets/client/shop.png">
            <span>
             <i>58888888个</i>
             <i>发放商品个数</i>
           </span>
          </p>
        </li>
      </ul>
      <!--特别推荐-->
      <div class="spc">
        <div class="swiper-button-prev"></div><!--左箭头。如果放置在swiper-container外面，需要自定义样式。-->
        <div class="swiper-button-next"></div><!--右箭头。如果放置在swiper-container外面，需要自定义样式。-->
        <p class="spcImg">
          <img src="./../../../assets/client/spc.png">
          <span class="girlSPC" >特别推荐</span>
        </p>
        <div id="swiper-container">
          <div class="swiper-wrapper">
            <div class="swiper-slide">
              <img src="./../../../assets/client/1.png" class="countImg">
              <p class="bsImg">
                <img src="./../../../assets/webIndex/tm.png">
                <span>雅诗兰黛雅诗兰黛雅诗兰黛雅诗兰黛雅诗兰黛雅诗兰黛雅诗兰黛雅诗兰黛雅诗兰黛</span>
              </p>
              <p class="priceBtn">
                <span>270</span>
                <el-button class="btnSpc">立即体验</el-button>
              </p>
            </div>
            <div class="swiper-slide">
              <img src="./../../../assets/client/1.png" class="countImg">
              <p class="bsImg">
                <img src="./../../../assets/webIndex/tm.png">
                <span>雅诗兰黛雅诗兰黛雅诗兰黛雅诗兰黛雅诗兰黛雅诗兰黛雅诗兰黛雅诗兰黛雅诗兰黛</span>
              </p>
              <p class="priceBtn">
                <span>270</span>
                <el-button class="btnSpc">立即体验</el-button>
              </p>
            </div>
            <div class="swiper-slide">
              <img src="./../../../assets/client/1.png" class="countImg">
              <p class="bsImg">
                <img src="./../../../assets/webIndex/tm.png">
                <span>雅诗兰黛雅诗兰黛雅诗兰黛雅诗兰黛雅诗兰黛雅诗兰黛雅诗兰黛雅诗兰黛雅诗兰黛</span>
              </p>
              <p class="priceBtn">
                <span>270</span>
                <el-button class="btnSpc">立即体验</el-button>
              </p>
            </div>
            <div class="swiper-slide">
              <img src="./../../../assets/client/1.png" class="countImg">
              <p class="bsImg">
                <img src="./../../../assets/webIndex/tm.png">
                <span>雅诗兰黛雅诗兰黛雅诗兰黛雅诗兰黛雅诗兰黛雅诗兰黛雅诗兰黛雅诗兰黛雅诗兰黛</span>
              </p>
              <p class="priceBtn">
                <span>270</span>
                <el-button class="btnSpc">立即体验</el-button>
              </p>
            </div>
            <div class="swiper-slide">
              <img src="./../../../assets/client/1.png" class="countImg">
              <p class="bsImg">
                <img src="./../../../assets/webIndex/tm.png">
                <span>雅诗兰黛雅诗兰黛雅诗兰黛雅诗兰黛雅诗兰黛雅诗兰黛雅诗兰黛雅诗兰黛雅诗兰黛</span>
              </p>
              <p class="priceBtn">
                <span>270</span>
                <el-button class="btnSpc">立即体验</el-button>
              </p>
            </div>
            <div class="swiper-slide">
              <img src="./../../../assets/client/1.png" class="countImg">
              <p class="bsImg">
                <img src="./../../../assets/webIndex/tm.png">
                <span>雅诗兰黛雅诗兰黛雅诗兰黛雅诗兰黛雅诗兰黛雅诗兰黛雅诗兰黛雅诗兰黛雅诗兰黛</span>
              </p>
              <p class="priceBtn">
                <span>270</span>
                <el-button class="btnSpc">立即体验</el-button>
              </p>
            </div>
          </div>
        </div>

      </div>
      <!--女装专区-->
      <div class="girlZone">
        <p class="spcImg">
          <span class="routerLeft">
            <img src="./../../../assets/client/nv.png">
            <span class="girlSPC">女装专区</span>
          </span>
          <Span class="routerRight">→</Span>
        </p>
        <div class="girlCount">
          <div class="girlLeft">
             <div>
               <img src="./../../../assets/client/1.png" class="leftIMG">
               <p class="tit">每日新品》</p>
             </div>
            <div class="tab">
              <ul class="tabUl">
                <li>
                  <span>
                     <img src="./../../../assets/client/2.png" class="ulImg">
                  </span>
                  <span class="ulSpan">
                    <i>预售韩都衣舍2019韩版女装夏装新款</i>
                    <i>
                      <i>￥103.00</i>
                      <a>立即体验</a>
                    </i>
                  </span>
                </li>
                <li>
                  <span>
                     <img src="./../../../assets/client/2.png" class="ulImg">
                  </span>
                  <span class="ulSpan">
                    <i>预售韩都衣舍2019韩版女装夏装新款</i>
                    <i>
                      <i>￥103.00</i>
                      <a>立即体验</a>
                    </i>
                  </span>
                </li>
                <li>
                  <span>
                     <img src="./../../../assets/client/2.png" class="ulImg">
                  </span>
                  <span class="ulSpan">
                    <i>预售韩都衣舍2019韩版女装夏装新款</i>
                    <i>
                      <i>￥103.00</i>
                      <a>立即体验</a>
                    </i>
                  </span>
                </li>
              </ul>
            </div>
          </div>
          <div class="girlRight">
            <div class="rightCount">
               <div class="rightCountDiv">
                 <div class="rightCountLeft">
                   <p class="pImg">
                     <img src="./../../../assets/client/1.png">
                   </p>
                   <p class="pSpan">
                      <span>
                        <img src="./../../../assets/webIndex/tm.png">
                        <i> 韩语琳裙子女夏装2019新款</i>
                      </span>
                   </p>
                   <p class="pI">
                     <i>￥338.00</i>
                     <a>立即体验</a>
                   </p>
                 </div>
               </div>
            </div>
            <div class="rightCount">
              <div class="rightCountDiv">
                <div class="rightCountLeft">
                  <p class="pImg">
                    <img src="./../../../assets/client/1.png">
                  </p>
                  <p class="pSpan">
                      <span>
                        <img src="./../../../assets/webIndex/tm.png">
                        <i> 韩语琳裙子女夏装2019新款</i>
                      </span>
                  </p>
                  <p class="pI">
                    <i>￥338.00</i>
                    <a>立即体验</a>
                  </p>
                </div>
              </div>
            </div>
            <div class="rightCount">
              <div class="rightCountDiv">
                <div class="rightCountLeft">
                  <p class="pImg">
                    <img src="./../../../assets/client/1.png">
                  </p>
                  <p class="pSpan">
                      <span>
                        <img src="./../../../assets/webIndex/tm.png">
                        <i> 韩语琳裙子女夏装2019新款</i>
                      </span>
                  </p>
                  <p class="pI">
                    <i>￥338.00</i>
                    <a>立即体验</a>
                  </p>
                </div>
              </div>
            </div>
            <div class="rightCount">
              <div class="rightCountDiv">
                <div class="rightCountLeft">
                  <p class="pImg">
                    <img src="./../../../assets/client/1.png">
                  </p>
                  <p class="pSpan">
                      <span>
                        <img src="./../../../assets/webIndex/tm.png">
                        <i> 韩语琳裙子女夏装2019新款</i>
                      </span>
                  </p>
                  <p class="pI">
                    <i>￥338.00</i>
                    <a>立即体验</a>
                  </p>
                </div>
              </div>
            </div>
            <div class="rightCount">
              <div class="rightCountDiv">
                <div class="rightCountLeft">
                  <p class="pImg">
                    <img src="./../../../assets/client/1.png">
                  </p>
                  <p class="pSpan">
                      <span>
                        <img src="./../../../assets/webIndex/tm.png">
                        <i> 韩语琳裙子女夏装2019新款</i>
                      </span>
                  </p>
                  <p class="pI">
                    <i>￥338.00</i>
                    <a>立即体验</a>
                  </p>
                </div>
              </div>
            </div>
            <div class="rightCount">
              <div class="rightCountDiv">
                <div class="rightCountLeft">
                  <p class="pImg">
                    <img src="./../../../assets/client/1.png">
                  </p>
                  <p class="pSpan">
                      <span>
                        <img src="./../../../assets/webIndex/tm.png">
                        <i> 韩语琳裙子女夏装2019新款</i>
                      </span>
                  </p>
                  <p class="pI">
                    <i>￥338.00</i>
                    <a>立即体验</a>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>
      <!--男装-->
      <div class="girlZone">
        <p class="spcImg">
          <span class="routerLeft">
            <img src="./../../../assets/client/nv.png">
            <span class="girlSPC">女装专区</span>
          </span>
          <Span class="routerRight">→</Span>
        </p>
        <div class="girlCount">
          <div class="girlLeft">
            <div>
              <img src="./../../../assets/client/1.png" class="leftIMG">
              <p class="tit">每日新品》</p>
            </div>
            <div class="tab">
              <ul class="tabUl">
                <li>
                  <span>
                     <img src="./../../../assets/client/2.png" class="ulImg">
                  </span>
                  <span class="ulSpan">
                    <i>预售韩都衣舍2019韩版女装夏装新款</i>
                    <i>
                      <i>￥103.00</i>
                      <a>立即体验</a>
                    </i>
                  </span>
                </li>
                <li>
                  <span>
                     <img src="./../../../assets/client/2.png" class="ulImg">
                  </span>
                  <span class="ulSpan">
                    <i>预售韩都衣舍2019韩版女装夏装新款</i>
                    <i>
                      <i>￥103.00</i>
                      <a>立即体验</a>
                    </i>
                  </span>
                </li>
                <li>
                  <span>
                     <img src="./../../../assets/client/2.png" class="ulImg">
                  </span>
                  <span class="ulSpan">
                    <i>预售韩都衣舍2019韩版女装夏装新款</i>
                    <i>
                      <i>￥103.00</i>
                      <a>立即体验</a>
                    </i>
                  </span>
                </li>
              </ul>
            </div>
          </div>
          <div class="girlRight">
            <div class="rightCount">
              <div class="rightCountDiv">
                <div class="rightCountLeft">
                  <p class="pImg">
                    <img src="./../../../assets/client/1.png">
                  </p>
                  <p class="pSpan">
                      <span>
                        <img src="./../../../assets/webIndex/tm.png">
                        <i> 韩语琳裙子女夏装2019新款</i>
                      </span>
                  </p>
                  <p class="pI">
                    <i>￥338.00</i>
                    <a>立即体验</a>
                  </p>
                </div>
              </div>
            </div>
            <div class="rightCount">
              <div class="rightCountDiv">
                <div class="rightCountLeft">
                  <p class="pImg">
                    <img src="./../../../assets/client/1.png">
                  </p>
                  <p class="pSpan">
                      <span>
                        <img src="./../../../assets/webIndex/tm.png">
                        <i> 韩语琳裙子女夏装2019新款</i>
                      </span>
                  </p>
                  <p class="pI">
                    <i>￥338.00</i>
                    <a>立即体验</a>
                  </p>
                </div>
              </div>
            </div>
            <div class="rightCount">
              <div class="rightCountDiv">
                <div class="rightCountLeft">
                  <p class="pImg">
                    <img src="./../../../assets/client/1.png">
                  </p>
                  <p class="pSpan">
                      <span>
                        <img src="./../../../assets/webIndex/tm.png">
                        <i> 韩语琳裙子女夏装2019新款</i>
                      </span>
                  </p>
                  <p class="pI">
                    <i>￥338.00</i>
                    <a>立即体验</a>
                  </p>
                </div>
              </div>
            </div>
            <div class="rightCount">
              <div class="rightCountDiv">
                <div class="rightCountLeft">
                  <p class="pImg">
                    <img src="./../../../assets/client/1.png">
                  </p>
                  <p class="pSpan">
                      <span>
                        <img src="./../../../assets/webIndex/tm.png">
                        <i> 韩语琳裙子女夏装2019新款</i>
                      </span>
                  </p>
                  <p class="pI">
                    <i>￥338.00</i>
                    <a>立即体验</a>
                  </p>
                </div>
              </div>
            </div>
            <div class="rightCount">
              <div class="rightCountDiv">
                <div class="rightCountLeft">
                  <p class="pImg">
                    <img src="./../../../assets/client/1.png">
                  </p>
                  <p class="pSpan">
                      <span>
                        <img src="./../../../assets/webIndex/tm.png">
                        <i> 韩语琳裙子女夏装2019新款</i>
                      </span>
                  </p>
                  <p class="pI">
                    <i>￥338.00</i>
                    <a>立即体验</a>
                  </p>
                </div>
              </div>
            </div>
            <div class="rightCount">
              <div class="rightCountDiv">
                <div class="rightCountLeft">
                  <p class="pImg">
                    <img src="./../../../assets/client/1.png">
                  </p>
                  <p class="pSpan">
                      <span>
                        <img src="./../../../assets/webIndex/tm.png">
                        <i> 韩语琳裙子女夏装2019新款</i>
                      </span>
                  </p>
                  <p class="pI">
                    <i>￥338.00</i>
                    <a>立即体验</a>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>
</template>

<script>
  import Swiper from 'swiper';
    export default {
      name: "index",
      data (){
        return {
          msg: '试用中心',
          animate:false,
          intNum: undefined,
          noticeList:[
            {
              item:1
            },
            {
              item:2
            },
            {
              item:3
            },
            {
              item:4
            },
            {
              item:5
            },
            {
              item:6
            },
            {
              item:7
            },
            {
              item:8
            }
          ]
        }
      },
      mounted() {
        // 图片轮播
        let mySwiper = new Swiper ('.swiper-container', {
          loop: true,
          autoplay:true,
          // 如果需要分页器
          pagination: '.swiper-pagination'
        })
        //  特别推荐
        let swiper= new Swiper('#swiper-container',{
           navigation: {
             nextEl: '.swiper-button-next',
             prevEl: '.swiper-button-prev',
           },
           loop:false,
           slidesPerView: 3,
           spaceBetween: 30,
           slidesPerGroup: 1,
           freeMode :true,
           loopFillGroupWithBlank: true,
        })
        this.ScrollUp()
      },
      methods:{
        ScrollUp(){
          this.intNum = setInterval(()=>{
            this.animate = true;
            setTimeout(()=>{
              this.animate=false;
              this.noticeList.push(this.noticeList[0]);// 将数组的第一个元素添加到数组的
              this.noticeList.shift(); //删除数组的第一个元素
            },100)
          },1000)
        },
        //鼠标移上去停止
        Stop() {
          clearInterval(this.intNum);
        },
        Up() {
          this.ScrollUp();
        },
        routerPush(){

        }
      }
    }
</script>

<style scoped>
.index{
  /*position: relative;*/
  background: #fafafa;
}
.navList{
  width: 1200px;
  margin: 0 auto;
  /*margin-top: 289px;*/
  position: relative;
  z-index: 111;

}
.navList ul{
  width: 240px;
  margin-top: -4px;
  z-index: 111;
  background: rgba(255,255,255,0.7);
}
.navList ul li{
  line-height:45px;
  width: 80%;
  margin: 4px auto;
  text-align: center;

}
.navList ul li img{
  vertical-align: sub;
  margin-right: 10px;
}
.banner{
  width: 100%;
  position: absolute;
  background: goldenrod;
  height: 500px;
  top: 319px;
}
.count{
  width: 1200px;
  margin: 0 auto;
  margin-top: 22px;
  position: relative;
}
.countUl{
  width: 100%;
  display: flex;
}
.countUl li{
  height: 120px;
  flex: 1;
  margin-left: 20px;
  border-radius: 10px;
}
.countUl li:nth-of-type(1){
  background: #ffebeb;
}
.countUl li:nth-of-type(2){
  background: #fff7e5;
}
.countUl li:nth-of-type(3){
  background: #f5ffe5;
}
.countUl li:nth-of-type(4){
  background: #ebf4ff;
}
.countUl li p img{
  /*width: 44px;*/
  /*height: 44px;*/
  display: inline-block;
  margin-left: 62px;
  margin-top: 38px;
}
.countUl li p span{
  display: inline-block;
}
.countUl li p span i{
  display: block;
  margin-left: 17px;
}
.countUl li p span i:nth-of-type(1){
  color:#f28b1d ;
  font-size: 20px;
}
.countUl li p span i:nth-of-type(2){
  color:#888888 ;
  font-size:16px;
}
.spc {
  margin-top: 50px;
  position: relative;
}
.spcImg{
  margin-left: 20px;
  display: flex;
}
.spcImg .routerLeft{
  flex: 1;
}
.routerRight{
  width: 24px;
  height: 24px;
  border-radius:24px;
  border: 1px solid #f18c1d;
  font-size: 18px;
  line-height: 27px;
  font-weight: normal;
  color: #f18c1d;
  text-align: center;
  cursor: pointer;
}
.spcImg img{
  width: 32px;
  height: 32px;
  vertical-align: sub;
}
.spcImg .girlSPC{
  font-size: 28px;
  color: #f18b1e;
  margin-left: 11px;
}
#swiper-container{
  position: relative;
  overflow: hidden;
  list-style: none;
  padding: 0;
  z-index: 1;
  width: 90%;
  margin: 0 auto;
  margin-top: 24px;
}
#swiper-container .swiper-notification{
  position: absolute;
  left: 0;
  top: 0;
  pointer-events: none;
  opacity: 0;
  z-index: -1000;
}
#swiper-container .swiper-slide{
  width: 270px !important;
  border-radius: 15px;
  box-shadow: 1px 1px 6px 1px rgba(0, 0, 0, 0.59);
  margin-top: 20px;

}
.swiper-slide .countImg{
  width: 100%;
}

.swiper-button-prev, .swiper-container-rtl .swiper-button-next{
   background-image: url('./../../../assets/client/left.png');

 }
.swiper-button-next, .swiper-container-rtl .swiper-button-prev{
  background-image: url('./../../../assets/client/right.png')
}
.swiper-button-next, .swiper-button-prev{
  margin-top: 0;
  /*top: 68%;*/
}
.bsImg,.priceBtn{
  margin-top: 10px;
  width: 90%;
  margin: 0 auto;
}
.bsImg img{
  width:23px;
  height: 23px;
}
.bsImg span{
   overflow:hidden;
   text-overflow:ellipsis;
   white-space:nowrap;
   width: 200px;
   margin-left: 10px;
   font-size: 16px;
   color: #333;
}
.priceBtn{
   display: flex;
  justify-content: space-between;
  padding-bottom: 10px;
  margin-top: 10px;
}
.priceBtn span:nth-of-type(1){
   color: #f28b1d;
   font-size: 18px;
   line-height: 36px;
   text-decoration: line-through;
}
.btnSpc{
  height: 36px;
  border:1px solid #f28b1d;
  color: #f28b1d;
}
.btnSpc:focus, .btnSpc:hover,.pI a:hover,.ulSpan i a:hover,.push:hover{
  background: #f28b1d;
  color: #fff;
}
.girlZone {
  margin-top: 59px;
}
.girlCount{
  margin-top: 20px;
  display: flex;
  margin-left: 10px;
}
.girlCount .girlLeft{
  width: 380px;
}
.girlLeft .leftIMG{
  border-radius: 15px 15px 0 0 ;
  width: 100%;
  height: 300px
}
 .tit{
   width: 100%;
   height: 40px;
   line-height: 40px;
   background: #fde9d5;
   font-size: 18px;
   text-indent: 20px;
   line-height: 40px;
   color: #f28b1d;
   margin-top: -5px;
 }
.tab{
   border:1px solid #dddddd;
   border-top: 0;
   border-radius: 0px 0px 15px 15px;
}
.tab .tabUl li{
  height: 113px;
  border-bottom: 1px solid #dddd;
}
.tab .tabUl li{
  display: flex;
}
 .ulImg {
   width: 80px;
   height: 80px;
   margin-top: 12px;
   margin-left: 11px;
 }
 .ulSpan{
    flex: 1;
 }
.ulSpan i{
  display: block;
  margin-left:12px;
  margin-top: 14px;
  overflow:hidden;
  text-overflow:ellipsis;
  white-space:nowrap;
  width: 250px;
}
.ulSpan i:nth-of-type(2){
  display: flex;
  justify-content: space-between;
}
.ulSpan i i{
  text-decoration:line-through;
  color: #f28b1d;
  font-size: 18px;
  flex: 1;
}
.ulSpan i a,.push{
  width: 100px;
  height: 36px;
  border-radius: 5px;
  border:1px solid #f28b1d;
  color: #f28b1d;
  line-height: 38px;
  font-size: 14px;
  text-align: center;
  margin-top: 5px;
  cursor: pointer;
}
.tab .tabUl li:last-of-type{
  border-bottom: none;
}
.girlRight{
  flex: 1;
  display: flex;
  flex-wrap:wrap;
}
.rightCount{
   flex: 1;
  margin-left: 15px;

}
.rightCountDiv{
  width: 250px;
  border: 1px solid #ddd;
  border-radius: 15px;
  box-shadow: 1px 1px 6px 1px rgba(0, 0, 0, 0.59);
  margin-bottom: 15px;
  display: flex;
}
.pImg{
  width: 250px;
}
.pImg img{
  display: block;
  width: 100%;
}
.pSpan {
  width: 95%;
  margin: 0 auto;
  margin-top: 10px;
}
.pSpan img{
  width:20px;
  height: 20px;

}
.pSpan i{
  overflow:hidden;
  text-overflow:ellipsis;
  white-space:nowrap;
  width: 200px;
  font-size: 16px;
  display: inline-block;
  margin-left: 8px;
}
.pI {
  width: 95%;
  margin: 10px auto;
  display: flex;
}
.pI i{
  flex: 1;
  line-height: 36px;
  text-decoration: line-through;
  color: #f28b1d;
  font-size: 18px;
}
.pI a{
  width: 100px;
  height: 36px;
  line-height: 38px;
  text-align: center;
  border: 1px solid #f28b1d;
  border-radius: 5px;
  color:#f28b1d;
  font-size: 14px;
  cursor: pointer;
}
.navListRight{
  width: 300px;
  height: 430px;
  border-radius: 15px;
  background: #fff;
  position: absolute;
  right: 370px;
  top: 355px;
  z-index: 222;
}
.navListRight .tx{
  width: 80px;
  height: 80px;
  border-radius: 80px;
  margin: 15px auto;
  display: block;
}
.fs{
 font-size: 16px;
 text-align: center;
 color: #333333;
 line-height: 21px;
}
.push{
 margin: 10px auto;
 display: block;
}
.el_tab{
  width: 100%;

}
.wordSwiper{
   width: 100%;
   height: 180px;
   overflow: hidden;
 }

.wordSwiper ul li{
  width: 80%;
  margin: 0 auto;
  text-align: center;
  font-size: 18px;
  height: 50px;
  border-bottom: 1px dashed #eeeeee;
  display: flex;
  margin-top: 5px;
  cursor: pointer;
}
.wordSwiper ul li img{
  width: 35px;
  height: 35px;
  border-radius: 35px;
  margin-top:4px;
}
.wordSwiper ul li p{
  flex: 1;
  margin-left: 20px;
  text-align: left;
}
.wordSwiper ul li p span:nth-of-type(1){
  font-size:14px;
  color: #333333;
  display: block;
}
.wordSwiper ul li p i{
  font-size: 14px;
  color: #f28b1d;
  display: block;
}
.tyUl{
  width: 80%;
  margin: 0 auto;
}
.tyUl li{
  font-size: 14px;
  color: #666666;
  border-bottom: 1px solid #eeeeee;
  line-height: 44px;
}
</style>

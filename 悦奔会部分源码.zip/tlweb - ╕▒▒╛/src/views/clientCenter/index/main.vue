<template>
    <div class="index">
      <el-header></el-header>
      <div class="count">
        <router-view></router-view>
      </div>
      <el-footer></el-footer>
    </div>
</template>
<script>
  import elHeader from  './../CommonHeader/appheader'
  import elFooter from  './../CommonFooter/appFooter'
  export default {
      name: "main.vue",
      components:{elHeader,elFooter},
      data() {
          return {}
      },
      methods: {}
  }
</script>

<style scoped>
.index{
  background: #fafafa;
}
</style>

<template>
    <div>
      <div class="count">
        <div class="upCount">
          <p>您的位置:  首页 > 家具日用 > 北欧植物沙发靠垫办公室靠枕床头靠背汽车护腰靠垫抱枕套芯腰枕垫</p>
          <div class="flex">
            <div class="flex1">
              <img src="./../../../assets/client/1.png">
            </div>
            <div class="flex1">
              <p>
                <img src="./../../../assets/webIndex/tm.png">
                <span>北欧植物沙发靠垫办公室靠枕床头靠背护腰靠垫抱枕套芯腰枕垫靠背护腰靠垫抱枕套芯腰枕垫</span>
              </p>
              <div class="countFlex">
                <p class="time">
                  倒计时:02天12时23分
                </p>

              </div>
            </div>
            <div class="flex1"></div>
          </div>
        </div>
      </div>
    </div>
</template>

<script>
    export default {
        name: "searchDetail",
        data() {
            return {}
        },
        methods: {}

    }
</script>

<style scoped>

</style>

<template>
    <div class="index">
      <!--<el-header></el-header>-->
      <p class="countTit">您的位置:   首页 > 商品分类 > 服饰精选</p>
      <div class="count flex">
        <!--左侧-->
        <div class="countLeft ">
          <div class="countCard">
              <div class="serach">
                <p class="searchP">
                  <span class="pOne">试用平台：</span>
                  <span class="pTwo">
                    <span>全部</span>
                    <span>天猫</span>
                    <span>淘宝</span>
                  </span>
                </p>
                <p class="searchF" v-if="isShow">
                  <span class="pOne">商品分类：</span>
                  <span class="pTwo">
                    <span>全部</span>
                    <span>天猫</span>
                    <span>淘宝</span>
                    <span>全部</span>
                    <span>天猫</span>
                    <span>淘宝</span>
                    <span>全部</span>
                    <span>天猫</span>
                    <span>淘宝</span>
                    <span>全部</span>
                    <span>天猫</span>
                    <span>淘宝</span>
                    <span>全部</span>
                    <span>天猫</span>
                    <span>淘宝</span>
                    <span>全部</span>
                    <span>天猫</span>
                    <span>淘宝</span>
                    <span>全部</span>
                    <span>天猫</span>
                    <span>淘宝</span>
                    <span>全部</span>
                    <span>天猫</span>
                    <span>全部</span>
                    <span>天猫</span>
                    <span>淘宝</span>
                    <span>全部</span>
                    <span>天猫</span>
                    <span>淘宝</span>
                    <span>全部</span>
                    <span>天猫</span>
                    <span>淘宝</span>
                    <span>全部</span>
                    <span>天猫</span>
                    <span>淘宝</span>
                    <span>淘宝</span>
                  </span>
                </p>
                <p class="searchP">
                  <span class="pOne">排列顺序:</span>
                  <span class="pTwo">
                    <span>
                      <span>综合</span>
                      <span>上线时间</span>
                      <span>高人气</span>
                      <span>价格</span>
                      <span class="pinput">
                        <el-input v-model="input1"></el-input>
                        <i>-</i>
                        <el-input  v-model="input2"></el-input>
                      </span>
                       <span class="pBtn">
                        <el-button>确定</el-button>
                      </span>
                    </span>
                  </span>

                </p>
              </div>
              <div class="countDetail">
                <div class="flex countOne">
                  <div class="flex1 countONE">
                    <div class="element">
                      <img src="./../../../assets/client/1.png" class="figure">
                    </div>
                    <div class="qCode">
                      <img src="./../../../assets/client/2.png">
                      <p>扫一扫立即申请免费体验商品</p>
                    </div>
                    <p class="countP">
                      <img src="./../../../assets/webIndex/tm.png" class="tm">
                      <span class="esp">女神范儿大红色礼服吊带</span>
                    </p>
                    <p class="residue flex">
                      <span class="flex1">
                        <i>￥356.00</i>
                        <i>剩余10份</i>
                      </span>
                      <a>立即体验</a>
                    </p>
                  </div>
                  <div class="flex1 countONE">
                    <img src="./../../../assets/client/1.png" class="figure">
                    <p class="countP">
                      <img src="./../../../assets/webIndex/tm.png" class="tm">
                      <span class="esp">女神范儿大红色礼服吊带</span>
                    </p>
                    <p class="residue flex">
                      <span class="flex1">
                        <i>￥356.00</i>
                        <i>剩余10份</i>
                      </span>
                      <a>立即体验</a>
                    </p>
                  </div>
                  <div class="flex1 countONE">
                    <img src="./../../../assets/client/1.png" class="figure">
                    <p class="countP">
                      <img src="./../../../assets/webIndex/tm.png" class="tm">
                      <span class="esp">女神范儿大红色礼服吊带</span>
                    </p>
                    <p class="residue flex">
                      <span class="flex1">
                        <i>￥356.00</i>
                        <i>剩余10份</i>
                      </span>
                      <a @click="subDetail">立即体验</a>
                    </p>
                  </div>
                </div>
                <div class="flex countOne">
                  <div class="flex1 countONE">
                    <img src="./../../../assets/client/1.png" class="figure">
                    <p class="countP">
                      <img src="./../../../assets/webIndex/tm.png" class="tm">
                      <span class="esp">女神范儿大红色礼服吊带</span>
                    </p>
                    <p class="residue flex">
                      <span class="flex1">
                        <i>￥356.00</i>
                        <i>剩余10份</i>
                      </span>
                      <a>立即体验</a>
                    </p>
                  </div>
                  <div class="flex1 countONE">
                    <img src="./../../../assets/client/1.png" class="figure">
                    <p class="countP">
                      <img src="./../../../assets/webIndex/tm.png" class="tm">
                      <span class="esp">女神范儿大红色礼服吊带</span>
                    </p>
                    <p class="residue flex">
                      <span class="flex1">
                        <i>￥356.00</i>
                        <i>剩余10份</i>
                      </span>
                      <a>立即体验</a>
                    </p>
                  </div>
                  <div class="flex1 countONE">
                    <img src="./../../../assets/client/1.png" class="figure">
                    <p class="countP">
                      <img src="./../../../assets/webIndex/tm.png" class="tm">
                      <span class="esp">女神范儿大红色礼服吊带</span>
                    </p>
                    <p class="residue flex">
                      <span class="flex1">
                        <i>￥356.00</i>
                        <i>剩余10份</i>
                      </span>
                      <a>立即体验</a>
                    </p>
                  </div>
                </div>
                <div class="flex countOne">
                  <div class="flex1 countONE">
                    <img src="./../../../assets/client/1.png" class="figure">
                    <p class="countP">
                      <img src="./../../../assets/webIndex/tm.png" class="tm">
                      <span class="esp">女神范儿大红色礼服吊带</span>
                    </p>
                    <p class="residue flex">
                      <span class="flex1">
                        <i>￥356.00</i>
                        <i>剩余10份</i>
                      </span>
                      <a>立即体验</a>
                    </p>
                  </div>
                  <div class="flex1 countONE">
                    <img src="./../../../assets/client/1.png" class="figure">
                    <p class="countP">
                      <img src="./../../../assets/webIndex/tm.png" class="tm">
                      <span class="esp">女神范儿大红色礼服吊带</span>
                    </p>
                    <p class="residue flex">
                      <span class="flex1">
                        <i>￥356.00</i>
                        <i>剩余10份</i>
                      </span>
                      <a>立即体验</a>
                    </p>
                  </div>
                  <div class="flex1 countONE">
                    <img src="./../../../assets/client/1.png" class="figure">
                    <p class="countP">
                      <img src="./../../../assets/webIndex/tm.png" class="tm">
                      <span class="esp">女神范儿大红色礼服吊带</span>
                    </p>
                    <p class="residue flex">
                      <span class="flex1">
                        <i>￥356.00</i>
                        <i>剩余10份</i>
                      </span>
                      <a>立即体验</a>
                    </p>
                  </div>
                </div>
                <el-pagination
                  class="pagination"
                  background
                  @size-change="handleSizeChange"
                  @current-change="handleCurrentChange"
                  :current-page.sync="currentPage"
                  :page-size="100"
                  layout="total, prev, pager, next"
                  :total="1000">
                </el-pagination>
              </div>
          </div>
        </div>
        <!--右侧-->
        <div class="countRight flex1">
          <div class="recommanded">
            <p class="newRecommanded">最新推荐》</p>
             <ul class="ulRecommanded">
               <li>
                 <img src="./../../../assets/client/1.png" class="countDetailImg">
                 <p class="countP">
                   <img src="./../../../assets/webIndex/tm.png"  class="tm">
                   <span class="esp">kk2019新款女装春装复古荷叶kk2019新款女装春装复古荷叶</span>
                 </p>
                 <p class="countRightResidue flex">
                   <span class="flex1">229.00</span>
                   <a>立即体验</a>
                 </p>
               </li>
               <li>
                 <img src="./../../../assets/client/1.png" class="countDetailImg">
                 <p class="countP">
                   <img src="./../../../assets/webIndex/tm.png"  class="tm">
                   <span class="esp">kk2019新款女装春装复古荷叶kk2019新款女装春装复古荷叶</span>
                 </p>
                 <p class="countRightResidue flex">
                   <span class="flex1">229.00</span>
                   <a>立即体验</a>
                 </p>
               </li>
               <li>
                 <img src="./../../../assets/client/1.png" class="countDetailImg">
                 <p class="countP">
                   <img src="./../../../assets/webIndex/tm.png"  class="tm">
                   <span class="esp">kk2019新款女装春装复古荷叶kk2019新款女装春装复古荷叶</span>
                 </p>
                 <p class="countRightResidue flex">
                   <span class="flex1">229.00</span>
                   <a>立即体验</a>
                 </p>
               </li>
               <li>
                 <img src="./../../../assets/client/1.png" class="countDetailImg">
                 <p class="countP">
                   <img src="./../../../assets/webIndex/tm.png"  class="tm">
                   <span class="esp">kk2019新款女装春装复古荷叶kk2019新款女装春装复古荷叶</span>
                 </p>
                 <p class="countRightResidue flex">
                   <span class="flex1">229.00</span>
                   <a>立即体验</a>
                 </p>
               </li>
             </ul>

          </div>
        </div>
      </div>
    </div>

</template>

<script>
  import elHeader from  './../CommonHeader/appheader'
  import elFooter from  './../CommonFooter/appFooter'
    export default {
        name: "search_product",
        data() {
            return {
              input1:'',
              input2:'',
              isShow: false,
              currentPage: 1

            }
        },
        mounted(){
          let getVal = sessionStorage.getItem('getVal')
          console.log(getVal)
          if (getVal){
            this.isShow = false
          }else {
            this.isShow = true
          }
        },
        methods: {
          handleSizeChange(val) {
            console.log(`每页 ${val} 条`);
          },
          handleCurrentChange(val) {
            console.log(`当前页: ${val}`);
          },
          subDetail(){
            console.log(222)
            this.$router.push({path:'/ClientDeatil'})
          }

        }

    }
</script>

<style scoped>
.index{
  background:#fafafa;
  position: relative;
}
.countTit{
  font-size: 16px;
  color: #888;
  width: 1200px;
  margin: 0 auto;
  margin-top: 20px;
}
.count{
  width: 1200px;
  margin: 0 auto;
  margin-top: 20px;
}
.countLeft{
}
.countCard{
  width: 881px;
}
.serach{
 width:100%;
 border-radius: 15px;
 box-shadow: 1px 1px 6px 1px rgba(0, 0, 0, 0.5);
}
.searchP,.searchF{
 width: 95%;
 margin: 0 auto;
 padding-top: 20px;
 color: #888;
  display: flex;
  padding-bottom: 10px;
}
.searchP{
  padding-bottom: 20px;
}
.pOne{
  color: #333;
  font-size: 18px;
  line-height: 36px;
}
.pTwo {
  font-size: 16px;
  cursor: pointer;
  flex: 1;
}
.pTwo span{
  margin-left: 24px;
}
 .pinput .el-input{
   width:80px;
   height: 35px;
 }
 .pBtn .el-button{
   background: #f28b1d;
   color: #fff;
   width: 80px;
   height: 35px;
 }
 .countDetail{
   margin-top:30px ;
 }
 .countOne{
   margin-top: 20px;
 }
 .countONE{
   width: 280px;
   border:1px solid #dddddd;
   box-shadow: 1px 1px 6px 1px rgba(0, 0, 0, 0.59);
   border-radius: 15px;
   margin-left: 20px;
   position: relative;

 }
 .figure{
   width: 100%;
 }
 .countP{
   width: 90%;
   margin:10px auto
 }
 .tm {
   width: 20px;
   height: 20px;
 }
 .esp{
   overflow:hidden;
   text-overflow:ellipsis;
   white-space:nowrap;
   width: 200px;
   margin-left: 10px;
   font-size: 16px;
   color: #333;
 }
.residue{
  width: 90%;
  margin:10px auto;
}
 .residue span i{
   display: block;
 }
.residue span i:nth-of-type(1){
  text-decoration: line-through;
  color: #f28b1d;
  font-size: 18px;
}
.residue span i:nth-of-type(2){
  color: #666;
  font-size: 16px;
}
.residue a, .countRightResidue a{
  width:100px;
  height: 36px;
  line-height: 38px;
  color: #f28b1d;
  font-size: 16px;
  border: 1px solid #f28b1d;
  border-radius: 5px;
  text-align: center;
  cursor: pointer;
  margin-top: 5px;
}
.residue a:hover,.countRightResidue a:hover{
  background: #f28b1d;
  color: #fff;
}
.qCode{
  width: 273px;
  height: 260px;
  border-radius: 15px 15px 0px 0px;
  background: rgba(0,0,0,0.4);
  position: absolute;
  top: 0;
  left: 0;
  display: none;
  cursor: pointer;
}
.qCode img{
  width: 158px;
  height: 158px;
  margin-top: 40px;
  margin-left: 64px;
}
.qCode p{
  color: #ffffff;
  font-size: 18px;
  text-align: center;
  line-height: 40px;
}
.countONE:hover .qCode{
  display: block;
}
.countRight{
  margin-left: 20px;
  border: 1px solid #dddddd;
  border-radius: 10px;
  border-top: 0;
}
 .newRecommanded{
   width: 100%;
   height: 40px;
   line-height: 43px;
   background: #fde9d5;
   border-radius: 10px 10px 0 0 ;
   text-indent: 18px;
   color:#f28b1d;
   font-size: 20px;
 }
.ulRecommanded li{
  border-bottom: 1px solid #dddddd;
}
.ulRecommanded li:last-of-type{
  border-bottom:none
}
.ulRecommanded .countDetailImg{
  width: 270px;
  border-radius: 10px;
  margin: 10px auto;
  display: block;
}
.countRightResidue{
  width: 90%;
  margin: 10px auto;
}
.countRightResidue span{
   color: #f28b1d;
   text-decoration: line-through;
  line-height: 43px;
}
</style>

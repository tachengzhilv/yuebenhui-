<template>
  <div id="login">
    <loginHead @isShow="isLogin"></loginHead>
    <clientCenter v-if="isClient"></clientCenter>
    <shopCenter></shopCenter>
    <!-- 首页底部-->
    <div class="footer">
      <p> ©2017-2020 XXX.COM 版权所有：桐璐网络科技有限公司 </p>
    </div>
  </div>
</template>

<script>
  import loginHead from  './../components/loginHead'
  import shopCenter from  './shopCenter/shopLogin/shopLogin'
  import clientCenter from  './clientCenter/clientLogin/clientLogin'
  // import  elGt from  './../components/gt/gtlogin'
  export default {
    name: 'login',
    components:{loginHead,shopCenter,clientCenter},
    data () {
      return {
        isClient :false
      }
    },
    created () {
    },
    methods: {
      isLogin(data){
        console.log(data)
        this.isClient = data
      }
    }
  }
</script>
<style scoped>
body{
  width: 100%;
  background:#fafafa;
}
#login{
  position: relative;
}


.banner .el-carousel__item{
  display: block;
  width: 100%;
  height: 720px;
}
.el-carousel__item img{
  width: 100%;
}
.footer{
  width: 100%;
  margin-top: 140px;
}
.footer p{
  text-align: center;
  line-height: 27px;
  color: #666;
  font-size: 12px;
}


</style>


<template>
    <div id="appheader">
        <!-- 头部-->
      <div class="headMain">
        <div class="main">
          <p>
            <span class="index"><img src="./../../../assets/webIndex/index.png">首页</span>
            <span><img src="./../../../assets/webIndex/shop.png">商家中心</span>
          </p>
          <p>
            <span>欢迎您，<i>{{title}}</i><img src="./../../../assets/webIndex/index.png"></span>
            <span>退出</span>
          </p>
        </div>
      </div>
        <!-- 图片轮播-->
        <el-carousel class="shopIndex" arrow="never" indicator-position="none">
        <el-carousel-item v-for="(item,index) in this.swiper" :key="index">
          <img :src="item"/>
        </el-carousel-item>
      </el-carousel>
        <!--  logo   -->
        <div class="logo">
            <img src="./../../../assets/webIndex/logo.png">
            <span>商家中心</span>
        </div>
    </div>
</template>

<script>
    export default {
        name: "appheader",
        data (){
          return {
            title:'我是头部',
            token:'',
            swiper:[
              'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1556000436255&di=9978b94b118efaf3a893dbc3a1b7eeff&imgtype=0&src=http%3A%2F%2Fgss0.baidu.com%2F9vo3dSag_xI4khGko9WTAnF6hhy%2Flvpics%2Fh%3D800%2Fsign%3D975e8412d209b3def4bfe968fcbf6cd3%2Fdcc451da81cb39db77ed442cd3160924ab18309e.jpg',
              'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1556000436255&di=9978b94b118efaf3a893dbc3a1b7eeff&imgtype=0&src=http%3A%2F%2Fgss0.baidu.com%2F9vo3dSag_xI4khGko9WTAnF6hhy%2Flvpics%2Fh%3D800%2Fsign%3D975e8412d209b3def4bfe968fcbf6cd3%2Fdcc451da81cb39db77ed442cd3160924ab18309e.jpg',
              'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1556000436255&di=9978b94b118efaf3a893dbc3a1b7eeff&imgtype=0&src=http%3A%2F%2Fgss0.baidu.com%2F9vo3dSag_xI4khGko9WTAnF6hhy%2Flvpics%2Fh%3D800%2Fsign%3D975e8412d209b3def4bfe968fcbf6cd3%2Fdcc451da81cb39db77ed442cd3160924ab18309e.jpg'
            ],
          }
        },
      mounted() {
          this.title = sessionStorage.getItem('userTel')
      }
    }
</script>

<style scoped>
  #appheader{
    width: 100%;
  }
  .headMain {
    height: 30px;
    line-height: 30px;
    background: #fff2e6;
  }
  .main {
    width: 1200px;
    margin: 0 auto;
    display: flex;
  }
  .main p{
    font-size: 14px;
    color: #333;
    flex: 1;

  }
  .main p:nth-of-type(2){
    text-align: right;
  }
  .main p span{
    height: 30px;
    margin-right: 30px;
  }
  .main p:nth-of-type(1) span:nth-of-type(2){
    color: #f28b1d;
  }
  .main p span img{
    display: inline-block;
    margin-right: 5px;
    vertical-align: sub;
  }
  .main p:nth-of-type(2) span:nth-of-type(2){
    color: #888888;
  }
  .logo {
    width: 1200px;
    margin:0 auto;
    margin-top: 58px;
    display: flex;
  }
  .logo img{
    padding-top: 12px;
  }
  .logo span{
    font-size: 34px;
    color: #333;
    display: inline-block;
    padding: 42px 50px;
  }
</style>

<template>
    <div class="firstTab">
      <h3>发布试用</h3>
      <div style="margin-top: 30px">
        <ul class="uls">
          <li class="activit">第一步</li>
          <li>第二步</li>
          <li>第三步</li>
          <li>第四步</li>
          <li>第五步</li>
        </ul>
      </div>
      <div class="firstTab">
        <p class="labelTip">商品信息</p>
        <div class="firstShop">
          <el-form :model="ruleForm" :rules="rules" ref="ruleForm"  label-width="120px">
            <el-form-item label="选择平台:" prop="radio">
              <el-radio-group v-model="ruleForm.radio">
                <el-radio label="1">天猫</el-radio>
                <el-radio label="5">淘宝</el-radio>
              </el-radio-group>
            </el-form-item>
            <el-form-item  label="店铺地址:" prop="address">
              <el-input v-model="ruleForm.address" @input="getAddress"></el-input>
            </el-form-item>
            <div class="btn">
              <img src="./../../../assets/webIndex/next.png" @click="next" v-if="isShow"/>
              <img src="./../../../assets/webIndex/nextDisabled.png" v-else/>
            </div>
          </el-form>
        </div>
      </div>
    </div>
</template>

<script>
    export default {
        name: "firstTab",
        data() {
            return {
              ruleForm:{
                radio: '1',
                address: ''
              },
              isShow:true,
              shopName: "",
              rules:{
                radio:[
                  { required: false,message: '请选择平台', trigger: 'change'}
                ],
                address:[
                  { required: false,message: '请输入合理的地址', trigger: 'blur'}
                ],
              }
            }
        },
      mounted(){
          // let firstTab = JSON.parse(sessionStorage.getItem('objFirst'))
          //   console.log(firstTab)
          //   if (firstTab !== null) {
          //     this.ruleForm.radio = firstTab.radio;
          //     this.ruleForm.address = firstTab.address
          //   }else{
          //      return false
          //   }
        },
        methods: {
          /***  输入地址获取店铺信息  ***/
          getAddress(){
            this.$http.post('/apicreep/getShopUrl', {url:this.ruleForm.address}).then((res)=>{
              console.log(res )
              if (res.code == 1) {
                this.shopName = res.datas.vendorName
                let product = res.datas.itemName
                console.log(res)
                sessionStorage.setItem('shopName',this.shopName )
                sessionStorage.setItem('product',product)
                this.isShow=true
              }else {
                this.$message(res.message)
                this.isShow=false
              }
            }).then((err)=>{
              console.log(err)
            })
          },
          next(){
            // console.log(1)
            this.$refs.ruleForm.validate((valid )=>{
              if (valid) {
                let objFirst = {
                  radio:this.ruleForm.radio,
                  address: this.ruleForm.address,
                }
                let objFirstTab=JSON.stringify(objFirst)
                sessionStorage.setItem('objFirst',objFirstTab)
                this.isShow=true
                this.$router.push({path:'/SecondTabs'})
              }else{
                  this.isShow=false
              }
            })
          }
        }

    }
</script>

<style scoped>
  .uls{
    width: 98%;
    border-bottom: 1px solid #dddddd;
    margin-top: 10px;
  }
  .uls li{
    width: 78px;
    height: 36px;
    line-height: 36px;
    border-radius: 5px 5px 0px 0px;
    display: inline-block;
    margin-left: 11px;
    background: #f2f2f2;
    text-align: center;
    cursor: pointer;
  }
  .activit{
    background: #f28b1d !important;
    color: #fff;
  }
  .btn{
    display: flex;
    justify-content: center;
    margin: 70px auto;
    cursor: pointer;
  }
  .btn img{
    margin-left: 50px;

  }
</style>

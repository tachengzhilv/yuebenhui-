  <template>
    <div>
      <h3>发布使用</h3>
      <div style="marign-top:30px">
        <ul class="uls">
          <li @click="firstTab">第一步</li>
          <li @click="secondTab">第二步</li>
          <li @click="thirdTab">第三步</li>
          <li @click="fourthTab">第四步</li>
          <li class="activit">第五步</li>
        </ul>
      </div>
      <div class="firstTab">
        <p class="labelTip">费用计算</p>
        <div class="state">
          <p>
            <span>商品担保金:</span>
            <span>{{totalMoney}}元</span>
            <span> （商品担保金=下单金额*份数）</span>
          </p>
          <p>
            <span>试用服务费:</span>
            <span> {{merchant_trys}}积分</span>
            <span v-for=" item in merchant_try">（试用服务费=<i>{{item.merchant_try}}</i>积分*份数）</span>
          </p>
          <p>
            <span>增值服务费:</span>
            <span>{{total}} 积分</span>
          </p>
          <div class="btn">
            <!--<img src="./../../assets/webIndex/save.png"/>-->
            <img src="./../../../assets/webIndex/next.png" v-if='isShow' @click="outerVisible = true"/>
          </div>
          <i class="sweettip">*温馨提示：当17点前提交的活动，当日审核；17点之后，次日审核</i>
          <!--<p v-show="false">{{canmoney}}</p>-->
          <!--<p v-show="false">{{integral}}</p>-->
        </div>
      </div>
      <div class="tips">
        <p class="ps">试用服务费明细：</p>
        <div class="tipsFoot">
          <p>1.自动返款：体验者完成试用后，平台将直接使用商家活动费用操作返款给体验者（商家无需耗费时间人力处理退款，省时省力）</p>
          <p>2.精准投放</p>
          <p>3.默认五星好评</p>
          <p>4.普通文字好评</p>
          <p>5.防IP重复，防小号</p>
          <p>6.禁止老用户中奖</p>
          <p>7.自动过滤黑名单</p>
        </div>
      </div>
      <el-dialog class="el_dialog" title="请确认填写信息是否无误" center width="55%" :visible.sync="outerVisible">
        <div class="demoLog">
           <p>
             <span>平台:</span>
             <span v-if="platform_id == 1"> 天猫</span>
             <span v-else> 淘宝</span>
           </p>
          <p>
            <span>店铺:</span>
            <span>{{shop}}</span>
          </p>
          <p>
            <span>商品标题:</span>
            <span>{{title}}</span>
          </p>
          <p>
            <span>商品链接:</span>
            <el-input v-model="shopURL" style="width:60%;"  :disabled="true"></el-input>
            <el-button v-clipboard:copy="shopURL"
                       v-clipboard:success="onCopy"
                       v-clipboard:error="onError">复制</el-button>
          </p>
          <p>
            <span>展示图片:</span>
            <img :src="urlOne" style="vertical-align: middle;">
          </p>
          <p>
            <span>规格:</span>
            <span>{{spec}}</span>
          </p>
          <p>
            <span>下单价格:</span>
            <span>{{lower_price}}元</span>
          </p>
          <p>
            <span>显示价格:</span>
            <span>{{display_price}}元</span>
          </p>
          <p>
            <span>份数:</span>
            <span>{{amount}}</span>
          </p>
          <p>
            <span>开始时间:</span>
            <span>{{start_timeOr}}</span>
          </p>
          <p>
            <span>活动持续天数:</span>
            <span>{{day}}</span>
          </p>
          <p>
            <span>下单类型:</span>
            <span>{{lower_Name}}</span>
          </p>
          <p>
            <span>结果提示图:</span>
            <img :src="urlTwo" style="vertical-align: middle;">
          </p>
          <p>
            <span>搜索关键词:</span>
            <span v-for="item in listArr "> {{item.keyword}}</span>
          </p>
          <p>
            <span>商家要求:</span>
            <span v-html="ask" class="imgs">{{ask}}</span>
          </p>
          <p>
            <span>增值服务:</span>
            <span v-for="item in servicesName">{{item}}  </span>
          </p>
          <p>
            <span>费用计算:</span>
            <span>合计:{{totalMoney}}元，{{totalintegral}}积分</span>
          </p>
        </div>
        <el-dialog
          width="50%"
          title='支付金额'
          center
          :visible.sync="innerVisible"
          append-to-body>
          <div class="count">
            <div>
              支付密码：
              <el-input
                placeholder="请填写支付密码"
                v-model="input2">
              </el-input>
            </div>
            <el-button>支付密码</el-button>
          </div>
        </el-dialog>
        <div slot="footer" class="dialog-footer">
          <el-button @click="subEdit">修改</el-button>
          <el-button type="primary" @click="sureBtn">提交</el-button>
        </div>
      </el-dialog>
    </div>
</template>

<script>
    export default {
        name: "fifth.vue",
        data() {
            return {
              isShow:true ,
              merchant_try: [],
              merchant_trys: '',
              totalMoney:'',
              total: '',
              outerVisible: false,
              innerVisible: false,
              platform_id: '',
              shopURL: '',
              shop_id: '',
              shop: '',
              merchant_liaison_id: '',
              title: '',
              productName: '',
              class_id:'',
              urlOne: '',
              spec: '',
              lower_price: '',
              display_price: '',
              amount: '',
              start_timeOr: '',
              day: '',
              product_details: '',
              lower_type: '',
              lower_Name: '',
              typeTwo: '',
              urlTwo: '',
              typeThree: '',
              urlThree: '',
              searchKeywords: {},
              ask:'',
              Zname: {},
              order_status: '',
              ensure_price: '',
              tryout_price: '',
              service_price: '',
              listArr:[],
              serviceList: [],
              servicesName:[],
              canmoney: '',
              integral:'',
              time:'',
              share: '',
              sex: '',
              FourthkeyWords: '',
              totalintegral : '',
              input2:''
            }

        },
        mounted(){
          this.allTotal()
            this.jifenRes()

            let objScound = JSON.parse(sessionStorage.getItem('objSecond'))
            this.totalMoney = objScound.order * objScound.num
            this.total = sessionStorage.getItem('total')
            let  objFirst = JSON.parse(sessionStorage.getItem('objFirst'))
            let objthirdTab = JSON.parse(sessionStorage.getItem('objthirdTab'))
            this.platform_id = objFirst.radio;
            this.shopURL = objFirst.address;
            this.shop_id = sessionStorage.getItem('shop1');
            this.shop = sessionStorage.getItem('shopName')
            this.title = objScound.tit;
            this.productName = sessionStorage.getItem('product');
            this.class_id  = sessionStorage.getItem('classId')
            this.urlOne =objScound.imageDataUrl;
            this.spec = objScound.spe;
            this.lower_price = objScound.order
            this.display_price = objScound.showMoney;
            this.amount  = objScound.num;
            this.start_timeOr = objScound.time;
            this.day = objScound.date;
            this.product_details = objScound.count;
            this.lower_type  = sessionStorage.getItem('orderStyle');
            this.urlTwo =objthirdTab.thirdImg
            this.urlThree = objthirdTab.thirdImgs
            this.searchKeywords = JSON.parse(sessionStorage.getItem('objThird'))
            this.ask = objthirdTab.require;
            let objFourth = JSON.parse(sessionStorage.getItem('objFourth'))
            this.time = objFourth.time;
            this.sex = objFourth.sexs;
            this.FourthkeyWords = sessionStorage.getItem('FourthkeyWords')
            // 关键词
            this.listArr = JSON.parse(sessionStorage.getItem('listAyy'))
            this.serviceList = JSON.parse(sessionStorage.getItem('sessionFourth'))
            this.$http.post('/merchant/terrace/serviceNumber',{}).then(res => {
                if (res.code == 1) {
                   console.log(res.datas)
                  for (let  i = 0; i<res.datas.length; i++) {
                     for (let z = 0;z<this.serviceList.length;z++) {
                       if (res.datas[i].id == this.serviceList[z]){
                         this.servicesName.push(res.datas[i].name)
                         console.log(this.servicesName)
                       }
                     }
                  }
                }
            })
            // 判断下单类型
            this.$http.post('/common/getCacheEnums',{
              key:'lower_type'
            }).then(res=>{
              if (res.code == 1) {
                console.log(res)
                res.datas.find(item => {
                  if (item.id == this.lower_type) {
                    this.lower_Name = item.element_value
                  }
                })
              }else{
                this.$message.error(res.message)
              }

            })

          // if (this.totalMoney < this.canmoney ) {
          //   this.$message.error('您的余额不足，请及时充值')
          // }
        },
        methods: {
          firstTab(){
            this.$router.push({path:'/FirstTabs'})
          },
          secondTab(){
            this.$router.push({path:'/SecondTabs'})
          },
          thirdTab(){
            this.$router.push({path:'/ThirdTabs'})
          },
          fourthTab(){
            this.$router.push({path:'/FourthTabs'})
          },
          jifenRes(){
              this.$http.post('/merchant/terrace/FormatOfCalculation',{}).then(res =>{
                console.log(res)
                if (res.code == 1) {
                  this.merchant_try = res.datas
                  this.merchant_try.map(item => {
                    console.log(item)
                    this.merchant_trys = item.merchant_try * this.amount
                  })
                }else {
                  this.$message.error(res.message())
                }
              }).catch(err =>{
                console.log(err)
              })
          },
          allTotal(){
            this. jifenRes();
            this.$http.post('/merchant/uniparteds/datum' ,{}).then(res => {
              if (res.code == 1) {
                console.log(res)
                for (let i= 0; i<res.datas.length;i++) {
                  this.canmoney = res.datas[i].can_money
                  this.integral = res.datas[i].integral
                  // 判断金额不足
                  console.log(Number(this.totalMoney))
                  console.log(this.merchant_trys)
                  this.totalintegral = Number(this.merchant_trys)+Number(this.total)
                  console.log(this.totalintegral)
                  if (Number(this.totalMoney) > Number(this.canmoney) ) {
                    this.$message.error('您的余额不足，请及时充值')
                    this.isShow = false
                    return false
                  }else {
                    this.isShow = true
                  }
                  if ( this.totalintegral > this.integral) {
                    this.$message.error('您的积分不足')
                    this.isShow = false
                    return false
                  }else {
                    this.isShow = true
                  }
                }
              }
            })
          },
          // 点击修改跳转
          subEdit(){
            this.outerVisible  = false
            this.$router.push('/FirstTabs')
          },
          onCopy () {
            this.$message({
              message: `复制成功！`,
              type: 'success'
            });
            //this.snackBar.info(this.$t('prompt.copySuccess'))
          },
          onError () {
            this.$message.error(this.$t('prompt.copyFail'))
          },
          sureBtn(){
            this.$http.post('/merchant/terrace/updateMessage' ,{
              platform_id: this.platform_id,
              shop_id: this.shop_id,
              title: this.title,
              productName: this.productName,
              class_id: this.class_id,
              urlOne :this.urlOne,
              spec: this.spec,
              lower_price :this.lower_price,
              display_price: this.display_price,
              amount :this.amount,
              start_timeOr: this.start_timeOr,
              day: this.day,
              product_details: this.product_details,
              lower_type : this.lower_type,
              urlTwo: this.urlTwo,
              urlThree: this.urlThree,
              searchKeywords: JSON.stringify(this.searchKeywords),
              ask: this.ask,
              merchantOrderServiceEven:JSON.stringify(this.serviceList),
              time: this.time,
              ensure_price: this.totalMoney,
              tryout_price:this.merchant_trys,
              service_price : this.total,
              additional_logo: this.FourthkeyWords

            }).then(res =>{
              console.log(res)
              if (res.code == 1) {
                this.innerVisible = true
                sessionStorage.removeItem('objSecond')
                sessionStorage.removeItem('total')
                sessionStorage.removeItem('objFirst')
                sessionStorage.removeItem('objthirdTab')
                sessionStorage.removeItem('shop1')
                sessionStorage.removeItem('shopName')
                sessionStorage.removeItem('product')
                sessionStorage.removeItem('classId')
                sessionStorage.removeItem('orderStyle')
                sessionStorage.removeItem('objThird')
                sessionStorage.removeItem('objFourth')
                sessionStorage.removeItem('FourthkeyWords')
                sessionStorage.removeItem('listAyy')
                sessionStorage.removeItem('sessionFourth')
                sessionStorage.removeItem('objFourths')
                sessionStorage.removeItem('className')
              }
            }).catch(err =>{
              console.log(err)
            })
          }
        }

    }
</script>

<style scoped>
  .uls{
    width: 98%;
    border-bottom: 1px solid #dddddd;
    margin-top: 10px;
  }
  .uls li{
    width: 78px;
    height: 36px;
    line-height: 36px;
    border-radius: 5px 5px 0px 0px;
    display: inline-block;
    margin-left: 11px;
    background: #f2f2f2;
    text-align: center;
    cursor: pointer;
  }
  .activit{
    background: #f28b1d !important;
    color: #fff;
  }
  .state{
    width: 500px;
    margin: 0 auto;
    margin-top: 53px;
  }
  .state p{
    font-size: 18px;
    color: #666;
    margin-top: 18px;
  }
  .state span:nth-of-type(2){
    color: #f28b1d;
    margin-left: 5px;
  }
.sweettip{
  color: #f28b1d;
  font-size: 12px;
  text-align: center;
  display: block;
}

  .btn{
    display: flex;
    justify-content: center;
    margin: 70px auto;
    margin-bottom: 10px;
  }
  .btn img{
    margin-left: 50px;

  }
.tips{
  width: 900px;
  margin-top: 50px;
  border: 1px solid #fff2e6;
  border-radius: 5px;
  margin-left: 10px;
}
.ps{
  line-height: 37px;
  border-bottom: 1px solid #eeeeee;
  font-size: 16px;
  color: #000;
  padding-left: 10px;
}
.tipsFoot p{
  border-bottom: 1px solid #eeeeee;
  line-height: 35px;
  padding-left: 15px;
  color: #666666;
  font-size: 14px;
}

.demoLog{
  width: 90%;
  border: 1px solid #f28b1d;
  border-radius: 10px;
  margin: 0 auto;
}
.demoLog p{
  width: 90%;
  margin: 0 auto;
  line-height: 45px;
}
.count{
  height: 300px;
}

</style>

<template>
    <div>
      <h3>发布试用</h3>
      <div class="secondtTab">
        <ul class="uls">
          <li @click="firstTab">第一步</li>
          <li class="activit">第二步</li>
          <li>第三步</li>
          <li>第四步</li>
          <li>第五步</li>
        </ul>
        <div class="firstTab" >
          <p class="labelTip">平台信息</p>
          <div class="firstShop">
            <el-form :model="ruleForm" :rules="rules" ref="ruleForm"  label-width="120px">
              <el-form-item label="选择店铺:" prop="shop">
                <el-select v-model="ruleForm.shop" placeholder="请选择" @change="shopSelect">
                  <el-option
                    v-for="item in shopOption"
                    :key="item.id"
                    :label="item.shop_name"
                    :value="item.id">
                  </el-option>
                </el-select>
              </el-form-item>
              <el-form-item label="商家QQ:" prop="qq">
                <el-input v-model="ruleForm.qq" :disabled="true"></el-input>
              </el-form-item>
              <el-form-item label="商品标题:" prop="tit">
                <el-input v-model="ruleForm.tit" placeholder="请输入商品标题"></el-input>
              </el-form-item>
              <el-form-item label="平台分类:" prop="class">
                <el-select v-model="ruleForm.class" placeholder="请选择" @change="terraceClass" >
                  <el-option
                    v-for="item in shopClass"
                    :key="item.id"
                    :label="item.name"
                    :value="item.id">
                  </el-option>
                </el-select>
              </el-form-item>
              <el-form-item label="展示图片:" prop="imageUrl">
                <el-upload
                  class="avatar-uploader"
                  action="http://upload-z2.qiniup.com"
                  :data="qn"
                  :show-file-list="false"
                  :on-success="handleAvatarSuccess"
                  :before-upload="beforeAvatarUpload">
                  <img v-if="ruleForm.imageUrl" :src="ruleForm.imageUrl" class="avatar">
                  <i v-else class="el-icon-plus avatar-uploader-icon">
                    <p class="uploadTip">上传照片</p>
                    <p class="uploadAsk">图片要求400*400，不能出现图片留白、拼接、水印、logo</p>
                  </i>
                </el-upload>
              </el-form-item>
              <el-form-item label="规格:" prop="spe">
                <el-input v-model="ruleForm.spe" style="width: 220px" placeholder="不填写自动默认可拍任何规格"></el-input>
              </el-form-item>
              <el-form-item label="下单金额:" prop="order">
                <el-input v-model="ruleForm.order"  style="width: 220px" placeholder="请输入商品下单金额"></el-input>
                <i style="font-size: 14px;color: #666666">元</i>
              </el-form-item>
              <el-form-item label="显示金额:" prop="showMoney">
                <el-input v-model="ruleForm.showMoney"  style="width: 220px" placeholder="请输入商品搜索显示金额"></el-input>
                <i style="font-size: 14px;color: #666666">元</i>
              </el-form-item>
              <el-form-item label="份数:" prop="num">
                <el-input v-model="ruleForm.num"  style="width: 220px" placeholder="请输入试用份数"></el-input>
                <i style="font-size: 14px;color: #666666">份</i>
              </el-form-item>
              <el-form-item label="开始时间:" >
                <el-date-picker
                  v-model="ruleForm.time"
                  type="datetime"
                  @change="getTime"
                  placeholder="选择日期时间">
                </el-date-picker>
              </el-form-item >
              <el-form-item label="活动天数:" prop="data">
                <el-input v-model="ruleForm.date"  style="width: 220px" placeholder="请输入活动天数"></el-input>
                <i style="font-size: 14px;color: #666666">天</i>
              </el-form-item>
              <el-form-item  label="详情:" prop="count">
                <div class="edit_container">
                  <quill-editor
                    v-model="ruleForm.count"
                    ref="myQuillEditor"
                    class="editer"
                    :options="editorOption"
                    @change="onEditorChange($event)"
                    @ready="onEditorReady($event)">
                  </quill-editor>
                </div>
              </el-form-item>
            </el-form>

          </div>
        </div>
        <div class="btn">
          <img src="./../../../assets/webIndex/next.png" @click="next(ruleForm)" v-if="isShow"/>
          <img src="./../../../assets/webIndex/nextDisabled.png" v-else/>
        </div>
      </div>
    </div>
</template>

<script>
  import {quillEditor} from 'vue-quill-editor' //调用编辑器
  import 'vue-quill-editor/node_modules/quill/dist/quill.core.css';
  import 'vue-quill-editor/node_modules/quill/dist/quill.snow.css';
  import  'vue-quill-editor/node_modules/quill/dist/quill.bubble.css'
  export default {
        name: "secondTab",
        components: {quillEditor},
        data() {
            return {
              ruleForm:{
                shop: '',
                qq: '',
                tit: '',
                class: '',
                imageUrl: '',
                spe:'',
                order:'',
                showMoney: '',
                num:'',
                time: '',
                date: '',
                count: '',
              },
              count:'',
              editorOption: {
                modules:{
                  toolbar:[
                    ['bold', 'italic', 'underline', 'strike','image'],        // toggled buttons
                    ['blockquote', 'code-block'],
                    [{ 'align': [] }],
                    [{ 'color': [] }, { 'background': [] }],
                    [{ 'header': [1, 2, 3, 4, 5, 6, false] }],     //几级标题
                  ]
                }
              },
              isShow:true,
              rules: {
                shop: [
                  {required: true, message: '请选择平台', trigger: 'change'}
                ],
                qq: [
                  {required: true, message: '请填写商家qq', trigger: 'blur'}
                ],
                tit: [
                  {required: true, message: '请填写商品标题', trigger: 'blur'}
                ],
                class: [
                  {required: true, message: '请选择商品分类', trigger: 'blur'}
                ],
                imageUrl: [
                  {required: true, message: '请上传图片', trigger: 'change'}
                ],
                order: [
                  {required: true, message: '请填写下单金额', trigger: 'blur'}
                ],
                showMoney: [
                  {required: true, message: '请填写显示金额', trigger: 'blur'}
                ],
                num: [
                  {required: true, message: '请输入份数', trigger: 'blur'}
                ],
                time: [
                  {required: true, message: '请输入活动开始时间', trigger: 'blur'}
                ],
                date: [
                  {required: true, message: '请输入活动天数', trigger: 'blur'}
                ],
                count: [
                  {required: true, message: '请输入详细内容', trigger: 'change'}
                ]

              },
              shopOption:[],
              shopClass: [],
              shopId: '',
              qn:{
                token: ''
              }
            }
        },
        computed: {
          editor() {
            return this.$refs.myQuillEditor.quill
          }
        },
        mounted(){
          this.shopList();
          this.terraceClass();
          this.getQiniuToken();
          let objSecond = JSON.parse(sessionStorage.getItem('objSecond'))
          if (objSecond) {
            this.ruleForm.shop  = sessionStorage.getItem('shop')
            this.ruleForm. qq = objSecond.qq
            this.ruleForm.tit = objSecond.tit
            this.ruleForm.class = sessionStorage.getItem('className')
            this.ruleForm.imageUrl = objSecond.imageDataUrl
            this.ruleForm.spe = objSecond.spe
            this.ruleForm.order = objSecond.order
            this.ruleForm.showMoney = objSecond.showMoney
            this.ruleForm.num = objSecond.num
            this.ruleForm.time = objSecond.time
            this.ruleForm.date = objSecond.date
            this.ruleForm.count = objSecond.count
          }
        },
        methods: {
          firstTab(){
            this.$router.push({path:'/FirstTabs'})
          },
          onEditorChange (e) { // 内容改变事件
            this.ruleForm.count = e.html
            // console.log(this.ruleForm.count)
          },
          // qq

          handleAvatarSuccess(res, file) {
            this.ruleForm.imageUrl = URL.createObjectURL(file.raw);
            this.param = new FormData();
            this.param.append('file', file, file.name);
            this.imageDataUrl = "http://pqi8u88r7.bkt.clouddn.com/"+res.key  //上传图片的路径
            console.log(this.imageDataUrl)
            return false;
          },
          beforeAvatarUpload(file) {
            console.log(file)
          },
          //获取店铺的信息
          shopList() {
            let id = sessionStorage.getItem('id')
            this.$http.post('/merchant/shop/selectShopByMerchant',{merchant_id: id}).then((res)=>{
              console.log(res)
              this.shopOption = res.datas
            })
          },
          //平台分类
          terraceClass(){
            this.$http.post('/merchant/terrace/terraceClass',{}).then(res=>{
               console.log(res)
              if (res.code == 1) {
                this.shopClass = res.datas
                let classId = this.ruleForm.class
                console.log(classId)
                sessionStorage.setItem('classId',classId)
                this.shopClass.map(item =>{
                  if (classId == item.id) {
                     let className = item.name
                    sessionStorage.setItem('className',className)
                  }else {
                    return false
                  }
                })
              }
            }).catch(err => {
              console.log(err)
            })
          },
          //根据选择平台 和 第一步爬到的店铺名称来判断是否符合
          shopSelect(vId){
            console.log(vId)
            this.qq();
            let name;
            this.shopOption.find((item)=>{      //这里的shopOption就是上面遍历的数据源
              // return item.shop_name == vId; //筛选出匹配数据
              if (item.id == vId) {
                 name = item.shop_name
              }

            });
            console.log(name)
            let shopName = sessionStorage.getItem('shopName')
            console.log(this.ruleForm.shop)
            sessionStorage.setItem('shop1',this.ruleForm.shop)
            if (shopName != name) {
                this.$message('店铺与商品信息不符，请检查是否有误')
                this.isShow = false
            }else {
              sessionStorage.setItem('shop',this.ruleForm.shop)
            }
          },
          qq(){
            this.$http.post('/merchant/shop/gainShop',{
              shop_id:this.ruleForm.shop
            }).then(res =>{
              console.log(res)
              if(res.code == 1){
                 for (let i=0;i<res.datas.length;i++) {
                   this.ruleForm.qq =  res.datas[i].shop_qq
                 }
              }
            }).catch(err =>{
              console.log(err)
            })
          },
          //  时间切割
          getTime (time) {   //获取时间
            console.log(time)
            this.ruleForm.time = this.toTime(time)
            console.log(this.ruleForm.time)
          },
          toTime (time) {
            if (!time) {
              return ''
            }
            let newtime = new Date(time)
            let y = newtime.getFullYear()
            let m = newtime.getMonth() + 1 >=10 ? newtime.getMonth() + 1 : ("0"+(newtime.getMonth() + 1))
            let d = newtime.getDate() >= 10 ? newtime.getDate() : ('0' + newtime.getDate())
            let h = newtime.getHours()>= 10 ? newtime.getHours() : ('0' + newtime.getHours())
            let mm= newtime.getMinutes()>= 10 ? newtime.getMinutes() : ('0' + newtime.getMinutes())
            let s= newtime.getSeconds()>= 10 ? newtime.getSeconds() : ('0' + newtime.getSeconds())
            // return y + '-' + m + '-' + d
            return y + '-' + m + '-' + d+' '+h+':'+mm+':'+s
          },
          // 初始化富文本编辑器
          onEditorReady(editor) {
          },
          // 点击下一步跳转
          next(ruleForm){
            this.$refs.ruleForm.validate((valid )=>{
              let that = this
              if (valid) {
                that.isShow=true
                let objSecond = {
                  qq: that.ruleForm.qq,
                  tit: that.ruleForm.tit,
                  imageDataUrl: that.imageDataUrl,
                  spe:that.ruleForm.spe,
                  order: that.ruleForm.order,
                  showMoney: that.ruleForm.showMoney,
                  num: that.ruleForm.num,
                  time: that.ruleForm.time,
                  date : that.ruleForm.date,
                  count: that.ruleForm.count
                }
                sessionStorage.setItem('objSecond',JSON.stringify(objSecond))
                that.$router.push({path:'./ThirdTabs'})
              }
            })
          },

          //获取上传图片的token
          getQiniuToken() {
            this.$http.post("/common/getQiNiuPicToken")
              .then(response => {
                if (response.code == 1) {
                  this.qn.token=response.datas;
                }
              })
              .catch(error => {
                console.log(error)
              });
          },
        }

    }
</script>

<style scoped>
  .uls{
    width: 98%;
    border-bottom: 1px solid #dddddd;
  }
  .uls li{
    width: 78px;
    height: 36px;
    line-height: 36px;
    border-radius: 5px 5px 0px 0px;
    display: inline-block;
    margin-left: 11px;
    background: #f2f2f2;
    text-align: center;
    cursor: pointer;
  }
  .activit{
    background: #f28b1d !important;
    color: #fff;
  }
  .avatar-uploader .el-upload:hover {
    border-color: #409EFF;
  }
  .avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    margin-top: 21px;
    /*width: 178px;*/
    /*height: 178px;*/
    /*line-height: 178px;*/
    text-align: center;
  }
  .avatar {
    width: 178px;
    height: 178px;
    display: block;
  }
  .uploadTip {
    font-size: 14px;
    margin-top: 20px;
    color: #666666;
  }
  .uploadAsk{
    font-size: 12px;
    color: #888;
  }
  .secondtTab{
    margin-top: 30px;
  }
  .btn{
    display: flex;
    justify-content: center;
    margin: 70px auto;
  }
  .btn img{
    margin-left: 50px;
  }

</style>

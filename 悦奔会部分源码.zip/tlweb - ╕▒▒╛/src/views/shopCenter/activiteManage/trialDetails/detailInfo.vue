<template>
    <div class="deta">
        <!-- 试用详情 -->
        <h3>试用详情</h3>
        <div>
            <ul class="detail">
                <li>
                    <p class="detail-title">
                        <span class="detail-number">活动编号：{{orderList.order_no}}</span>
                        <span class="detail-name">发布时间：{{orderList.create_time}}</span>
                    </p>
                    <div class="detail-info">
                        <div class="detail-img">
                            <img :src="orderList.product_url" alt="">
                        </div>
                        <div class="details">
                            <p class="detail-describle">商&nbsp;品&nbsp;名&nbsp;称：{{orderList.spName}}</p>
                            <p>商&nbsp;品&nbsp;规&nbsp;格：{{orderList.spec}}</p>
                            <p>平&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;台: {{orderList.platform_id}}</p>
                            <p>店&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;铺：{{orderList.shop_id}}</p>
                            <!-- <p>试用服务费： 99积分</p> -->
                        </div>
                        <div class="draw">
                            <p>下单价:{{orderList.lower_price}}</p>
                            <p>试用数：{{orderList.amount}}份</p>
                            <p>已领取：{{orderList.take_number}}份</p>
                            <p>未领取：{{orderList.amount-orderList.take_number}}份</p>
                        </div>
                        <div class="serves">
                            <p>担&nbsp;&nbsp;保&nbsp;&nbsp;金&nbsp;：{{orderList.ensure_price}}</p>
                            <p>试用服务费：{{orderList.tryout_price}}积分</p>
                            <p>增&nbsp;值&nbsp;服&nbsp;务：
                                <!-- {{orderList.zzName}} -->
                                <span>{{orderList.zzName}}</span>

                                <!-- <span v-for="(items,i ) in item.merchantShopServiceEvenList" :key="i">
                                    <span class="w60">{{items.name}}</span>
                                </span> -->
                            </p>
                            <p>增值服务费：{{orderList.service_price}}积分</p>
                        </div>
                        <div class="state">
                            <p>活动状态：{{orderList.order_status}}</p>
                            <p>创建时间：{{orderList.create_time}}</p>
                            <p>开始时间：{{orderList.start_time}}</p>
                            <p>结束时间：{{orderList.stop_time}}</p>
                        </div>
                    </div>
                </li>
            </ul>
            <div class="trial">
                <div>
                    <span class="first">总共发放试用：{{orderList.amount}}份</span>
                    <span>今日已通过：{{orderList.yitongguo}}份(已领取{{orderList.yilingqu}}份)</span>
                </div>
                <div>
                    <span class="first">已&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;申&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;请：{{orderList.getSum}}人</span>
                    <span @click="trialManger">试客管理</span>
                </div>
            </div>
            <div class="method">
                <p>试用发放方式：</p>
                <div class="source">
                    <p>商家链接：{{orderList.spProduct_url}}</p>
                    <p>下单类型：{{orderList.lower_type}}</p>
                    <!-- 关键字还未切出来 -->
                    <div class="keyword">
                        <div class="left">搜索关键词:</div>
                        <div class="right">
                            <ul>
                                <li>综合，价格筛选</li>
                                <li>信用，价格筛选</li>
                            </ul>
                        </div>
                    </div>
                    <p>商家要求：{{orderList.ask}}</p>
                    <div class="table">
                        <el-tabs v-model="activeName" @tab-click="handleClick">
                            <el-tab-pane label="试用进展(共计139人申请)" name="first">
                                <el-table
                                :data="shokeySumList"
                                style="width: 100%">
                                    <el-table-column
                                        prop="name"
                                        label="申请"
                                        width="180">
                                    </el-table-column>
                                    <el-table-column
                                        prop="date"
                                        label="日期"
                                        width="180">
                                    </el-table-column>
                                    <el-table-column
                                        prop="address"
                                        label="合计">
                                    </el-table-column>
                                </el-table>
                            </el-tab-pane>
                            <el-tab-pane label="费用明细" name="second">
                                <el-table
                                :data="tableData2"
                                style="width: 100%">
                                    <el-table-column
                                        prop="date"
                                        label="费用分类"
                                        width="200">
                                    </el-table-column>
                                    <el-table-column
                                        prop="name"
                                        label="费用明细"
                                        width="200">
                                    </el-table-column>
                                    <el-table-column
                                        prop="address"
                                        label="合计">
                                    </el-table-column>
                                </el-table>
                                <p class="count">合计：2000元，400积分</p>
                            </el-tab-pane>
                        </el-tabs>
                    </div>
                    <el-button type="primary" round class="btn" @click="goback">返回</el-button>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    data() {
      return {
        orderList:[],
        keywordList:[],
        shokeySumList:[],
        activeName: 'first',
        tableData1: [{
            date: '2016-05-02',
            name: '100',
            address: '139'
          }, {
            date: '2016-05-04',
            name: '39',
            address: '39'
          }, {
            date: '2016-05-01',
            name: '3',
            address: '9'
          }, {
            date: '2016-05-03',
            name: '0',
            address: '0'
        }],
        tableData2: [{
            date: '试用服务费',
            name: '试用服务费=3积分*份数',
            address: '139'
          }, {
            date: '商品担保金',
            name: '商品担保金=下单金额*份数',
            address: '39'
          }, {
            date: '增值服务费',
            name: '人群打标：20积分*份数     活动置顶：50积分/天*活动天数    特别置顶： 50积分*活动天数',
            address: '9'
          }]
      };
    },
    created(){
        this.get()
        // this.post()
    },
    methods: {
    //   post(){
    //       this.$http.post('/merchant/terrace/FormatOfCalculation ').then(res=>{
    //           console.log(res)
    //       })
    //   },
      handleClick(tab, event) {
        // console.log(tab, event);
      },
      goback(){
          this.$router.go(-1)
      },
      trialManger(){
          this.$router.push({path:'./detailTrial'})
      },
      get(){//商品详情
          this.$http.post('/merchant/activitys/activityDetails',{
              order_no: this.$route.query.order_no,
              member_order_status: this.$route.query.member_order_status
          }).then((res)=>{
              console.log(res)
              if(res.code=='1'){
                //   console.log(res.datas.orderOne[0])
                  this.orderList = res.datas.orderOne[0]
                  this.orderList.create_time = res.datas.orderOne[0].create_time.slice(0,10)
                  this.orderList.start_time = res.datas.orderOne[0].start_time.slice(0,10)
                  this.orderList.stop_time = res.datas.orderOne[0].stop_time.slice(0,10)
                  for(let i=0;i<res.datas.shokeySum.length;i++){
                      this.shokeySumList.push(
                          {
                              date : res.datas.shokeySum[i].create_time.slice(0,10),
                              name : res.datas.shokeySum[i].numberDay,
                              address : res.datas.shokeySum[i].numberSum
                          }
                      )
                    //   this.shokeySumList[i].data = res.datas.shokeySum[i].create_time
                    //   this.shokeySumList[i].name = res.datas.shokeySum[i].numberDay
                    //   this.shokeySumList[i].address = res.datas.shokeySum[i].numberSum
                  }
                //   console.log(this.shokeySumList)
                  this.keywordList  = res.datas.orderKeyword
                //   console.log(this.keywordList)
              }
            //   console.log(this.orderList)
          })
      }
    }
}
</script>

<style scoped>
.deta{
    padding: 0 15px;
}
.deta h3{
    margin-top:40px;
    font-size: 20px;
    text-align: center;
}
.detail{
    margin-top: 50px;
}
.detail li{
    /* margin-bottom: 34px; */
    /* height: 234px; */
    font-size: 15px;
    border: 1px solid rgb(255,233,212);
    border-radius: 5px;
}
.detail li .detail-title{
    box-sizing: border-box;
    padding: 0 12px;
    display: flex;
    justify-content: space-between;
    width: 100%;
    line-height: 60px;
    font-size: 17px;
    background-color: rgb(242,242,242);
    border: 1px solid rgb(242,242,242);
    border-top-left-radius: 5px;
    border-top-right-radius: 5px;
}
.detail .detail-info{
    box-sizing: border-box;
    display: flex;
    padding: 20px 0 0 20px;
}
.detail-info .detail-img{
    display: flex;
    justify-content: center;
    align-items: center;
    width: 130px;
}
.detail-img img{
    width: 130px;
    height: 134px;
    /* background-color: aqua; */
    border-radius: 5px;
}
.details{
    box-sizing: border-box;
    position: relative;
    top:-5px;
    display: flex;
    flex-direction: column;
    justify-content: space-around;
    /* margin-right: 20px; */
    padding: 0 15px 0 20px;
    width: 259px;
    border-right: 1px solid rgb(221,221,221);
}
.detail p{
    line-height: 24px;/*注意根据行数设置实际行高*/
}
.details .detail-describle{
    width: 222px;
    overflow: hidden;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
}
.draw{
    box-sizing: border-box;
    position: relative;
    top:-5px;
    display: flex;
    flex-direction: column;
    justify-content: space-around;
    /* margin-right: 20px; */
    padding: 0 10px;
    width: 140px;
    border-right: 1px solid rgb(221,221,221);
}
.serves{
    box-sizing: border-box;
    position: relative;
    top:-5px;
    display: flex;
    flex-direction: column;
    justify-content: space-around;
    /* margin-right: 20px; */
    padding: 0 10px;
    width: 182px;
    border-right: 1px solid rgb(221,221,221);
}
.state{
    box-sizing: border-box;
    position: relative;
    top:-5px;
    display: flex;
    flex-direction: column;
    justify-content: space-around;
    /* margin-right: 20px; */
    padding-left:10px;
    width: 178px;
}
.trial{
    margin-top:20px;
    font-size: 17px;
}
.trial span{
    line-height: 54px;
}
.trial .first{
    width: 300px;
}
.method p{
    font-size: 18px;
    font-weight: bold;
    line-height: 50px;
}
.source p{
    line-height: 54px;
    font-weight: normal;
}
.source p span{
    line-height: 26px;
}
.table{
    margin-top:25px;
    border: 1px solid rgb(255,233,212);
    border-radius: 5px;
}
.keyword{
    display: inline-block;
    margin-top:12px;
}
.keyword .left{
    margin-right: 10px;
    float: left;
    font-size: 18px;
}
.keyword .right{
    float: left;
}
.keyword .right li{
    font-size: 16px;
    line-height: 26px;
}
.count{
    margin-right: 20px;
    float: right;
}
.btn{
    margin: 60px 0 50px 230px;
    width: 450px;
    height: 60px;
    font-size: 18px;
    background-color: rgb(243,145,39);
    border: none;
    border-radius: 50px;
}
.w60{
    margin-right: 10px;
    width: 60px;
    height: 20px;
    overflow: hidden;
}
</style>


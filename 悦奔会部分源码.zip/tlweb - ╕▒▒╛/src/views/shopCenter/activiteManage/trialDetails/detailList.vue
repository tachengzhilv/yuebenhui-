<template>
    <div>
       <p class="title">试用活动</p>
       <div class="search">
                <div>
                    <div>
                        <span>活动查询</span>
                        <el-button class="search-btn" @click="searchInfo">查询</el-button>
                    </div>
                    <div class="search-info">
                        <div>
                            活动编号：<el-input v-model="inputNumber" placeholder="请输入活动编号" class="number"></el-input>
                        </div>
                        <div>
                            商品名称：<el-input v-model="inputName" placeholder="请输入商品名称" class="name"></el-input>
                        </div>
                        <div>
                            选择店铺：
                            <el-select v-model="sotreValue" placeholder="全部" class="shop">
                                <el-option
                                v-for="item in sotreOptions"
                                :key="item.value"
                                :label="item.label"
                                :value="item.id">
                                </el-option>
                            </el-select>
                        </div>
                        <div>
                            活动状态：
                            <el-select v-model="activiteValue" placeholder="全部" class="state">
                                <el-option
                                v-for="item in activiteOptions"
                                :key="item.value"
                                :label="item.label"
                                :value="item.id">
                                </el-option>
                            </el-select>
                        </div>
                    </div>
               <!-- 选项卡 -->
               <div class="tabs">
                   <el-tabs v-model="activeName">
                        <el-tab-pane :label="item.label" :name="item.label" v-for="item in activiteOptions" :key='item.id' @click="getOrderList(item.id)">{{item.label}}</el-tab-pane>
                    </el-tabs>
                    <!-- 订单信息 -->
                    <ul class="detail">
                        <li v-for="(item,index) in orderList" :key='index'>
                            <p class="detail-title">
                                <span class="detail-number text2">活动编号：{{item.order_no}}</span>
                                <span class="detail-name">店铺名称：{{item.shop_name}}</span>
                            </p>
                            <div class="detail-info">
                                <div class="detail-img">
                                    <img :src="item.url" alt="">
                                </div>
                                <div class="details">
                                    <p class="detail-describle text2">商&nbsp;品&nbsp;名&nbsp;称：{{item.productName}}</p>
                                    <p>下&nbsp;单&nbsp;价&nbsp;格：￥{{item.lower_price}}</p>
                                    <p>试&nbsp;用&nbsp;份&nbsp;数:&nbsp;&nbsp;&nbsp;{{item.amount}}份</p>
                                    <p>担&nbsp;&nbsp;&nbsp;保&nbsp;&nbsp;&nbsp;金：￥{{item.ensure_price}}</p>
                                    <p>试用服务费： {{item.service_price}}积分</p>
                                </div>
                                <div class="selects">
                                    <p>申&nbsp;请&nbsp;人&nbsp;数：{{item.num}}人</p>
                                    <p>已&nbsp;领&nbsp;取&nbsp;数：{{item.take_number}}人</p>
                                    <p>增&nbsp;值&nbsp;服&nbsp;务：
                                        <span v-for="(items,i ) in item.merchantShopServiceEvenList" :key="i">
                                            <span class="w60">{{items.name}}</span>
                                        </span>
                                    </p>
                                    <p>增值服务费：{{item.service_price}}积分</p>
                                </div>
                                <div class="time">
                                    <p>活动状态：{{item.order_status | orderStatus}}</p>
                                    <p>创建时间：{{item.create_time}}</p>
                                    <p>开始时间：{{item.start_time}}</p>
                                    <p>结束时间：{{item.stop_time}}</p>
                                </div>
                                <!-- 进行中59 -->
                                <div class="change" v-if='item.order_status=="59"'>
                                    <p @click='detailinfo(item.order_no,item.order_status)'>查看详情</p>
                                    <p @click="detailtrial(item.id,item.amount)">试客管理</p>
                                    <p >
                                        <!-- 暂停 -->
                                        <el-button type="text" @click="parse" class="between" style="text-align-last=justify">暂停</el-button>
                                    </p>
                                    <p @click="longtime">延长时间</p>
                                </div>
                                <!-- 暂停中60 -->
                                <div class="change" v-else-if='item.order_status=="60"'>
                                    <p @click='detailinfo(item.order_no,item.order_status)'>查看详情</p>
                                    <p @click="detailtrial(item.id,item.amount)">试客管理</p>
                                    <p class="between" @click="conti(item.order_status,item.id)">继续</p>
                                </div>
                                <!-- 待付款52 -->
                                <div class="change" v-else-if='item.order_status=="52"'>
                                    <p class="between" @click="pay(item.id)">付款</p>
                                </div>
                                <!-- 待审核53 -->
                                <div class="change" v-else-if='item.order_status=="53"'>
                                    <p @click='detailinfo(item.order_no,item.order_status)'>查看详情</p>
                                </div>
                                <!-- 未通过57 -->
                                <div class="change" v-else-if='item.order_status=="57"'>
                                    <p @click='reason(item.id)'>查看原因</p>
                                    <p class="between" @click="edit(item.id)">编辑</p>
                                </div>
                                <!-- 待上线c -->
                                <div class="change" v-else-if='item.order_status=="57"'>
                                    <p @click='detailinfo(item.order_no,item.order_status)'>查看详情</p>
                                    <p @click="detailtrial(item.id,item.amount)">试客管理</p>
                                    <p class="between" @click="parse">暂停</p>
                                    <p @click="longtime">延长时间</p>
                                </div>
                                <!-- 快下线61 -->
                                <div class="change" v-else-if='item.order_status=="61"'>
                                    <p @click='detailinfo(item.order_no,item.order_status)'>查看详情</p>
                                    <p @click="detailtrial(item.id,item.amount)">试客管理</p>
                                    <p class="between" @click="parse">暂停</p>
                                    <p @click="longtime">延长时间</p>
                                </div>
                                <!-- 已下线62 -->
                                <div class="change" v-else-if='item.order_status=="62"'>
                                    <p @click='detailinfo(item.order_no,item.order_status)'>查看详情</p>
                                    <p @click="detaillist(item.id)">试客列表</p>
                                     <p @click="longtime">延长时间</p>
                                </div>
                                <!-- 已完成63 -->
                                <div class="change" v-else>
                                    <p @click='detailinfo(item.order_no,item.order_status)'>查看详情</p>
                                    <p @click="detaillist(item.id)">试客列表</p>
                                </div>
                                <!-- 暂停弹出框 -->
                                <div v-if="false">
                                    <el-button type="text" @click="parseopen">点击打开 Message Box</el-button>
                                </div>
                                <div v-if="show">
                                    <el-dialog
                                    :visible.sync="dialogVisible"
                                    height="200"
                                    width="30%"
                                    :before-close="handleClose">
                                        <span class="parse">是否暂停活动?</span>
                                        <span slot="footer" class="dialog-footer">
                                            <el-button type="primary" @click="parseopen(item.order_status,item.id)">确 定</el-button>
                                            <el-button @click="dialogVisible = false">取 消</el-button>
                                        </span>
                                    </el-dialog>
                                </div>
                                <!-- 延长时间弹出框 -->
                                <div>
                                    <div v-if="false">
                                        <el-button type="text" @click="dialogFormVisible = true">打开嵌套表单的 Dialog</el-button>
                                    </div>

                                    <el-dialog title="选择延长天数" :visible.sync="dialogFormVisible" class="long">
                                    <el-form>
                                        <el-form-item label="">
                                        <el-select v-model="item.day">
                                            <el-option :label="item.day" :value="item.day" v-for='item in form' :key='item.day'></el-option>
                                        </el-select>
                                        </el-form-item>
                                    </el-form>
                                    <div slot="footer" class="dialog-footer">
                                        <el-button type="primary" @click="longtimeS(item.day)" class="longt">延长</el-button>
                                    </div>
                                    </el-dialog>
                                    <!-- 延长时间第二弹出框 -->
                                    <div>
                                        <div v-if="false">
                                            <el-button type="text" @click="dialogVisible1 = false">点击打开 Dialog</el-button>
                                        </div>

                                        <div class="foot">
                                            <el-dialog
                                            :visible.sync="dialogVisible1"
                                            width="30%"
                                            :before-close="handleClose">
                                            <p>您已选择增值服务:</p>
                                            <div v-for="(itemi,i) in item.merchantShopServiceEvenList" :key="i">
                                               <p>{{i}}{{itemi.name}}</p>
                                               <!-- <input type="hidden" :value="itemi.name"> -->
                                                <div v-if="itemi.name=='自动筛选'">
                                                   <span>111</span>
                                                </div>
                                                <div v-else style="color:red">
                                                    <span>如延长活动时间需再支付{{points}}积分</span>
                                                </div>
                                                
                                                   <!-- <span>如延长活动时间需再支付{{points}}积分</span> -->
                                            </div>

                                            <p>您是否延长</p>
                                            <span slot="footer" class="dialog-footer bot5">
                                                <el-button type="primary" @click="longtimeSS">确 定</el-button>
                                                <el-button @click="dialogVisible1 = false">取 消</el-button>
                                            </span>
                                            </el-dialog>
                                        </div>
                                    </div>
                                    <!-- 延长确定弹框 -->
                                    <div>
                                        <div v-if="false">
                                            <el-button type="text" @click="longtimeopen">点击打开 Message Box</el-button>
                                        </div>
                                    </div>
                                </div>
                                <!-- 查看原因 -->
                                <div>
                                    <div v-if="false">
                                        <el-button type="text" @click="reasonopen">点击打开 Message Box</el-button>
                                    </div>
                                </div>
                                <!-- 继续 -->
                                <div>
                                    <div v-if="false">
                                        <el-button type="text" @click="contiopen">点击打开 Message Box</el-button>
                                    </div>
                                </div>
                            </div>
                            
                        </li>
                    </ul>
                    <!-- 分页器 -->
                    <div class="pagination">
                        <!-- current-page为当前页 -->
                        <el-pagination
                            background
                            @size-change="handleSizeChange"
                            @current-change="handleCurrentChange"
                            :current-page="pageNum"
                            layout="prev, pager, next"
                            :total="200"
                            :page-size = 'pageS'
                             @next-click="next"
                             @prev-click="prev">
                        </el-pagination>
                    </div>
               </div>
           </div>
       </div>
    </div>
</template>

<script>
export default {
    data(){
        return{
            zzService:[],
            points: '5',
            current:'',
            pageNum: 1,
            show: false,
            inputNumber:'',//商品编号
            inputName:'',//商品名称
            activeName: '全部',//tab选中状态
            sotreOptions: [],//店铺列表
            activiteOptions:[],//状态列表
            sotreValue: '',//店铺选项值
            activiteValue: '',//状态选项值
            orderList:[],//订单列表
            failReason:'',//失败原因
            dialogVisible: false,
            dialogVisible1: false,
            pageS: 10,
            dialogTableVisible: false,
            dialogFormVisible: false,
            form: [
                {day:'1天'},
                {day:'2天'},
                {day:'3天'},
                {day:'4天'},
                {day:'5天'},
                {day:'6天'},
                {day:'7天'}
            ]
        }
    },
    created(){
        this.getStoreList(),
        this.getStateList(),
        this.getOrderList(),
        this.getI()
    },
    computed:{
        
    },
    methods:{
        getI(){
            this.$http.post('/merchant/terrace/serviceNumber').then(res=>{
                // console.log(res)
                if(res.code=='1'){
                    this.zzService = res.datas
                    console.log(this.zzService)
                }
            })
        },
        getStoreList(){//获取店铺列表//固定id传10获取列表记得修改
            let  id = sessionStorage.getItem('id')
            this.$http.post('/merchant/shop/selectShopByMerchant',{merchant_id:10}).then(res=>{
                // console.log(res)
                if(res.code=='1'){
                    for(let i=0;i<res.datas.length;i++){
                        this.sotreOptions.push(
                            {
                                value: i,
                                label: res.datas[i].shop_name,
                                id: res.datas[i].id
                            }
                        )
                    }
                    this.sotreOptions.unshift({
                        value: 999,
                        label:'全部',
                        id: 999
                    })
                }
                // console.log(this.sotreOptions)
            })
        },
        getStateList(){//获取状态列表
            // let  id = sessionStorage.getItem('id')
            this.$http.post('/common/getCacheEnums',{key:'order_status'}).then(res=>{
                // console.log(res)
                if(res.code=='1'){
                    let arr=res.datas
                    for(let i=0;i<arr.length;i++){
                        if(arr[i].element_value=='开始'){
                            arr.splice(arr.indexOf(arr[i]),1)
                        }
                    }
                    for(let i=0;i<arr.length;i++){
                        if(arr[i].element_value=='不通过'){
                            arr.splice(arr.indexOf(arr[i]),1)
                        }
                    }
                    for(let i=0;i<arr.length;i++){
                        if(arr[i].element_value=='通过'){
                            arr.splice(arr.indexOf(arr[i]),1)
                        }
                    }
                    for(let i=0;i<arr.length;i++){
                        if(arr[i].element_value=='待完善'){
                            arr.splice(arr.indexOf(arr[i]),1)
                        }
                    }
                    // console.log(arr)
                    for(let i=0;i<arr.length;i++){
                        this.activiteOptions.push(
                            {
                                value: i,
                                label: arr[i].element_value,
                                id: arr[i].id
                            }
                        )
                    }
                    this.activiteOptions.unshift({
                        value: 999,
                        label:'全部',
                        id: 999
                    })
                    // console.log(this.activiteOptions)
                }
            })
        },
        getOrderList(order_status){//获取订单列表
            // let  id = sessionStorage.getItem('id')
            // console.log(this.activiteValue)
            // console.log(order_status)
            if(order_status == '999'||order_status == '999'){
                return order_status = ''
            }
            this.$http.post('/merchant/activitys/inquire',{
                order_no: this.inputNumber?this.inputNumber:'',
                name: this.inputName?inputName:'',
                shop_id: this.sotreValue?this.sotreValue:'',
                order_status: this.activiteValue||order_status||''
            }).then(res=>{
                console.log(res)
                if(res.code=='1'){
                    let arr=res.datas
                    this.orderList = arr
                    // console.log(arr)
                    for(let i=0;i<arr.length;i++){//裁切三个时间的长度格式
                        // arr[i].create_time = this.orderList[i].create_time.slice(0,10) 
                        arr[i].start_time = this.orderList[i].start_time.slice(0,10)
                        arr[i].stop_time = this.orderList[i].stop_time.slice(0,10)
                    }
                }
            })
        },
        detailinfo(orderNO,orderStatus){//查看详情
            this.$router.push({path:'./detailInfo',query:{
                order_no: orderNO,
                member_order_status: orderStatus
            }})
        },
        detailtrial(id,amount){//试客管理  24为待审核列表  22为已通过列表
            this.$router.push({path:'./detailTrial',query:{
                order_id: id,
                amount: amount,
                member_order_status: 24
            }})
        },
        searchInfo(){//查询信息
            this.getOrderList()
            // console.log(this.sotreValue)
            // console.log(this.activiteValue)
        },
        handleClick(tab, event) {
            console.log(tab, event);
        },
        detaillist(id){//试客列表
            this.$router.push({path:'./trialList',query:{
                order_id:id
            }})
        },
        conti(status,id){//继续
            this.contiopen(status,id)
        },
        contiopen(status,id) {//继续确定
            let that = this
            console.log(status,id)
            this.$confirm('是否继续活动?', '', {
                cancelButtonText: '取消',
                confirmButtonText: '确定',
                // type: 'warning'
                }).then(() => {
                    // console.log(id)
                    this.$http.post('/merchant/activitys/startToEnd',{
                        order_status:status,
                        id:id
                    }).then(res=>{
                        // console.log(1)
                    })
                    this.$message({
                        type: 'success',
                        message: '继续活动成功!',
                        onClose:function () {//弹出文字后刷新
                          that.$router.go()
                        //   console.log(123)
                        }
                    });
                    
                })
                .catch(() => {
                // this.$message({
                    // type: 'info',
                    // message: '已取消删除'
                // });          
            });
        },
        parse(){//暂停确认后发送数据给后台
            this.show = true
            // console.log(123)
            // console.log(status)
            this.dialogVisible =true
        },
        parseopen(status,id){//暂停成功后刷新界面
            this.dialogVisible = false
             this.$message({
              type: 'success',
              message:'该活动暂停成功'
            });
            this.$http.post('/merchant/activitys/startToEnd',{
                order_staus: status,
                id:id
            }).then(res=>{
                if(res.code=='1'){
                    this.$router.go()//重新刷新页面
                }
            })
        },
        reason(id){//查看原因
            this.$http.post('/merchant/activitys/lookCause',{
                order_id: id
            }).then(res=>{
                console.log(res)
                if(res.code=='1'){
                    this.failReason = res.datas.failing_cause
                    console.log(this.failReason)
                }
                this.reasonopen()
            })
            
        },
        reasonopen() {//原因弹框
            this.$alert(this.failReason + `</br><p style='font-size:13px;color:rgb(87,87,87)'>*担保金及相应服务费已退回账号</p>`, '审核未通过', {
            confirmButtonText: '确定',
            dangerouslyUseHTMLString: true,
            callback: action => {}
            });
        },
        pay(id){//付款
            console.log('付款')
            // let  id = sessionStorage.getItem('id')
            this.$http.post('/merchant/activitys/editingActivity',{
                order_id:id
            }).then(res=>{
                console.log(res)
            })
        },
        edit(id){//编辑
            // let  id = sessionStorage.getItem('id')
            console.log('编辑')
            // this.$router.push('/FirstTabs')
            this.$http.post('/merchant/activitys/editingActivity',{
                order_id:id
            }).then(res=>{
                console.log(res)
            })
        },
        longtime(){//延长时间
            // console.log(1)
            this.dialogFormVisible = true
        },
        longtimeS(day){//延长按钮    延长积分比较麻烦放最后计算
            this.dialogFormVisible = false
            this.dialogVisible1 = true
            console.log(day)
        },
        longtimeSS(){//延长确定
            this.dialogVisible1 = false
            console.log('延长确定')
            this.longtimeopen()
        },
        longtimeopen() {//延长确认后弹框
            this.$message({
                type: 'success',
                message:'该试客申请已通过'
            });
        },
        handleClose(done) {
            this.$confirm('确认关闭？')
            .then(_ => {
                done();
            })
            .catch(_ => {});
        },
        next(){//下一页
            // console.log(1)
            this.current++
            console.log(this.current)
        },
        prev(){//前一页
            this.current--
            console.log(this.current)
        },
        handleSizeChange(val) {
            console.log(`每页 ${val} 条`);
        },
        handleCurrentChange(val) {//val值为当前页的值
            console.log(`当前页: ${val}`);
        }
    },
    filters:{
        orderStatus (str) {//状态过滤器
            if (str == '52') {
                return '待付款'
            }else if(str == '53') {
                return '待审核'
            }else if(str == '57') {
                return '未通过'
            }else if(str == '58') {
                return '待上线'
            }else if(str == '59') {
                return '进行中'
            }else if(str == '60') {
                return '暂停中'
            }else if(str == '61') {
                return '快下线'
            }else if(str == '62') {
                return '已下线'
            }else if(str == '63') {
                return '已完成'
            }
        }
    }
}
</script>

<style scoped>
.bot5{
    position: relative;
    top: 20px;
}
.w60{
    margin-right: 10px;
    width: 60px;
    height: 20px;
    overflow: hidden;
}
.text2{
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
}
.foot{
    padding-top: 0;
}
.longt{
    position: absolute;
    bottom: 20px;
    left: 305px;
}
.title{
    margin-top:40px;
    font-size: 20px;
    text-align: center;
}
.search{
    width: 920px;
    margin-top: 54px;
    padding-left: 15px;
    font-size: 20px;
}
.search .search-btn{
    margin-left: 25px;
    padding: 14px 40px;
    font-size: 20px;
    color: rgb(241,140,29);
    border-color: rgb(241,140,29);
}
.search-info{
    margin: 37px 14px 0 0; 
    display: flex;
    justify-content: space-between;
    font-size: 17px;
}
.search-info .number,.shop,.state,.name{
    width: 120px;
    font-size: 13px;
}
.search-info .name{
    width: 140px;
}
.tabs{
    margin:36px 14px 0 0;
    padding-top: 10px;
    width: 920px;
    font-size: 15px;
}
.tabs .el-tabs__nav{
    width: 100%;
    display: flex;
    justify-content: space-between;
}
.tabs .detail{
    margin-top: 35px;
}
.detail li{
    margin-bottom: 34px;
    border: 1px solid rgb(255,233,212);
    border-radius: 5px;
}
.detail li .detail-title{
    box-sizing: border-box;
    padding: 0 12px;
    display: flex;
    justify-content: space-between;
    width: 100%;
    line-height: 60px;
    font-size: 17px;
    background-color: rgb(242,242,242);
    border: 1px solid rgb(242,242,242);
    border-top-left-radius: 5px;
    border-top-right-radius: 5px;
}
.detail .detail-info{
    box-sizing: border-box;
    display: flex;
    padding: 20px;
}
.detail-info .detail-img{
    display: flex;
    justify-content: center;
    align-items: center;
    width: 130px;
}
.detail-img img{
    width: 130px;
    height: 134px;
    background-color: aqua;
    border-radius: 5px;
}
.details{
    position: relative;
    top:0px;
    display: flex;
    flex-direction: column;
    justify-content: space-around;
    /* margin-right: 20px; */
    padding: 0 20px;
    border-right: 1px solid rgb(221,221,221);
}
.detail p{
    line-height: 24px;/*注意根据行数设置实际行高*/
}
.details .detail-describle{
    width: 222px;
    overflow: hidden;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
}
.detail-info .selects{
    position: relative;
    display: flex;
    flex-direction: column;
    justify-content: space-around;
    box-sizing: border-box;
    padding: 0 20px;
    width: 194px;
    line-height: 28px;
    border-right: 1px solid rgb(221,221,221);
}
.detail-info .time{
    position: relative;
    display: flex;
    flex-direction: column;
    justify-content: space-around;
    box-sizing: border-box;
    padding: 0 20px;
    width: 210px;
    line-height: 28px;
    border-right: 1px solid rgb(221,221,221);
}
.detail-info .change{
    position: relative;
    display: flex;
    flex-direction: column;
    justify-content: space-around;
    align-content: center;
    /* align-items: center; */
    box-sizing: border-box;
    padding: 0 20px;
    width: 104px;
    line-height: 28px;
}
.change p .between{/*文字两端对齐*/
    text-align-last: justify;
}
.tabs .pagination{
    margin-bottom: 50px;
    text-align: center;
}
.parse{
    position: relative;
    top: 5px;
    font-size: 16px;
}
</style>


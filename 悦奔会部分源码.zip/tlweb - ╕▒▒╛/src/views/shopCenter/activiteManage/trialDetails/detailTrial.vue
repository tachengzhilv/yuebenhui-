<template>
    <div class="trialManage">
        <!-- 试客管理 -->
        <h3>试用管理</h3>
        <p class="info">试客申请信息查询&nbsp;&nbsp;<span>(剩余名额：{{surplus}})</span></p>
        <div class="list">
            <el-tabs v-model="activeName" @tab-click="handleClick">
                <el-tab-pane :label="applyNumber" name="first" @click="getTrialList">
                    <ul>
                        <li v-for="(item,i) in applyList" :key="i" @click="getTrialInfo(item.id)">
                            <el-button type="text" @click="dialogVisible = true">
                                <img :src="item.head_url" alt="">
                                <p style="width:60px">{{item.nick_name}}</p>
                            </el-button>

                            <el-dialog
                            :visible.sync="dialogVisible"
                            :before-close="handleClose" class="first">
                                <div class="personal">
                                    <div class="pleft">
                                        <img :src="personalInfo.head_url" alt="">
                                        <p>{{personalInfo.nick_name}}</p>
                                        <p>买家信用:<img :src="personalInfo.ailpay_level_url" alt="" style="width:20px;height:20px;margin-left:5px;margin-top:0"></p>
                                    </div>
                                    <div class="pright">
                                        <div class="number">
                                            <span>悦奔会账号:{{personalInfo.mobile}}</span>
                                        </div>
                                        <div class="prtsc">
                                            <p>浏览截图:</p>
                                            <img :src="personalInfo.printscreen_url" alt="">
                                        </div>
                                        <div>
                                            <p>操作:&nbsp;&nbsp;
                                                <el-button type="text" @click="pass" style="padding:0">通过</el-button>
                                            </p>
                                            <p class="caution">*通过后无法取消,请谨慎操作</p>
                                        </div>
                                    </div>
                                </div>
                            </el-dialog>
                            <div class="inpass">
                                <el-dialog
                                :visible.sync="dialogVisible1"
                                :before-close="handleClose" class="second">
                                    <span class="ispass">是否确认通过该试客的申请?</span>
                                    <span slot="footer" class="dialog-footer">
                                        <el-button type="primary" @click="shows(item.id)">确 定</el-button>
                                    </span>
                                </el-dialog>
                            </div>
                        </li>
                    </ul>
                    <div v-if="show">
                        <el-button type="text" @click="open">点击打开 Message Box</el-button>
                    </div>
                    <el-pagination
                    :page-size="1"
                    :pager-count="5"
                    layout="prev, pager, next"
                    :total="42" class="pagination">
                    </el-pagination>
                </el-tab-pane>
                <el-tab-pane :label="passNumber" name="second" @click="getTrialPass">
                    <ul>
                        <li v-for="(item,i) in passList" :key="i" @click="getTrialInfo(item.id)">
                            <el-button type="text" @click="dialogVisible2 = true">
                                <img :src="item.head_url" alt="">
                                <p style="width:60px">{{item.nick_name}}</p>
                            </el-button>

                            <el-dialog
                            :visible.sync="dialogVisible2"
                            :before-close="handleClose" class="first">
                                <div class="personal">
                                    <div class="pleft">
                                        <img :src="personalInfo.head_url" alt="">
                                        <p>{{personalInfo.nick_name}}</p>
                                        <p>买家信用:<img :src="personalInfo.ailpay_level_url" alt="" style="width:20px;height:20px;margin-left:5px;margin-top:0"></p>
                                        <p>所在城市：{{personalInfo.city}}</p>
                                    </div>
                                    <div class="pright">
                                        <div class="number">
                                            <span>悦奔会账号:{{personalInfo.mobile}}</span>
                                        </div>
                                        <div class="prtsc">
                                            <p>浏览截图:</p>
                                            <img :src="personalInfo.printscreen_url" alt="">
                                        </div>
                                        <div>
                                            <p>状态：待悦粉填写订单号</p>
                                        </div>
                                    </div>
                                </div>
                            </el-dialog>
                        </li>
                    </ul>
                    <el-pagination
                    :page-size="1"
                    :pager-count="11"
                    layout="prev, pager, next"
                    :total="20" class="pagination">
                    </el-pagination>
                </el-tab-pane>
            </el-tabs>
            
        </div>
    </div>
</template>

<script>
import { fail } from 'assert';
import { setTimeout } from 'timers';
export default {
    data() {
      return {
        surplus:'',
        activeName: 'first',
        dialogVisible:false,
        dialogVisible1:false,
        dialogVisible2:false,
        show : false,
        personalInfo: {},
        applyNumber:'',
        passNumber:'',
        applyList:[],//申请列表
        passList:[]//通过列表
      };
    },
    created(){
        this.getTrialList()
        this.getTrialPass()
    },
    methods: {
      handleClick(tab, event) {
        // console.log(tab, event);
      },
      handleClose(done) {
        this.$confirm('确认关闭？')
          .then(_ => {
            done();
          })
          .catch(_ => {});
      },
      pass(){//通过
        console.log(1)
        this.dialogVisible1 = true
      },
      getTrialList(){//申请待审核名单名单
        //   console.log(this.$route.query.order_id)
          this.$http.post('/merchant/shokey/shokeyManagement',{
            order_id: this.$route.query.order_id,
            member_order_status: 24
          }).then(res=>{
              console.log(res)
              if(res.code=='1'){
                  this.applyList = res.datas.shokeyManagementList
                  this.applyNumber = "申请名单("+res.datas.shokeyNumberList[0].shenqing+")"
                  this.passNumber = "已通过("+res.datas.shokeyNumberList[0].tongguo+")"
                  this.surplus = this.$route.query.amount - res.datas.shokeyNumberList[0].tongguo
                //   console.log(this.surplus)
                //   console.log(this.applyList)
              }
          })
      },
      getTrialPass(){//申请名单已通过
          this.$http.post('/merchant/shokey/shokeyManagement',{
            order_id: this.$route.query.order_id,
            member_order_status: 22
          }).then(res=>{
            //   console.log(res)
              if(res.code=='1'){
                //   console.log(res)
                  this.passList = res.datas.shokeyManagementList
                //   console.log(this.passList)
              }
          })
      },
      getTrialInfo(id){//获取试客详情
          this.$http.post('/merchant/shokey/shokeyDetails',{
              id:id
          }).then(res=>{
              console.log(res)
              if(res.code=='1'){
                  this.personalInfo = res.datas[0]
                  console.log(this.personalInfo)
                  var tel = this.personalInfo.mobile;
                  tel = "" + tel;
                  var tel1 = tel.substr(0,3) + "*****" + tel.substr(8)
                  this.personalInfo.mobile = tel1
              }
          })
      },
      shows(id){//确认通过该试客的申请
          this.dialogVisible = false
          this.dialogVisible1 = false
          this.open()
          this.$http.post('/merchant/shokey/shokeyStatus',{
              id:id,
              member_order_status: 22
          }).then(res=>{
              if(res.code=='1'){
                this.$router.go()//刷新页面
              }
          })
         
      },
      open() {
          this.$message({
              type: 'success',
              message:'该试客申请已通过'
          });
      }
    }
}
</script>

<style scoped>
.trialManage{
    padding: 0 12px 0 18px;
}
.trialManage h3{
    margin-top:40px;
    font-size: 20px;
    text-align: center;
}
.info{
    margin-top: 50px;
    font-size: 17px;
}
.list{
    box-sizing: border-box;
    margin-top: 50px;
    padding-left: 24px;
    border: 1px solid rgb(254,244,230);
    border-radius: 5px;
}
.list ul{
    display: flex;
    flex-wrap: wrap;
    width: 874px;
}
.list li{
    margin: 24px 25px 0 0;
    /* float: left; */
}
.list img{
    width: 60px;
    height: 60px;
    border-radius: 50%;
}
.personal{
    display: flex;
    height: 440px;
    width: 500px;
    /* border: 1px solid red; */
}
.pleft{
    width: 140px;
    height: 440px;
    background-color: rgb(242,242,242)
}
.pright{
    padding: 20px;
    width: 360px;
}
.pleft img{
    margin: 35px 0 0 30px;
    width: 80px;
    height: 80px;
    border-radius: 50%;
}
.pleft p{
    font-size: 15px;
    line-height: 28px;
    text-align: center;
}
.pright .number{
    display: flex;
    justify-content: space-between;
    box-sizing: border-box;
    margin-top: 20px;
    padding-bottom: 20px;
    font-size: 16px;
    font-weight: bold;
    border-bottom: 1px solid rgb(221,221,221)
}
.prtsc{
    box-sizing: border-box;
    padding: 20px 0;
}
.prtsc p{
    line-height: 26px;
}
.prtsc img{
    width: 120px;
    height: 238px;
    border-radius: 0;
}
.caution{
    font-size: 14px;
    color: rgb(136,136,136);
}
.ispass{
    position: relative;
    top: 50px;
    left: 50px;
}
/* .list .mar0{
    margin-right: 0;
} */
</style>

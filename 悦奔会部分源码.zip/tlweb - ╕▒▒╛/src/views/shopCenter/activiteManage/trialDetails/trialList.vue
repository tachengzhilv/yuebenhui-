<template>
    <div class="trial">
        <h3>试客列表</h3>
        <div class="list">
            <el-tabs v-model="activeName" @tab-click="handleClick">
                <el-tab-pane :label="all" name="first">
                    <ul>
                        <li v-for="item in trialList" :key="item.id" @click="getTrialInfo(item.id)">
                            <el-button type="text" @click="dialogVisible1 = true">
                                <img :src="item.head_url" alt="">
                                <p>{{item.nick_name}}</p>
                            </el-button>

                            <el-dialog
                            :visible.sync="dialogVisible1"
                            :before-close="handleClose" class="first">
                                <div class="personal">
                                    <div class="pleft">
                                        <img :src="personalInfo.head_url" alt="">
                                        <p>{{personalInfo.nick_name}}</p>
                                        <p>买家信用:<img :src="personalInfo.ailpay_level_url" alt="" style="width:20px;height:20px;margin-left:5px;margin-top:0"></p>
                                        <p>所在城市：{{personalInfo.city}}</p>
                                    </div>
                                    <div class="pright">
                                        <div class="number">
                                            <span>悦奔会账号:{{personalInfo.mobile}}</span>
                                        </div>
                                        <div class="prtsc">
                                            <p>浏览截图:</p>
                                            <img :src="personalInfo.printscreen_url" alt="">
                                        </div>
                                        <div>
                                            <p>状态：待悦粉填写订单号</p>
                                        </div>
                                    </div>
                                </div>
                            </el-dialog>
                        </li>
                    </ul>
                    <el-pagination
                    :page-size="1"
                    :pager-count="11"
                    layout="prev, pager, next"
                    :total="20" class="pagination">
                    </el-pagination>
                </el-tab-pane>
                <el-tab-pane :label="pass" name="second" @click="getPasslist">
                    <ul>
                        <li v-for="item in passList" :key="item.id" @click="getTrialInfo(item.id)">
                            <el-button type="text" @click="dialogVisible2 = true">
                                <img :src="item.head_url" alt="">
                                <p>{{item.nick_name}}</p>
                            </el-button>

                            <el-dialog
                            :visible.sync="dialogVisible2"
                            :before-close="handleClose" class="first">
                                <div class="personal">
                                    <div class="pleft">
                                        <img :src="personalInfo.head_url" alt="">
                                        <p>{{personalInfo.nick_name}}</p>
                                        <p>买家信用:<img :src="personalInfo.ailpay_level_url" alt="" style="width:20px;height:20px;margin-left:5px;margin-top:0"></p>
                                        <p>所在城市：{{personalInfo.city}}</p>
                                    </div>
                                    <div class="pright">
                                        <div class="number">
                                            <span>悦奔会账号:{{personalInfo.mobile}}</span>
                                        </div>
                                        <div class="prtsc">
                                            <p>浏览截图:</p>
                                            <img :src="personalInfo.printscreen_url" alt="">
                                        </div>
                                        <div>
                                            <p>状态：待悦粉填写订单号</p>
                                        </div>
                                    </div>
                                </div>
                            </el-dialog>
                        </li>
                    </ul>
                    <el-pagination
                    :page-size="1"
                    :pager-count="11"
                    layout="prev, pager, next"
                    :total="20" class="pagination">
                    </el-pagination>
                </el-tab-pane>
            </el-tabs>
            
        </div>
    </div>
</template>

<script>
export default {
    data() {
      return {
        activeName: 'first',
        dialogVisible1:false,
        dialogVisible2:false,
        trialList:[],
        passList:[],
        all:'',
        pass:'',
        personalInfo:''
      };
    },
    created(){
        this.getTriallist()
        this.getPasslist()
    },
    methods: {
      handleClick(tab, event) {
        // console.log(tab, event);
      },
      handleClose(done) {
        this.$confirm('确认关闭？')
          .then(_ => {
            done();
          })
          .catch(_ => {});
      },
      shows(){
          this.dialogVisible = false
          this.dialogVisible1 = false
      },
      getTriallist(id){//全部名单
          this.$http.post('/merchant/shokey/shokeyManagement',{
            order_id: 2
          }).then(res=>{
            //   console.log(res)
              if(res.code=='1'){
                  let number = res.datas.shokeyNumberList[0]
                  this.trialList = res.datas.shokeyManagementList
                  let allNumber = number.shenqing+number.tongguo
                  this.all = "全部("+allNumber+")"
                //   console.log(this.all)
              }
          })
      },
      getPasslist(){//已通过列表
          this.$http.post('/merchant/shokey/shokeyManagement',{
            order_id: 2,
            member_order_status: 22
          }).then(res=>{
              console.log(res)
              if(res.code=='1'){
                  this.passList = res.datas.shokeyManagementList
                  this.pass = "已通过("+res.datas.shokeyNumberList[0].tongguo+")"
              }
          })
      },
      getTrialInfo(id){
          this.$http.post('/merchant/shokey/shokeyDetails',{
              id:2
          }).then(res=>{
              console.log(res)
              if(res.code=='1'){
                  this.personalInfo = res.datas[0]
                  console.log(this.personalInfo)
                  var tel = this.personalInfo.mobile;
                  tel = "" + tel;
                  var tel1 = tel.substr(0,3) + "*****" + tel.substr(8)
                  this.personalInfo.mobile = tel1
              }
          })
      }
    }
  };
</script>

<style scoped>
.trial{
  box-sizing: border-box;
  padding: 24px;
}
.trial h3{
    font-size: 20px;
    margin-top: 40px;
    text-align: center;
}
.list{
    box-sizing: border-box;
    margin-top: 50px;
    padding-left: 24px;
    border: 1px solid rgb(254,244,230);
    border-radius: 5px;
}
.list ul{
    display: flex;
    flex-wrap: wrap;
    width: 874px;
}
.list li{
    margin: 24px 25px 0 0;
}
.list img{
    width: 60px;
    height: 60px;
    border-radius: 50%;
}
.personal{
    display: flex;
    height: 440px;
    width: 500px;
}
.pleft{
    width: 140px;
    height: 440px;
    background-color: rgb(242,242,242)
}
.pright{
    padding: 20px;
    width: 360px;
}
.pleft img{
    margin: 35px 0 0 30px;
    width: 80px;
    height: 80px;
    border-radius: 50%;
}
.pleft p{
    font-size: 15px;
    line-height: 28px;
    text-align: center;
}
.pright .number{
    display: flex;
    justify-content: space-between;
    box-sizing: border-box;
    margin-top: 20px;
    padding-bottom: 20px;
    font-size: 16px;
    font-weight: bold;
    border-bottom: 1px solid rgb(221,221,221)
}
.prtsc{
    box-sizing: border-box;
    padding: 20px 0;
}
.prtsc p{
    line-height: 26px;
}
.prtsc img{
    width: 120px;
    height: 238px;
    border-radius: 0;
}
.caution{
    font-size: 14px;
    color: rgb(136,136,136);
}
.ispass{
    position: relative;
    top: 50px;
    left: 50px;
}
.list .mar0{
    margin-right: 0;
}
</style>

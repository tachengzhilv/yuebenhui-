<template>
    <div class="trialManage">
       <h3>活动管理</h3>
       <router-view></router-view>
    </div>
</template>

<script>
    export default {
        name: "trialManage",
        data() {
            return {
                
            }
        },
        methods: {
            
        }
    }
</script>

<style scoped>
.trialManage h3{
    font-size: 24px;
}
</style>

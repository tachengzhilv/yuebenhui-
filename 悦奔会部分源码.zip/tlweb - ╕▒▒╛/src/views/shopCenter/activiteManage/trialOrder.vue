<template>
    <div>
       <h3>活动管理</h3>
       <router-view></router-view>
    </div>
</template>

<script>
    export default {
        name: "trialOrder",
        data() {
            return {}
        },
        methods: {}
    }
</script>

<style scoped>
h3{
    font-size: 24px;
}
</style>

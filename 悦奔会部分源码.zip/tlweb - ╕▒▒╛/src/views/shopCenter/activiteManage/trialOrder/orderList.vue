<template>
    <div class="orderlist">
        <h3>试用订单</h3>
        <!-- 订单查询 -->
        <div class="orderSearch">
            <p class="title">订单查询</p>
            <div class="searchOptions">
                <div>
                    活动编号：<el-input v-model="input" placeholder="请输入内容" class="number"></el-input>
                </div>
                <div>
                    商&nbsp;品&nbsp;名&nbsp;称：<el-input v-model="input1" placeholder="请输入内容" class="name"></el-input>
                </div>
                <div>
                    悦粉账号：<el-input v-model="input2" placeholder="请输入内容" class="ynumber"></el-input>
                </div>
                <div>
                    试用订单：<el-input v-model="input3" placeholder="请输入内容" class="number"></el-input>
                </div>
                <div>
                    平台订单号：<el-input v-model="input4" placeholder="请输入内容" class="name"></el-input>
                </div>
                <div class="choose">
                    选择店铺：
                    <el-select v-model="value" placeholder="请选择">
                        <el-option
                        v-for="item in sotreOptions"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                        </el-option>
                    </el-select>
                </div>
                <div class="search" @click="searchinfo">查询</div>
                <div>
                    订单状态：
                    <el-select v-model="value1" placeholder="请选择">
                        <el-option
                        v-for="item in options1"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                        </el-option>
                    </el-select>
                </div>
            </div>
        </div>
        <!-- 分页器 -->
        <div>
            <el-tabs v-model="activeName"  class="page">
                <el-tab-pane label="全部订单10" name="1"></el-tab-pane>
                <el-tab-pane label="待填订单号(1)" name="2"></el-tab-pane>
                <el-tab-pane label="待审核订单号" name="3"></el-tab-pane>
                <el-tab-pane label="待发货(1)" name="4"></el-tab-pane>
                <el-tab-pane label="已发货(1)" name="5"></el-tab-pane>
                <el-tab-pane label="待审核内容" name="6"></el-tab-pane>
                <el-tab-pane label="待评价截图" name="7"></el-tab-pane>
                <el-tab-pane label="待审核评价" name="8"></el-tab-pane>
                <el-tab-pane label="已完成" name="9"></el-tab-pane>
            </el-tabs>
        </div>
        <!-- 试用订单 -->
        <div>
            <ul class="detail">
                <li v-for="(item,i) in orderList" :key="i">
                     <!-- v-for="item in orderList" :key="item.id" -->
                    <p class="detail-title">
                        <span class="detail-number">试用订单号：{{item.no}}</span>
                        <span class="detail-status">订单状态：{{item.member_order_status}}</span>
                        <span class="detail-name">店铺名称：{{item.shop_name}}</span>
                    </p>
                    <div class="detail-info">
                        <div class="detail-img">
                            <img :src="item.product_url" alt="">
                        </div>
                        <div class="details">
                            <p>活&nbsp;动&nbsp;编&nbsp;号：{{item.order_no}}</p>
                            <p class="detail-describle">商&nbsp;品&nbsp;名&nbsp;称：{{item.name}}</p>
                            <p>下&nbsp;单&nbsp;价&nbsp;格：{{item.lower_price}}</p>
                        </div>
                        <div class="selects">
                            <p>淘&nbsp;宝/天&nbsp;猫&nbsp;账&nbsp;号：{{item.alipay}}</p>
                            <p>淘宝/天猫订单号：{{item.tb_no}}</p>
                            <p v-if="true">下&nbsp;单&nbsp;倒&nbsp;计&nbsp;时：5小时23份10秒</p>
                            <p v-if="true">物&nbsp;&nbsp;流&nbsp;&nbsp;信&nbsp;&nbsp;息：申通快递<span class="right">32539784549565</span></p>
                        </div>
                        <div class="time">
                            <p>悦奔会账号：{{item.mobile}}</p>
                            <p v-if="true">审核倒计时：<span style="font-size:12px;">5小时23份10秒</span> </p>
                        </div>
                        <!-- 待悦粉填订单号 -->
                        <div class="connect" v-if="show">
                            <p style="text-align:center">无</p>
                        </div>
                        <!-- 待审核订单号 -->
                        <div class="connect" v-if="show">
                            <p @click="passOrder">通过订单</p>
                            <p @click="refuseOrder">拒绝订单</p>
                            <p @click="lookImg(item.id)">查看订单截图</p>
                        </div>
                        <!-- 待发货 -->
                        <div class="connect" v-if="show">
                            <p @click="send">发货</p>
                        </div>
                        <!-- 已发货 -->
                        <div class="connect" v-if="show">
                            <p style="text-align:center">无</p>
                        </div>
                        <!-- 待审核评价内容 -->
                        <div class="connect" v-if="true">
                            <p @click="checkassess(item.id)">审核评价内容</p>
                        </div>
                        <!-- 待悦粉传评价截图 -->
                        <div class="connect" v-if="show">
                            <p @click="lookassess(item.id)">查看评价内容</p>
                        </div>
                        <!-- 待审核评价截图 -->
                        <div class="connect" v-if="show">
                            <p @click="checkassessImg(item.id)">审核评价截图</p>
                            <p @click="lookassess(item.id)">查看评价内容</p>
                        </div>
                        <!-- 已完成 -->
                        <div class="connect" v-if="show">
                            <p @click="lookassessImg(item.id)">查看评价截图</p>
                            <p @click="lookassess(item.id)">查看评价内容</p>
                        </div>
                        <!-- 弹框事件 -->
                        <div class="orderlistframe">
                            <!-- 通过弹框 -->
                            <div>
                                <div v-if="false">
                                    <el-button type="text" @click="dialogVisible = true">点击打开 Dialog</el-button>
                                </div>
                                <el-dialog
                                :visible.sync="dialogVisible"
                                width="30%"
                                :before-close="handleClose">
                                <span>是否通过该订单</span>
                                <span slot="footer" class="dialog-footer">
                                    <el-button type="primary" @click="passopen(item.id)">确 定</el-button>
                                    <el-button @click="dialogVisible = false">取 消</el-button>
                                </span>
                                </el-dialog>
                            </div>
                            <!-- 拒绝弹框 -->
                            <div>
                                <div v-if="false">
                                    <el-button type="text" @click="dialogVisible1 = true">点击打开 Dialog</el-button>
                                </div>
                                <div>
                                    <el-dialog
                                    :visible.sync="dialogVisible1"
                                    width="30%"
                                    :before-close="handleClose">
                                    <span class="refusereason">拒绝订单理由</span>
                                    <el-input
                                    type="textarea"
                                    resize="none"
                                    :rows="2"
                                    placeholder="请输入内容"
                                    v-model="textarea">
                                    </el-input>
                                    <span slot="footer" class="dialog-footer refuse">
                                        <el-button type="primary" @click="refuseopen">确 定</el-button>
                                        <el-button @click="dialogVisible1 = false">取 消</el-button>
                                    </span>
                                    </el-dialog>
                                </div>
                                <div v-if="false">
                                    <el-button type="text" @click="dialogVisible1 = true">点击打开 Message Box</el-button>
                                </div>
                            </div>
                            <!-- 订单截图弹框 -->
                            <div>
                                <div v-if="false">
                                    <el-button type="text" @click="centerDialogVisible = true">点击打开 Dialog</el-button>
                                </div>

                                <div>
                                    <el-dialog
                                    :visible.sync="centerDialogVisible"
                                    width="500px"
                                    customClass="h800"
                                    center>
                                    <span class="imgtitle">试用订单截图</span>
                                    <img :src="orderImg" alt="" class="lookimg">
                                    <span slot="footer" class="dialog-footer">
                                        <el-button type="primary" @click="centerDialogVisible = false" style="width:450px;height:60px;border-radius:50px" class="confirmbtn">确 定</el-button>
                                    </span>
                                    </el-dialog>
                                </div>
                            </div>
                            <!-- 发货物流信息弹框 -->
                            <div>
                               <div v-if="false">
                                   <el-button type="text" @click="dialogFormVisible = true">打开嵌套表单的 Dialog</el-button>
                               </div>

                                <el-dialog :visible.sync="dialogFormVisible" custom-class="h265">
                                    <div class="wuliuinfo">物流信息</div>
                                    <el-form :model="form">
                                        <el-form-item label="快递公司：" :label-width="formLabelWidth">
                                            <el-input v-model="form.name1" autocomplete="off"></el-input>
                                        </el-form-item>
                                        <el-form-item label="快递单号：" :label-width="formLabelWidth">
                                            <el-input v-model="form.name2" autocomplete="off"></el-input>
                                        </el-form-item>
                                    </el-form>
                                    <div slot="footer" class="dialog-footer top45">
                                        <el-button type="primary" @click="sendopen(item.id)">确 定</el-button>
                                        <el-button @click="dialogFormVisible = false">取 消</el-button>
                                    </div>
                                </el-dialog>

                            </div>
                            <!-- 审核评价内容 -->
                            <div>
                                <div v-if="false">
                                    <el-button type="text" @click="dialogVisible3 = true">点击打开 Dialog</el-button>
                                </div>
                                <el-dialog
                                :visible.sync="dialogVisible3"
                                width="500px"
                                custom-class="h440"
                                :before-close="handleClose">
                                    <span class="t20">审核试客评价</span>
                                    <el-input
                                    type="textarea"
                                    resize="none"
                                    :readonly="true"
                                    :rows="11"
                                    class="w440"
                                    v-model="textarea1">
                                    </el-input>
                                    <span class="ispass">是否通过该评价内容？</span>
                                    <span slot="footer" class="dialog-footer b50">
                                        <el-button type="primary" @click="checkassessSuccess(item.id)">确 定</el-button>
                                        <el-button @click="checkassessFail">拒 绝</el-button>
                                    </span>
                                </el-dialog>
                                <!-- 拒绝评价内容弹框 -->
                                <div>
                                    <div v-if="false">
                                        <el-button type="text" @click="dialogVisible4 = true">点击打开 Dialog</el-button>
                                    </div>
                                    <el-dialog
                                    :visible.sync="dialogVisible4"
                                    width="30%"
                                    :before-close="handleClose">
                                    <span class="refusereason">拒绝评价内容理由</span>
                                    <el-input
                                    type="textarea"
                                    resize="none"
                                    :rows="2"
                                    placeholder="请输入内容"
                                    v-model="textarea">
                                    </el-input>
                                    <span slot="footer" class="dialog-footer rq">
                                        <el-button type="primary" @click="refuseReason(item.id)">确 定</el-button>
                                        <el-button @click="dialogVisible4 = false">取 消</el-button>
                                    </span>
                                    </el-dialog>
                                    <div v-if="false">
                                        <el-button type="text" @click="dialogVisible4">点击打开 Message Box</el-button>
                                    </div>
                                </div>
                            </div>
                            <!-- 查看评价内容 -->
                            <div>
                                <div v-if="false">
                                    <el-button type="text" @click="dialogVisible5 = true">点击打开 Dialog</el-button>
                                </div>
                                <el-dialog
                                :visible.sync="dialogVisible5"
                                width="500px"
                                custom-class="h410"
                                :before-close="handleClose">
                                    <span class="t20">试客评价</span>
                                    <el-input
                                    type="textarea"
                                    resize="none"
                                    :readonly="true"
                                    :rows="13"
                                    class="w440"
                                    v-model="textarea2">
                                    </el-input>
                                </el-dialog>
                            </div>
                            <!-- 审核评价截图 -->
                            <div>
                                <div v-if="false">
                                    <el-button type="text" @click="centerDialogVisible2 = true">点击打开 Dialog</el-button>
                                </div>

                                <div>
                                    <el-dialog
                                    :visible.sync="centerDialogVisible2"
                                    width="500px"
                                    customClass="h800"
                                    center>
                                    <span class="imgtitle">审核评价截图</span>
                                    <img :src="lookImgi" alt="" class="lookimg">
                                    <span slot="footer" class="dialog-footer dtbn">
                                        <!-- <el-button type="primary" @click="centerDialogVisible2 = false" style="width:450px;height:60px;border-radius:50px" class="confirmbtn">确 定</el-button> -->
                                        <el-button type="primary" @click="checkassessImgSuccess(item.id)">通 过</el-button>
                                        <el-button @click="checkassessImgFail" class="qxbtn">拒 绝</el-button>
                                    </span>
                                    <span class="t625">是否通过该评价截图？</span>
                                    </el-dialog>
                                </div>
                                <!-- 评价截图拒绝弹框 -->
                                <div v-if="false">
                                    <el-button type="text" @click="dialogVisible6 = true">点击打开 Dialog</el-button>
                                </div>
                                <el-dialog
                                :visible.sync="dialogVisible6"
                                width="30%"
                                :before-close="handleClose">
                                <span class="refusereason">拒绝评价截图理由</span>
                                <el-input
                                type="textarea"
                                resize="none"
                                :rows="2"
                                placeholder="请输入内容"
                                v-model="textarea3">
                                </el-input>
                                <span slot="footer" class="dialog-footer reimg">
                                    <el-button type="primary" @click="checkassessImgFailopen(item.id)">确 定</el-button>
                                    <el-button @click="dialogVisible6 = false">取 消</el-button>
                                </span>
                                </el-dialog>
                                <div v-if="false">
                                    <el-button type="text" @click="dialogVisible6 = true">点击打开 Message Box</el-button>
                                </div>
                            </div>
                            <!-- 查看评价截图 -->
                            <div>
                                <div v-if="false">
                                    <el-button type="text" @click="centerDialogVisible3 = true">点击打开 Dialog</el-button>
                                </div>

                                <div>
                                    <el-dialog
                                    :visible.sync="centerDialogVisible3"
                                    width="500px"
                                    customClass="h620"
                                    center>
                                    <span class="imgtitle">试客评价截图</span>
                                    <img :src="lookImgii" alt="" class="assessimg">
                                    <!-- <span slot="footer" class="dialog-footer">
                                        <el-button type="primary" @click="centerDialogVisible3 = false" style="width:450px;height:60px;border-radius:50px" class="confirmbtn">确 定</el-button>
                                    </span> -->
                                    </el-dialog>
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
                <!-- <li>
                    <p class="detail-title">
                        <span class="detail-number">试用订单号：27441689456789123</span>
                        <span class="detail-status">订单状态：待填写订单号</span>
                        <span class="detail-name">店铺名称：韩式服业</span>
                    </p>
                    <div class="detail-info">
                        <div class="detail-img">
                            <img src="" alt="">
                        </div>
                        <div class="details">
                            <p>活动编号：5469802</p>
                            <p class="detail-describle">商&nbsp;品&nbsp;名&nbsp;称：清新文艺感镂空春季白色毛衣</p>
                            <p>下&nbsp;单&nbsp;价&nbsp;格：￥299.00</p>
                            <p>试&nbsp;用&nbsp;份&nbsp;数:&nbsp;&nbsp;&nbsp;份</p>
                            <p>担&nbsp;&nbsp;&nbsp;保&nbsp;&nbsp;&nbsp;金：￥</p>
                            <p>试用服务费：积分</p>
                        </div>
                        <div class="selects">
                            <p>淘宝/天猫账号：tb145933</p>
                            <p>淘宝/天猫订单号：458692483939</p>
                            <p>下单倒计时：5小时23份10秒</p>
                        </div>
                        <div class="time">
                            <p>悦奔会账号：132*****118</p>
                        </div>
                        <div class="connect">
                            <p style="text-align:center">无</p>
                        </div>
                    </div>
                </li> -->
            </ul>
        </div>
        <!-- 分页器 -->
        <div class="pagination">
            <!-- current-page为当前页 -->
            <el-pagination
                background
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page="pageNum"
                layout="prev, pager, next"
                :total="200"
                :page-size = 'pageS'
                    @next-click="next"
                    @prev-click="prev">
            </el-pagination>
        </div>
    </div>
</template>

<script>
import { truncate } from 'fs';
export default {
    data() {
        return {
            pageS: 10,
            pageNum: 1,
            show: false,
            input: '',
            input1: '',
            input2: '',
            input3: '',
            input4: '',
            options1: [{//订单状态下拉框
                value: '选项1',
                label: '黄金糕'
                }, {
                value: '选项2',
                label: '双皮奶'
                }, {
                value: '选项3',
                label: '蚵仔煎'
                }, {
                value: '选项4',
                label: '龙须面'
                }, {
                value: '选项5',
                label: '北京烤鸭'
            }],
            value: '',
            value1: '',
            activeName: '1',//分页激活选项
            dialogVisible: false,
            dialogVisible1: false,
            dialogVisible2: false,
            dialogVisible3: false,
            dialogVisible4: false,
            dialogVisible5: false,
            dialogVisible6: false,
            textarea:'',
            textarea1: '',
            textarea2: '',            
            textarea3: '',
            centerDialogVisible:false,
            centerDialogVisible1: false,
            centerDialogVisible2: false,
            centerDialogVisible3: false,
            dialogFormVisible: false,
            form: {
                name1: '',
                name2: ''
            },
            formLabelWidth: '120px',
            orderList:[],
            sotreOptions:[],
            orderImg: '',
            lookImgi:'',
            lookImgii:''
        }
    },
    created(){
        this.getOrderlist()  
        // this.getOrderstatus()
        this.getStoreList()
    },
    methods:{
        getStoreList(){//获取店铺列表//固定id传10获取列表记得修改
            let  id = sessionStorage.getItem('id')
            this.$http.post('/merchant/shop/selectShopByMerchant',{merchant_id:10}).then(res=>{
                // console.log(res)
                if(res.code=='1'){
                    for(let i=0;i<res.datas.length;i++){
                        this.sotreOptions.push(
                            {
                                value: i,
                                label: res.datas[i].shop_name,
                                id: res.datas[i].id
                            }
                        )
                    }
                    this.sotreOptions.unshift({
                        value: 999,
                        label:'全部',
                        id: 999
                    })
                }
                // console.log(this.sotreOptions)
            })
        },
        getOrderlist(){//获取订单
            this.$http.post('/merchant/morder/order',{
                order_no:'',
                name:'',
                mobile:'',
                no:'',
                tb_no:'',
                shop_id:'',
                member_order_status:''
            }).then(res=>{
                // console.log(res)
                if(res.code=='1'){
                    this.orderList = res.datas
                    console.log(this.orderList)
                    for(let i=0;i<this.orderList.length;i++){
                        var tel = this.orderList[i].mobile;
                        tel = "" + tel;
                        var tel1 = tel.substr(0,3) + "*****" + tel.substr(8)
                        this.orderList[i].mobile = tel1
                    }
                }
            })
        },
        getOrderstatus(){//订单状态
            this.$http.post('/common/getCacheEnums',{
                key:'member_order_status'
            }).then(res=>{
                // console.log(res)
            })
        },
        searchinfo(){//查询按钮
            console.log('查询按钮')
            this.getOrderlist()
        },
        contact(){//联系悦粉
            console.log('联系悦粉')
        },
        passOrder(){//通过订单
            console.log('通过订单')
            this.dialogVisible = true
        },
        passopen(id) {//通过确认后弹框
            this.dialogVisible = false
            this.$http.post('/merchant/morder/orderStatus',{
                order_status: 9,
                order_no:order_no,
                id:id
            })
            this.$message({
                type: 'success',
                message:'订单已通过'
            });
        },
        refuseOrder(){//拒绝订单
            console.log('拒绝订单')
            this.dialogVisible1 = true
        },
        refuseopen() {//拒绝确认后弹框
            this.dialogVisible1 = false
            this.$message({
                type: 'success',
                message:'订单已拒绝'
            });
        },
        lookImg(id){//查看订单截图
            console.log('查看订单截图')
            this.centerDialogVisible = true
            this.$http.post('/merchant/morder/orderScreenshots',{
                order_id:id
            }).then(res=>{
                console.log(res)
            })
        },
        send(){//发货
            console.log('发货')
            this.dialogFormVisible = true
        },
        sendopen(id){//发送确认后弹框
            this.dialogFormVisible = false
            this.$http.post('/merchant/morder/logistics',{
                name:this.form.name1,
                no:this.form.name2,
                id:id
            })
            this.$message({
                type: 'success',
                message:'订单发货成功'
            });
        },
        checkassess(id){//审核评价内容
            console.log('审核评价内容')
            this.dialogVisible3 = true
            this.$http.post('/merchant/morder/commentsAndScreenshot',{
                id:id
            }).then(res=>{
                console.log(res)
                // this.textarea1
                if(res.code=='1'){
                    this.textarea1 = res.datas[0].evaluate
                }
            })
        },
        checkassessSuccess(id){//审核评价通过
            this.dialogVisible3 = false
            this.$http.post('/merchant/morder/reviewComments',{
                evaluate_status:18,
                id:id
            }).then(res=>{
                console.log(res)
                if(res.code=='1'){
                    this.$message({
                        type: 'success',
                        message:'该评论内容已通过'
                    });
                }
            })
        },
        checkassessFail(){//审核评价拒绝
            this.dialogVisible3 = false
            this.dialogVisible4 = true
        },
        refuseReason(id){//拒绝理由确定弹框
            this.dialogVisible4 = false
            this.$http.post('/merchant/morder/reviewComments',{
                evaluate_status:18,
                id:id
            }).then(res=>{
                console.log(res)
                if(res.code=='1'){
                    this.$message({
                        type: 'success',
                        message:'该评论内容已拒绝'
                    });
                }
            })
        },
        lookassess(id){//查看评价内容
            console.log('查看评价内容')
            this.dialogVisible5 = true
            this.$http.post('/merchant/morder/commentsAndScreenshot',{
                id:id
            }).then(res=>{
                console.log(res)
                // this.textarea2
                if(res.code=='1'){
                    this.textarea2 = res.datas[0].evaluate
                }
            })
        },
        checkassessImg(id){//审核评价截图
            console.log('审核评价截图')
            this.centerDialogVisible2 = true
            this.$http.post('/merchant/morder/commentsAndScreenshot',{
                id:id
            }).then(res=>{
                console.log(res)
                if(res.code=='1'){
                    this.lookImgi = res.datas[0].evaluate_url
                }
            })
        },
        checkassessImgSuccess(id){//评价截图确认
            this.centerDialogVisible2 = false
            this.$http.post('/merchant/morder/reviewScreenshot',{
                evaluate_url_status:20,
                id:id
            }).then(res=>{
                console.log(res)
                if(res.code=='1'){
                    this.$message({
                        type: 'success',
                        message:'该评论内容已通过'
                    });
                }
            })
        },
        checkassessImgFail(){//评价截图拒绝
            this.centerDialogVisible2 = false
            this.dialogVisible6 = true
        },
        checkassessImgFailopen(id){//评价截图拒绝确认
            this.dialogVisible6 = false
            this.$http.post('/merchant/morder/decline',{
                evaluate_url_status:21,
                id:id
            }).then(res=>{
                console.log(res)
                if(res.code=='1'){
                    this.$message({
                        type: 'success',
                        message:'该评论截图已拒绝'
                    });
                }
            })
        },
        lookassessImg(id){//查看评价截图
            console.log('查看评价截图')
            this.centerDialogVisible3 = true
            this.$http.post('/merchant/morder/commentsAndScreenshot',{
                id:id
            }).then(res=>{
                console.log(res)
                if(res.code=='1'){
                    this.lookImgii = res.datas[0].evaluate_url
                }
            })
        },
        next(){//下一页
            // console.log(1)
            this.current++
            console.log(this.current)
        },
        prev(){//前一页
            this.current--
            console.log(this.current)
        },
        handleSizeChange(val) {
            console.log(`每页 ${val} 条`);
        },
        handleCurrentChange(val) {//val值为当前页的值
            console.log(`当前页: ${val}`);
        },
        handleClose(done) {
            this.$confirm('确认关闭？')
            .then(_ => {
                done();
            })
            .catch(_ => {});
      }
    }
}
</script>

<style scoped>
.reimg{
    position: relative;
    top: -40px;
}
.rq{
    position: relative;
    top: -40px;
}
.top45{
    position: relative;
    top: -45px;
}
.refuse{
    position: relative;
    top: -40px;
}
.t625{
    position: absolute;
    top: 625px;
    font-size: 17px;
}
.b50{
    position: absolute;
    left: 170px;
    bottom: 30px;
}
.ispass{
    position: absolute;
    top: 280px;
    font-size: 17px;
}
.w440{
    position: absolute;
    height: 277px;
    width: 440px;
}
.t20{
    position: absolute;
    bottom: 50px;
    font-size: 18px;
}
.right{
    float: right;
    margin-right: 15px;
}
.wuliuinfo{
    position: relative;
    bottom: 35px;
    font-size: 18px;
}
.el-input{
    width: 250px;
}
.refusereason{
    position: relative;
    bottom: 20px;
    font-size: 16px;
}
.confirmbtn{
    position: absolute;
    left: 25px;
    bottom: 20px;
    background-color: #f18c1d;
    border:none;
    font-size: 20px;
}
.dtbn{
    position: absolute;
    bottom: 27px;
    right: 155px;
}
.qxbtn{
    margin-left: 50px;
}
.imgtitle{
    position: relative;
    bottom: 50px;
    font-size: 18px;
}
.orderlist{
    padding-left: 15px;
}
.orderlist h3{
    margin-top: 40px;
    font-size: 20px;
    text-align: center;
}
.title{
    margin-top: 70px;
    font-size: 20px;
}
.searchOptions{
    margin-top: 20px;
    display: flex;
    flex-wrap: wrap;
}
.searchOptions>div{
    margin-bottom: 36px;
    margin-right: 15px;
}
.number{
    width: 120px;
}
.name{
    width: 168px;
}
.ynumber{
    width: 262px;
}
.search{
    width: 120px;
    height: 40px;
    line-height: 40px;
    text-align: center;
    background-color: #f18c2d;
    border-radius: 5px;
    color: #fff;
}
.searchOptions .choose{
    margin-right: 10px;
}
.page{
    width: 920px;
}
.detail li{
    margin-bottom: 34px;
    height: 234px;
    border: 1px solid rgb(255,233,212);
    border-radius: 5px;
}
.detail li .detail-title{
    box-sizing: border-box;
    padding: 0 12px;
    display: flex;
    justify-content: space-between;
    width: 100%;
    line-height: 60px;
    font-size: 17px;
    background-color: rgb(242,242,242);
    border: 1px solid rgb(242,242,242);
    border-top-left-radius: 5px;
    border-top-right-radius: 5px;
}
.detail .detail-info{
    box-sizing: border-box;
    display: flex;
    padding: 20px 0 20px 20px;
    font-size: 15px;
}
.detail-info .detail-img{
    /* margin-right: 20px; */
    width: 130px;
    height: 134px;
    /* background-color: aqua; */
    border-radius: 5px;
}
.detail-img img{
    width: 130px;
    height: 134px;
    /* background-color: aqua; */
    border-radius: 5px;
}
.details{
    position: relative;
    top:0px;
    display: flex;
    flex-direction: column;
    justify-content: space-around;
    /* margin-right: 20px; */
    padding: 0 12px;
    width: 200px;
    border-right: 1px solid rgb(221,221,221);
}
.detail p{
    line-height: 24px;/*注意根据行数设置实际行高*/
}
.details .detail-describle{
    width: 200px;
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
}
.detail-info .selects{
    position: relative;
    display: flex;
    flex-direction: column;
    justify-content: space-around;
    box-sizing: border-box;
    padding: 0 5px;
    width: 244px;
    line-height: 28px;
    border-right: 1px solid rgb(221,221,221);
}
.detail-info .time{
    position: relative;
    display: flex;
    flex-direction: column;
    justify-content: space-around;
    box-sizing: border-box;
    padding: 0 5px;
    width: 190px;
    line-height: 28px;
}
.detail-info .connect{
    position: relative;
    display: flex;
    flex-direction: column;
    justify-content: space-around;
    align-content: center;
    /* align-items: center; */
    box-sizing: border-box;
    padding: 0 5px;
    width: 104px;
    line-height: 28px;
    border-left: 1px solid #ccc;
}
.connect p .between{/*文字两端对齐*/
    text-align-last: justify;
}
.pagination{
    margin-bottom: 50px;
    text-align: center;
}
.lookimg{
    position: absolute;
    width: 325px;
    height: 580px;
}
.assessimg{
    position: absolute;
    width: 325px;
    height: 460px;
}
</style>

<template>
    <div>
      <h3>黑名单管理</h3>
      <div class="blackList">
        <p class="tit">黑名单(本月剩余黑名单名额：<i style="color:#f21d1d">{{num}}</i>)</p>
        <p class="tip">将用户账号加入次列表，列表中的用户账号无法使用您的商品</p>

        <el-form :inline="true" :model="formInline" class="demo-form-inline">
          <el-form-item label="拉黑账号：">
            <el-select v-model="formInline.region" placeholder="拉黑账号" class="el-select">
                <el-option
                  v-for="item in options"
                  :key="item.id"
                  :label="item.element_value"
                  :value="item.id">
                </el-option>
            </el-select>
            <el-input class="el-select" placeholder="请输入账号" v-model="formInline.user"></el-input>
          </el-form-item>
          <el-form-item label="添加时间">
            <el-date-picker
              v-model="StartEndTime"
              type="daterange"
              @change="getTime"
              range-separator="至"
              start-placeholder="开始日期"
              end-placeholder="结束日期">
            </el-date-picker>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" class="el-button--primary" @click="sub">查询</el-button>
          </el-form-item>
        </el-form>
        <div class="flag">
          <el-button class="spc" @click="clearAll">解除黑名单</el-button>
          <el-button class="add" @click="dialog=true">添加黑名单</el-button>
        </div>
        <div>
           <el-table
             :data="tableData"
             tooltip-effect="dark"
             style="width: 100%"
             @selection-change="handleSelectionChange">
             <el-table-column
               type="selection"
               width="55">
             </el-table-column>
             <el-table-column
               label="拉黑账号"
               prop="account_id"
              >
             </el-table-column>
             <el-table-column
               prop="black_account_type"
               label="账号类型">
               <template slot-scope="scope">
                 {{scope.row.black_account_type | black_account_type}}
               </template>
             </el-table-column>
             <el-table-column
               prop="create_time"
               label="添加时间">
             </el-table-column>
             <el-table-column
               prop="shieldingDays"
               label="拉黑时长">
             </el-table-column>
             <el-table-column
              prop="black_type"
              label="拉黑原因">
             </el-table-column>
             <el-table-column
               prop="address"
               label="拉黑范围(店铺)">
               <template slot-scope="scope">
                 <p v-for="items in scope.row.shopList">
                    {{items}}
                 </p>
               </template>
             </el-table-column>
             <el-table-column
               prop="address"
               label="操作">
               <template slot-scope="scope">
                  <p @click="openDialog(scope.row.id)" style="cursor: pointer">解除黑名单</p>
               </template>
             </el-table-column>
           </el-table>
         </div>
      </div>
      <el-dialog
        title="提示"
        :visible.sync="dialogVisible"
        width="30%"
        :before-close="handleClose">
        <span>是否解除黑名单</span>
        <span slot="footer" class="dialog-footer">
    <el-button @click="dialogVisible = false">取 消</el-button>
    <el-button type="primary" @click="closeBlack">确 定</el-button>
  </span>
      </el-dialog>
      <!--添加黑名单dialog-->
      <el-dialog
        title="提示"
        :visible.sync="dialog"
        width="50%"
        :before-close="handleClose">
        <div class="">
          <p style="color:#333;font-size: 18px">添加黑名单 <i style="color: #888;font-size: 14px">(本月剩余黑名单名额:<i style="color:#f21d1d">{{num}}</i>名)</i></p>
          <p style="color: #666;line-height: 21px;margin-top: 20px">黑名单功能针对违规试客，在黑名单上的试客将只能申请试用，不能中奖，包括系统抽奖，兑换等形式，请谨慎操作。</p>
          <el-form :inline="true" :model="formInlines" class="demo-form-inline" style="margin-top: 40px">
            <el-form-item label="拉黑账号：">
              <el-select v-model="formInlines.region" placeholder="拉黑账号" class="el-select">
                <el-option
                  style=" padding-right: 0"
                  v-for="item in options"
                  :key="item.id"
                  :label="item.element_value"
                  :value="item.id">
                </el-option>
              </el-select>
              <el-input class="el-select" placeholder="请输入账号" v-model="formInlines.user"></el-input>
            </el-form-item>
          </el-form>
          <p style="display: flex">
            <label style="width: 80px">拉黑范畴：</label>
            <span style="flex: 1">
             <el-checkbox-group v-model="checkList" >
                <el-checkbox v-for="(item,index) in blackScopes" :key="index" :label=item.id >{{item.shop_name}}</el-checkbox>
              </el-checkbox-group>
            </span>
          </p>
          <div style="display: flex;margin-top: 20px">
            <label style="width: 80px">拉黑原因:</label>
            <p style="flex: 1">
              <el-radio  v-for="(item,index) in blackResions" :key="index" v-model="radio" :label=item.id style="display: block" @change="items()">{{item.element_value}}</el-radio>
              <el-input
                type="textarea"
                :rows="2"
                v-if="isShow"
                placeholder="请输入内容"
                v-model="textarea">
              </el-input>
            </p>

          </div>
        </div>
        <span slot="footer" class="dialog-footer">
    <el-button @click="dialog = false">取 消</el-button>
    <el-button type="primary" @click="subTrue">确 定</el-button>
  </span>
      </el-dialog>

    </div>
</template>

<script>
    export default {
        name: "blacklist",
        data() {
            return {
              id: '',
              StartEndTime:'',
              checkList: [],
              options: [],
              tableData:[],
              create_timeStart: '',
              create_timeEnd: '',
              num:'',
              formInline: {
                user: '',
                region: ''
              },
              formInlines: {
                user: '',
                region: ''
              },
              multipleSelection:[],
              dialogVisible: false,
              dialog:false,
              textarea: '',
              radio: '',
              blackScopes: [],
              blackResions: [],
              isShow: false,
              idList:''
            }
        },
        mounted(){
          this.getList();
          this.getPost();
          this.blackScope();
          this.blackResion()
        },
        methods: {
          handleSelectionChange(val) {
            this.multipleSelection = val;
            for (let i= 0;i<val.length;i++) {
              this.idList+=val[i].id+ ','
            }
          },
          clearAll(){
            if (this.idList == '') {
              this.$message({
                type:'error',
                message:'请先选择要解除的名单'
              })
            } else {
              this.$http.post('/merchant/blacklist/blackliCheckAll',{
                idString: this.idList
              }).then(res =>{
                if (res.code == 1) {
                  console.log(res)
                  let  that = this
                  this.$message({
                    type:'success',
                    message:res.message,
                    showClose: true,
                    onClose:function () {
                      that.getList()
                    }
                  })
                }
              }).catch(err =>{
                console.log(err);
              })
            }
          },
          sub(){
            this.getList()
          },
          getList() {
            this.$http.post('/merchant/blacklist/getBlacklist', {
              black_account_type: this.formInline.region,
              account_id: this.formInline.user,
              create_timeStart: this.create_timeStart,
              create_timeEnd: this.create_timeEnd,
            }).then((res) => {
              console.log(res)
              if (res.code == 1) {
                this.tableData = res.datas.blacklistList;
                this.num = res.datas.blacklistNumber
              }
            }).catch(err => {
              console.log(err)
            })
          },
          getPost() {
            this.$http.post('/common/getCacheEnums', {
              key: 'black_account_type'
            }).then(res => {
              console.log(res)
              if (res.code == 1) {
                this.options = res.datas;
              }
            })
          },
          //转化时间
          toTime (time) {
            if (!time) {
              return ''
            }
            let newtime = new Date(time)
            let y = newtime.getFullYear()
            let m = newtime.getMonth() + 1 >=10 ? newtime.getMonth() + 1 : ("0"+(newtime.getMonth() + 1))
            let d = newtime.getDate() >= 10 ? newtime.getDate() : ('0' + newtime.getDate())
            let h = newtime.getHours()>= 10 ? newtime.getHours() : ('0' + newtime.getHours())
            let mm= newtime.getMinutes()>= 10 ? newtime.getMinutes() : ('0' + newtime.getMinutes())
            let s= newtime.getSeconds()>= 10 ? newtime.getSeconds() : ('0' + newtime.getSeconds())
            return y + '-' + m + '-' + d
            // return y + '-' + m + '-' + d+' '+h+':'+mm+':'+s
          },
          //  时间切割
          getTime (time) {   //获取时间
            console.log(time)
            this.create_timeStart = this.toTime(time[0])
            this.create_timeEnd = this.toTime(time[1])
            console.log(this.toTime(time[0]))
            console.log(this.toTime(time[1]))
          },
           // 解除黑名单
          openDialog(id){
            this.id = id;
            console.log(this.id)
            this.dialogVisible = true
          },
          handleClose(done) {
            this.dialogVisible = false
            this.dialog = false
          },
          //解除黑名单 点击确定
          closeBlack() {
            this.$http.post('/merchant/blacklist/unblacklist',{
              id: this.id
            }).then(res =>{
              console.log(res)
              if (res.code == 1) {
                let that = this
                this.dialogVisible = false;
                this.$message({
                  type:'success',
                  message: res.message,
                  onClose:function(){
                    that.getList()
                  }

                })
              }
            }).catch(err =>{
              console.log(err)
            })
          },
          //获取拉黑范畴
          blackScope(){
            let id = sessionStorage.getItem('id')
            this.$http.post('/merchant/shop/selectShopByMerchant',{
              merchant_id: id
            }).then(res =>{
              if (res.code == 1) {
                this.blackScopes = res.datas
              }
            })
          },
          //获取拉黑原因
          blackResion(){
            this.$http.post('/common/getCacheEnums' ,{
                key: 'black_type'
            }).then(res=>{
              if (res.code ==1 ){
                  this.blackResions = res.datas;
                  console.log(this.blackResions)
              }
            })
          },
          items(){
            console.log(this.radio)
            if (this.radio == 44) {
                this.isShow = true
            }else {
              this.isShow = false
            }
          },
          //点击添加黑名单确定按钮
          subTrue() {
            console.log(this.checkList)
            let shopIdList = this.checkList.join(',');
            console.log(shopIdList)
            if (this.checkList.length == 0) {
              this.$message.error('拉黑范畴需选一个')
            } else {
              this.$http.post('/merchant/blacklist/blacklisting', {
                black_account_type: this.formInlines.region,
                account: this.formInlines.user,
                black_type: this.radio,
                black_describe: this.textarea,
                shopIdString: shopIdList
              }).then(res => {
                console.log(res);
              })
            }
          }
        },
        filters:{
          black_account_type(str) {
            if (str == 1) {
              return '淘宝天猫账号'
            }else if (str == 2) {
              return '试客ID'
            }
          }
        }

    }
</script>

<style scoped>
.blackList{
  width: 98%;
  margin: 40px auto;
}
.tit{
   color: #333333;
   font-size: 20px;
   text-align: center;
}
.tip{
  text-align: center;
  color: #888888;
  font-size: 14px;
  line-height: 25px;
  margin-bottom: 50px;
}
.el-select{
  width: 120px;
}
.el-button--primary{
  color: #fff;
  background: #f28b1d;
  border: 1px solid #f28b1d;
}
.flag{
  margin-top: 10px;
  margin-bottom: 10px;
}
.el-button{
  width: 100px;
  height: 40px;
  text-align: center;
  padding: 14px 13px
}
.spc{
  color: #f28b1d;
  border: 1px solid #f28b1d;

}
</style>

<template>
  <div class="index">
    <appheader></appheader>
    <div class="content">
     <div class="leftNav">
       <leftNav></leftNav>
     </div>
      <div class="main-content">
         <router-view></router-view>
      </div>
    </div>
  </div>
</template>

<script>
    import Appheader from "../CommonHeader/appheader";
    import LeftNav from  '../CommonLeft/navLeft'
    export default {
      name: "index",
      components: {Appheader,LeftNav},
      data (){
        return {

        }
    }
    }
</script>

<style scoped>
.content{
  width: 1200px;
  margin: 45px auto;
  background: #ffffff;
  border-radius: 15px;
  box-shadow: 0 5px 20px 0px #bfb9b9 ;
  display: flex;
  min-height: 1000px;

}
.leftNav {
  width: 260px;
  overflow-y: auto;
  background: #f2f2f2;
}
.main-content{
  flex: 1;
}
.addSub img{
  margin: 60px 0 0 100px;
}
</style>

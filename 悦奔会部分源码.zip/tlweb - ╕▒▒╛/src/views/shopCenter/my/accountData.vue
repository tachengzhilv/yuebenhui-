<template>
    <div>
      <!-- 账户资料 -->
      <h3>个人中心</h3>
      <router-view></router-view>
    </div>
</template>

<script>
    export default {
        name: "accountData",
        data() {
            return {}
        },
        methods: {}
    }
</script>

<style scoped>

</style>

<template>
    <div>
        <h3>账户资料</h3>    
        <div class="accountDetail">
            <!-- 头像 -->
            <div class="headImg">
                <img src="http://pic15.nipic.com/20110628/1369025_192645024000_2.jpg" alt="" class="h100 img" @click="changeHead">
            </div>
            <!-- 账号（手机号） -->
            <div class="number">
                <div class="w130">账&nbsp;号&nbsp;(手&nbsp;机&nbsp;号)：</div>13600000000
            </div>
            <!-- 会员等级 -->
            <div class="level h66">
                <div class="lleft">
                    <div class="w130">会&nbsp;&nbsp;&nbsp;员&nbsp;&nbsp;&nbsp;等&nbsp;&nbsp;&nbsp;级：</div>VIP商家  <el-button class="renewvip" @click="renewVip">续费VIP</el-button>
                    <p class="time">到期时间：2019-08-12 22:05:49</p>
                </div>
                <!-- <div class="lright">续费VIP</div> -->
            </div>
            <!-- 主要负责人QQ -->
            <div class="qq h66">
                <div class="w130">主要负责人QQ：</div>365256363 <el-button style="width:80px" @click="changeqq">修改</el-button>
            </div>
            <!-- 地区 -->
            <div class="city h66">
                <div class="w130">地&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;区：</div>福建厦门 <el-button style="width:80px" @click="changecity">修改</el-button>
            </div>
            <!-- 可用余额 -->
            <div class="can">
                <div class="w130">可&nbsp;&nbsp;&nbsp;用&nbsp;&nbsp;&nbsp;余&nbsp;&nbsp;&nbsp;额：</div>￥658.56
            </div>
            <!-- 冻结余额 -->
            <div class="freeze">
                <div class="w130">冻&nbsp;&nbsp;&nbsp;结&nbsp;&nbsp;&nbsp;余&nbsp;&nbsp;&nbsp;额：</div>￥6580.56
            </div>
            <!-- 积分 -->
            <div class="integral">
                <div class="w130">积&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;分：</div>6580
            </div>
            <!-- 已绑定店铺 -->
            <div class="shop h66">
                <div class="w130">已&nbsp;绑&nbsp;定&nbsp;店&nbsp;铺&nbsp;：</div>1个 <el-button style="width:80px" @click="lookShop">查看</el-button>
            </div>
            <!-- 已绑定银行卡 -->
            <div class="card h66">
                <div class="w130">已绑&nbsp;定银&nbsp;行卡：</div>2张 <el-button style="width:80px" @click="lookCard">查看</el-button>
            </div>
            <!-- 修改头像弹框 -->
            <div>
                <div v-if="false">
                    <el-button type="text" @click="centerDialogVisible1 = true">点击打开 Dialog</el-button>
                </div>

                <el-dialog
                title="修改头像"
                :visible.sync="centerDialogVisible1"
                width="30%"
                center>
                <span>请上传图片:</span>
                <img src="http://pic15.nipic.com/20110628/1369025_192645024000_2.jpg" alt="" class="h100 img plimg">
                <p class="renew">重新上传</p>
                <span slot="footer" class="dialog-footer">
                    <el-button type="primary" @click="uploadHead">上传头像</el-button>
                </span>
                </el-dialog>
            </div>
            <!-- VIP续费弹框 -->
            <!-- 修改QQ弹框 -->
            <div>
                <div v-if="false">
                    <el-button type="text" @click="centerDialogVisible = true">点击打开 Dialog</el-button>
                </div>

                <el-dialog
                title="修改QQ"
                :visible.sync="centerDialogVisible"
                width="30%"
                center>
                <span>修改QQ号码</span><el-input v-model="input" placeholder="请输入内容"></el-input>
                <span slot="footer" class="dialog-footer">
                    <el-button type="primary" @click="changeqqOpen">确 定</el-button>
                    <el-button @click="centerDialogVisible = false">取 消</el-button>
                </span>
                </el-dialog>
            </div>
            <!-- 修改地区弹框 -->
            <!-- 查看店铺弹框 -->
            <!-- 查看银行卡弹框 -->
        </div>
    </div>    
</template>

<script>
export default {
    data () {
      return {
        radio: '1',
        centerDialogVisible: false,
        centerDialogVisible1:false,
        input:''
      };
    },
    methods:{
        renewVip(){//续费VIP
            console.log('续费VIP')
        },
        changeHead(){//修改头像
            this.centerDialogVisible1 = true
        },
        uploadHead(){//上传头像
            this.centerDialogVisible1 = false
            this.$message({
              type: 'success',
              message:'头像修改成功'
            });
            //图片过大上传失败提醒
        },
        changeqq(){//修改QQ
            console.log('修改QQ')
            this.centerDialogVisible  = true
        },
        changeqqOpen(){//确认修改QQ
            this.centerDialogVisible = false
            this.$message({
                type: 'success',
                message:'QQ修改成功'
            });
        },
        changecity(){//修改城市
            console.log('修改城市')
        },
        lookShop(){//店铺查看
            console.log('店铺查看')
        },
        lookCard(){//银行卡查看
            console.log('银行卡查看')
        },
        handleClose(done) {
            this.$confirm('确认关闭？')
            .then(_ => {
                done();
            })
            .catch(_ => {});
        }
    }
}
</script>

<style scoped>
h3{
    font-size: 20px;
    text-align: center;
}
.accountDetail{
    position: relative;
    width: 350px;
    height: 660px;
    margin: 0 auto;
    display: flex;
    flex-direction: column;
}
.accountDetail>div{
    line-height: 52px;
}
.headImg{
    width: 100px;
    height: 100px;
    margin: 20px auto;
}
.headImg .img{
    width: 100px;
    height: 100px;
}
.h100{
    width: 100px;
    height: 100px;
    border-radius: 50%;
}
.time{
    position: absolute;
    top: 210px;
    color: #ccc;
    font-size: 14px;
}
.h66{
    height: 66px;
}
.w130{
    display: inline-block;
    width: 130px;
}
.renewvip{
    position: absolute;
    top: 203px;
    right: 5px;
}
.plimg{
    position: absolute;
    left: 150px;
    top: 120px;
}
.renew{
    position: relative;
    top: 50px;
    left: 145px;
}
/* .accountDetail el-button{
    width: 80px;
} */
</style>
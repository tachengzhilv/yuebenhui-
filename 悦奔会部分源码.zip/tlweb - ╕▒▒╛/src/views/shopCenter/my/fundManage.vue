<template>
    <div>
        <!-- 资金管理 -->
        <h3>个人中心</h3>
        <router-view></router-view>
    </div>
</template>

<script>
export default {
    name:'fundManage'
}
</script>

<style scoped>

</style>

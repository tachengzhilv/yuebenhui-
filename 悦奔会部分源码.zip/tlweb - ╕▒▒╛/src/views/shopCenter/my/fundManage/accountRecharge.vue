<template>
    <div class="pad20">
        <h3>账号充值</h3>    
        <div class="accountRecharge">
            <div>
                <div>可用余额：￥0.00</div>
            </div>
            <div>
                <div>
                    充值方式：
                            <el-radio v-model="radio" label="1">支付宝</el-radio>
                            <el-radio v-model="radio" label="2">微信</el-radio>
                </div>
            </div>
            <div>
                <div>
                    充值类型：
                            <el-radio v-model="radio1" label="3">余额充值</el-radio>
                </div>
            </div>
            <div>
                <div>
                    充值金额：<el-input v-model="input" placeholder="每次充值金额不可低于1元" class="input"></el-input>
                </div>
            </div>
            
            <div class="warn">
                <img src="" alt="">
                <p class="warning">悦奔会不提供刷单刷单/刷销量/炒作信用等服务，
                    若商家利用平台进行以上活动或在转账信息中备注以上信息，
                    将依据《悦奔会商家处罚规则》处以立即清退及终生不予合作的处罚。</p>
            </div>
            <div>
                <!-- 确认充值 -->
                <el-button class="confirm" @click="confirm">确认充值</el-button>
                <p class="reds">注意在第三方支付时,请在15分钟内完成支付</p>
            </div>
            <!-- 弹框 -->
            <!-- 确认充值弹框成功 -->
            <div>
                <div v-if="false">
                    <el-button type="text" @click="centerDialogVisible = true">点击打开 Dialog</el-button>
                </div>

                <div>
                    <el-dialog
                    title="提示"
                    :visible.sync="centerDialogVisible"
                    width="30%"
                    center>
                    <span>需要注意的是内容是默认不居中的</span>
                    <span slot="footer" class="dialog-footer">
                        <el-button type="primary" @click="centerDialogVisible = false">确 定</el-button>
                        <el-button @click="centerDialogVisible = false">取 消</el-button>
                    </span>
                    </el-dialog>
                </div>
            </div>
            <!-- 确认充值余额不足 -->
            <div>
                <div v-if="false">
                    <el-button type="text" @click="centerDialogVisible1 = true">点击打开 Dialog</el-button>
                </div>

                <div>
                    <el-dialog
                    title="提示"
                    :visible.sync="centerDialogVisible1"
                    width="30%"
                    center>
                    <span>需要注意的是内容是默认不居中的</span>
                    <span slot="footer" class="dialog-footer">
                        <el-button @click="centerDialogVisible1 = false">取 消</el-button>
                        <el-button type="primary" @click="centerDialogVisible1 = false">确 定</el-button>
                    </span>
                    </el-dialog>
                </div>
            </div>
            <!-- 确认充值密码错误 -->
            <div>
                <div v-if="false">
                    <el-button type="text" @click="centerDialogVisible2 = true">点击打开 Dialog</el-button>
                </div>

                <div>
                    <el-dialog
                    title="提示"
                    :visible.sync="centerDialogVisible2"
                    width="30%"
                    center>
                    <span>需要注意的是内容是默认不居中的</span>
                    <span slot="footer" class="dialog-footer">
                        <el-button @click="centerDialogVisible2 = false">取 消</el-button>
                        <el-button type="primary" @click="centerDialogVisible2 = false">确 定</el-button>
                    </span>
                    </el-dialog>
                </div>
            </div>
        </div>
        <!-- 温馨提示 -->
        <div class="last">
            <p class="noti">温馨提示：</p>
            <p class="notice">&nbsp;&nbsp;1.信用卡支付时银行会自动提示风险安全提醒，可继续支付，请勿担心；</p>
            <p class="notice">&nbsp;&nbsp;2.请注意您的银行卡充值限制，以免造成不便；</p>
            <p class="notice">&nbsp;&nbsp;3.如果充值金额没有及时到账，请联系客服</p>
        </div>
    </div>    
</template>

<script>
export default {
    data(){
        return{
            radio:'1',
            radio1:'3',
            input:'',
            centerDialogVisible:false,
            centerDialogVisible1:false,
            centerDialogVisible2:false
        }
    },
    methods:{
        confirm(){
            console.log('确认充值')
            // this.centerDialogVisible = true
            this.$message({
              type: 'success',
              message:'充值成功'
            });
        }
    }
}
</script>

<style scoped>
h3{
    font-size: 20px;
    text-align: center;
}
.accountRecharge{
    margin: 80px 0 0 135px;
    display: flex;
    flex-direction: column;
    justify-content: space-around;
    height: 450px;
}
.warning{
    width: 645px;
    line-height: 21px;
    font-size: 13px;
    color: #f38c20;
}
.noti{
    font-size: 16px;
    line-height: 22px;
}
.notice{
    font-size: 13px;
    line-height: 38px;
    color: #666;
}
.input{
    width: 400px;
}
.last{
    margin: 20px 0 0 135px;
}
.reds{
    position: relative;
    top: 30px;
    left: 130px;
    color: red;
    font-size: 13px;
}
.confirm{
    position: relative;
    top: 20px;
    left: 50px;
    width: 450px;
    height: 60px;
    border: none;
    font-size: 20px;
    color: #fff;
    background-color: #f38c20;
    border-radius: 50px;
}
</style>
<template>
    <div class="applyCash">
        <h3>申请提现</h3>
        <div class="applyInfo">
            <div>
                可提现金额：￥80.00<el-button class="history" @click="applyHistory">提现记录</el-button>
            </div>
            <div class="card">
                可用银行卡：
                <ul class="cardManage">
                    <li>
                        <img src="http://pic32.nipic.com/20130823/13339320_183302468194_2.jpg" alt="">
                        <p>王**</p>
                    </li>
                    <li>
                        <img src="http://pic32.nipic.com/20130823/13339320_183302468194_2.jpg" alt="">
                        <p>王**</p>
                    </li>
                </ul>
            </div>
            <div>
                提现金额：<el-input v-model="input" style="width:200px"></el-input>
                <span v-if="show" class="c1">单次最少提现500元，提现操作平台将收取<span>6%</span>手续费</span>
                <span v-else style="color:red">*提现金额不可低于500</span>
                <div class="time">
                    <p>预计3-5个工作日内（国家法定节假日和双休日顺延）平台完成提现操作。</p>
                    <p>到账时间以各大银行为准，预计3-7个工作日左右。</p>
                </div>
            </div>
            <div class="number">
                实际到账金额：
            </div>
            <div>
                支付密码：<el-input v-model="input1" style="width:200px"></el-input>
            </div>
            <div>
                填写完信息记得加背景的类名控制颜色
                <el-button class="confirm" @click="confirm">确认提现</el-button>
            </div>
            <div class="last">
                <p class="f20">温馨提示：</p>
                <p>1.请确保您输入的提现金额，以及银行账户信息准确无误；</p>
                <p>2.提现需缴纳提现金额的<span>6%</span>作为提现手续费；(用户首次提现免手续费)</p>
                <p>3.单次提现最少500元，以10的倍数提现；(用户首次提现只需以10的倍数提现，不受最少数限制)</p>
                <p>4.悦奔会会在3-5个工作日内处理(国家法定节假日和双休日顺延)。处理成功后，预计3-7个工作日到达您绑定的银行卡；</p>
                <p>5.悦奔会禁止洗钱、信用卡套现、虚假交易等行为，一经发现并确认将终止该账号的使用，悦奔会不承担由此导致的一切损失。</p>
            </div>
            <!-- 弹框
            确认提现成功弹框 -->
            <div>
                <div v-if="false">
                    <el-button type="text" @click="centerDialogVisible = true">点击打开 Dialog</el-button>
                </div>

                <div>
                    <el-dialog
                    title="提示"
                    :visible.sync="centerDialogVisible"
                    width="30%"
                    center>
                    <span>需要注意的是内容是默认不居中的</span>
                    <span slot="footer" class="dialog-footer">
                        <el-button @click="centerDialogVisible = false">取 消</el-button>
                        <el-button type="primary" @click="centerDialogVisible = false">确 定</el-button>
                    </span>
                    </el-dialog>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    data(){
        return{
            show:true,
            input:'',
            input1:'',
            centerDialogVisible: false
        }
    },
    computed:{
        //计算提现金额是否大于500
    },
    methods:{
        confirm(){
            this.$message({
              type: 'success',
              message:'提现成功'
            });
            // this.$message({
            //   type: 'error',
            //   message:'提现失败'
            // });
        },
        applyHistory(){//提现记录
            this.$router.push('/applyHistory')
        }
    }
}
</script>

<style scoped>
h3{
    font-size: 20px;
    text-align: center;
}
.applyInfo{
    box-sizing: border-box;
    margin-top: 70px;
    padding-left: 85px;
}
.history{
    margin-left: 20px;
}
.card{
    margin-top:20px;
}
ul li{
    list-style: none;
}
.cardManage{
    display: flex;
    flex-wrap: wrap;
    position: relative;
    left: 100px;
    top: -15px;
    width: 700px;
}
.cardManage li{
    width: 310px;
    margin-right: 34px;
}
.cardManage img{
    width: 310px;
    height: 160px;
    border-radius: 10px;
}
.cardManage li p{
    text-align: center;
}
.time{
    position: relative;
    left: 80px;
    top: 3px;
    font-size: 13px;
    color: #898989;
}
.c1{
    color: #ccc;
}
.number{
    margin: 20px 0;
}
.confirm{
    margin: 60px 0 50px 130px;
    width: 450px;
    height: 60px;
    font-size: 20px;
    background-color: #ddd;
    border-radius: 50px;
    border: none;
    color: #fff;
}
.last .f20{
    font-weight: bold;
    color: #000;
}
.last p{
    font-size: 14px;
    color: #666;
}
.isactive{
    background-color: #f28d1e;
}
</style>
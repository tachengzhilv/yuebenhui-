<template>
    <div>
        <h3>提现记录</h3>
        <div class="choose">
             <div class="block">
                <span class="demonstration">时间：</span>
                <el-date-picker
                v-model="value1"
                type="date"
                placeholder="选择日期">
                </el-date-picker>
            </div>
            <div class="avtive">
                状态：
                <el-select v-model="value" placeholder="请选择">
                    <el-option
                    v-for="item in options"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value">
                    </el-option>
                </el-select>
            </div>
            <div>
                <el-button class="search">搜索</el-button>
            </div>
            <p class="notice">因数据较大，明细仅供查询近3个月提现记录</p>
        </div>
        <div class="message">
            <el-table
                :data="tableData"
                stripe
                style="width: 100%">
                <el-table-column
                prop="date"
                label="申请提现时间"
                width="180">
                </el-table-column>
                <el-table-column
                prop="name"
                label="提现交易单号"
                width="180">
                </el-table-column>
                <el-table-column
                prop="address"
                label="金额">
                </el-table-column>
                <el-table-column
                prop="reality"
                label="实际到账金额">
                </el-table-column>
                <el-table-column
                prop="status"
                label="状态">
                </el-table-column>
            </el-table>
        </div>
    </div>
</template>

<script>
export default {
    data(){
        return{
            value1:'',
            value: '',
            options: [{
                value: '选项1',
                label: '黄金糕'
            }, {
                value: '选项2',
                label: '双皮奶'
            }, {
                value: '选项3',
                label: '蚵仔煎'
            }, {
                value: '选项4',
                label: '龙须面'
            }, {
                value: '选项5',
                label: '北京烤鸭'
            }],
            tableData: [{
                date: '2016-05-02 13:00:06',
                name: 'P8516321566208252',
                address: '500',
                reality:'450',
                status:'已完成'
                }, {
                date: '2016-05-04 13:00:06',
                name: 'P8516321566208252',
                address: '300',
                reality:'350',
                status:'待审核'
                }, {
                date: '2016-05-01 13:00:06',
                name: 'P8516321566208252',
                address: '800',
                reality:'850',
                status:'被驳回'
                }, {
                date: '2016-05-03 13:00:06',
                name: 'P8516321566208252',
                address: '1000',
                reality:'900',
                status:'已完成'
            }]
        }
    }
}
</script>

<style scoped>
h3{
    font-size: 20px;
    text-align: center;
}
.choose{
    position: relative;
    display: flex;
    box-sizing: border-box;
    margin-top: 80px;
    padding-left: 70px;
}
.avtive{
    margin: 0 20px;
}
.search{
    border-color: #f18c1d;
    color: #f18c1d;
}
.notice{
    position: absolute;
    top: 43px;
    left: 124px;
    font-size: 13px;
    color: #cdcdcd;
}
.message{
    box-sizing: border-box;
    margin-top: 60px;
    padding-left: 70px;
}
</style>

<template>
    <div>
        <h3>余额明细</h3>
        <div class="choose">
             <div class="block">
                <span class="demonstration">时间：</span>
                <el-date-picker
                v-model="value1"
                class="w150"
                type="date"
                placeholder="选择日期">
                </el-date-picker>
            </div>
            <div class="number">
                活动编号：<el-input v-model="input" class="w150"></el-input>
            </div>
            <div class="avtive">
                收入类型：
                <el-select v-model="value" placeholder="请选择">
                    <el-option
                    v-for="item in options"
                    :key="item.value"
                    class="w150"
                    :label="item.label"
                    :value="item.value">
                    </el-option>
                </el-select>
            </div>
            <div>
                <el-button class="search">搜索</el-button>
            </div>
            <p class="notice">因数据较大，明细仅供查询近3个月提现记录</p>
        </div>
        <div class="message">
            <el-table
                :data="tableData"
                stripe
                style="width: 100%">
                <el-table-column
                prop="date"
                label="时间"
                width="180">
                </el-table-column>
                <el-table-column
                prop="name"
                label="活动编号"
                width="180">
                </el-table-column>
                <el-table-column
                prop="address"
                label="金额">
                </el-table-column>
                <el-table-column
                prop="reality"
                label="结余">
                </el-table-column>
                <el-table-column
                prop="status"
                label="类型">
                </el-table-column>
            </el-table>
        </div>
    </div>
</template>

<script>
export default {
    data(){
        return{
            input:'',
            value:'',
            value1:'',
            options: [{
                value: '选项1',
                label: '黄金糕'
            }, {
                value: '选项2',
                label: '双皮奶'
            }, {
                value: '选项3',
                label: '蚵仔煎'
            }, {
                value: '选项4',
                label: '龙须面'
            }, {
                value: '选项5',
                label: '北京烤鸭'
            }],
            tableData: [{
                date: '2016-05-02 13:00:06',
                name: '18752',
                address: '+500',
                reality:'450',
                status:'已完成'
                }, {
                date: '2016-05-04 13:00:06',
                name: '18752',
                address: '+300',
                reality:'350',
                status:'待审核'
                }, {
                date: '2016-05-01 13:00:06',
                name: '18752',
                address: '+800',
                reality:'850',
                status:'被驳回'
                }, {
                date: '2016-05-03 13:00:06',
                name: '18752',
                address: '+1000',
                reality:'900',
                status:'已完成'
            }]
        }
    }
}
</script>

<style scoped>
h3{
    font-size: 20px;
    text-align: center;
}
.choose{
    position: relative;
    display: flex;
    box-sizing: border-box;
    margin-top: 80px;
    padding-left: 70px;
}
.avtive{
    margin: 0 20px;
}
.search{
    border-color: #f18c1d;
    color: #f18c1d;
}
.number{
    margin-left: 20px;
}
.notice{
    position: absolute;
    top: 43px;
    left: 124px;
    font-size: 13px;
    color: #cdcdcd;
}
.w150{
    width: 150px;
}
.message{
    box-sizing: border-box;
    margin-top: 60px;
    padding-left: 70px;
}
</style>

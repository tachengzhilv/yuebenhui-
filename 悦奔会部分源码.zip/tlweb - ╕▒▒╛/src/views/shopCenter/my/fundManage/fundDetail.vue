<template>
    <div class="pa20">
        <h3>资金管理</h3>
        <div class="fundDetail">
            <div>
                <el-button class="w64 recharge1" @click="balanceRecharge">充值</el-button>
                <p>可用余额</p>
                <p class="marb10">￥6658.56</p>
                <el-button class="w64" @click="balanceDetail">余额明细</el-button><el-button class="w64" @click="applyCash">提现</el-button>
            </div>
            <div>
                <p>担保金额</p>
                <p class="marb10">￥6580.00</p>
                <el-button class="w64" @click="guaranteeMoney">明细</el-button>
            </div>
            <div>
                <el-button class="w64 recharge2" @click="integralRecharge">充值</el-button>
                <p>积分</p>
                <p class="marb10">86952</p>
                <el-button class="w64" @click="integralDetail">明细</el-button>
            </div>
        </div>
        <div>
            <span>已绑定银行卡：2张</span><el-button style="margin-left:20px">银行卡管理</el-button>
        </div>
        <ul class="cardManage">
            <li>
                <img src="http://pic32.nipic.com/20130823/13339320_183302468194_2.jpg" alt="">
                <p>王**</p>
            </li>
            <li>
                <img src="http://pic32.nipic.com/20130823/13339320_183302468194_2.jpg" alt="">
                <p>王**</p>
            </li>
            <li>
                <img src="http://pic32.nipic.com/20130823/13339320_183302468194_2.jpg" alt="">
                <p>王**</p>
            </li>
        </ul>
    </div>
</template>

<script>
export default {
    data(){
        return{

        }
    },
    methods:{
        balanceRecharge(){//余额充值
            console.log('余额充值')
            this.$router.push('/accountRecharge')
        },
        integralRecharge(){//积分充值
            console.log('积分充值')
            this.$router.push('/integralRecharge')
        },
        applyCash(){
            console.log('申请提现')
            this.$router.push('/applyCash')
        },
        balanceDetail(){
            console.log("余额明细")
            this.$router.push('/balanceDetail')
        },
        guaranteeMoney(){
             console.log('担保金额记录')
             this.$router.push('/guaranteeMoney')
        },
        integralDetail(){
            console.log('积分明细')
            this.$router.push('/integralDetail')
        }
    }
}
</script>

<style scoped>
h3{
    font-size: 20px;
    text-align: center;
}
.pa20{
    padding-left: 20px;
}
.fundDetail{
    margin-top: 50px;
    position: relative;
    display: flex;
    justify-content: space-between;
    height: 136px;
    width: 900px;
}
.fundDetail>div{
    text-align: center;
    width: 300px;
}
.fundDetail p{
    margin: 0;
}
.w64{
    padding: 0;
    width: 64px;
    text-align: center;
    line-height: 28px;
}
.recharge1{
    position: absolute;
    top: 6px;
    left: 230px;
    color: red;
    border-color: red;
}
.recharge2{
    position: absolute;
    top: 6px;
    right: 46px;
    color: red;
    border-color: red;
}
.fundDetail .marb10{
    margin-bottom: 10px;
}
ul li{
    list-style: none;
}
.cardManage{
    margin-top: 34px; 
    display: flex;
    flex-wrap: wrap;
}
.cardManage li{
    width: 310px;
    margin-right: 34px;
}
.cardManage img{
    width: 310px;
    height: 160px;
    border-radius: 10px;
}
.cardManage li p{
    text-align: center;
}
</style>
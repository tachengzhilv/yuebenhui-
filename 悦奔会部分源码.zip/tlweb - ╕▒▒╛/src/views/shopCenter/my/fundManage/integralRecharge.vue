<template>
    <div>
        <h3>积分充值</h3>
        <div class="integral">
            <div>
                积&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;分：89652
            </div>
            <div>
                可用余额：￥0.00  <el-button>充值余额</el-button>
            </div>
            <div>
                充值方式：<el-radio v-model="radio" label="1">余额兑换</el-radio>
            </div>
            <div>
                兑换金额：<el-input v-model="input" placeholder="每次充值不可低于10元" class="number"></el-input>
                <p class="scale">积分兑换比例为： 1:1</p>
            </div>
            <div>
                <img src="" alt="">
                <p class="notice">悦奔会不会提供刷单/刷销量/炒作信用等服务，若商家利用平台进行以上活动或在转账信息中备注以上信息，将依据《悦奔会商家处罚规则》处以立即清退及终生不予合作的处罚。</p>
            </div>
            <div>
                 <!-- gray判断余额不足后添加按钮类名和显示p标签 -->
                <el-button class="confirm">确认充值</el-button>
                <p v-if="show" class="btnn">可用余额不足</p>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    data(){
        return{
            radio:'1',
            input:'',
            show: false
        }
    }
}
</script>

<style scoped>
h3{
    font-size: 20px;
    text-align: center;
}
.integral{
    position: relative;
    box-sizing: border-box;
    display: flex;
    flex-direction: column;
    justify-content: space-around;
    margin-top:80px;
    padding-left: 130px;
    height: 450px;
}
.number{
    width: 200px;
}
.scale{
    position: relative;
    top: -30px;
    left: 290px;
    font-size: 14px;
    color: #ccc;
}
.notice{
    margin-left: 20px;
    width: 630px;
    font-size: 13px;
    color: #f2952d;
}
.confirm{
    position: relative;
    top: 20px;
    left: 120px;
    width: 450px;
    height: 60px;
    color: #fff;
    border: none;
    background-color: #f18c1d;
    border-radius: 50px;
}
.gray{
    background-color: #ccc;
    color: #656565;
}
.btnn{
    position: absolute;
    bottom: -28px;
    left: 437px;
    font-size: 13px;
    color: #f18c1d;
}
</style>

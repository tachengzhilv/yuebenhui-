<template>
    <div>
        <!-- 邀请返利 -->
        <h3>个人中心</h3>
        <router-view></router-view>
    </div>
</template>

<script>
export default {
    name:'inviteRebate'
}
</script>

<style scoped>

</style>

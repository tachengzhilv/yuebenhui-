<template>
    <div>
        <h3>邀请返利</h3>
    </div>
</template>

<script>
export default {
    
}
</script>

<style scoped>
h3{
    margin-top: 40px;
    font-size: 20px;
    text-align: center;
}
</style>
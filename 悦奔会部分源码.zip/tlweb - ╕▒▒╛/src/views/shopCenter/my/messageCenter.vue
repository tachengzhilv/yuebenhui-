<template>
    <div>
        <!-- 消息中心 -->
        <h3>个人中心</h3>
        <router-view></router-view>
    </div>
</template>

<script>
export default {
    name:'messageCenter'
}
</script>

<style scoped>

</style>
<template>
    <div>
        <h3>消息中心</h3>
        <div>
            <el-tabs v-model="activeName" @tab-click="handleClick">
                <el-tab-pane label="全部消息" name="first">
                    <el-table
                    :data="tableData"
                    ref="table"
                    @select="select"
                    style="width: 100%">
                    <el-table-column
                    type="selection"
                    @selection-change="changeFun"
                    >
                    </el-table-column>
                    <el-table-column
                    fixed
                    prop="date"
                    label="状态"
                    align='center'
                    width="120">
                    </el-table-column>
                    <el-table-column
                    prop="name"
                    label="主题"
                    align='center'
                    width="120">
                    </el-table-column>
                    <el-table-column
                    prop="address"
                    label="内容"
                    align='center'
                    :show-overflow-tooltip='true'
                    width="300">
                    </el-table-column>
                    <el-table-column
                    prop="zip"
                    label="时间"
                    align='center'
                    width="120">
                    </el-table-column>
                    <el-table-column
                    fixed="right"
                    align='center'
                    label="操作"
                    width="120">
                    <template slot-scope="scope">
                        <el-button
                        @click.native.prevent="unread(scope.$index, tableData)"
                        type="text"
                        size="small">
                        标为未读
                        </el-button>
                        <el-button
                        @click.native.prevent="deleteRow(scope.$index, tableData)"
                        type="text"
                        size="small">
                        删除
                        </el-button>
                    </template>
                    </el-table-column>
                </el-table>
                </el-tab-pane>
                <el-tab-pane label="未读消息" name="second">

                </el-tab-pane>
                <el-tab-pane label="已读消息" name="third">
                    
                </el-tab-pane>
            </el-tabs>
        </div>
    </div>
</template>

<script>
export default {
    data() {
      return {
        activeName: 'first',
         tableData: [{
          date: '2016-05-03',
          name: '王小虎',
          province: '上海',
          city: '普陀区',
          address: '上海市普陀区金沙江路 1518 弄',
          zip: 200333
        }, {
          date: '2016-05-02',
          name: '王小虎',
          province: '上海',
          city: '普陀区',
          address: '上海市普陀区金沙江路 1518 弄上海市普陀区金沙江路 1518 弄',
          zip: 200333
        }, {
          date: '2016-05-04',
          name: '王小虎',
          province: '上海',
          city: '普陀区',
          address: '上海市普陀区金沙江路 1518 弄',
          zip: 200333
        }, {
          date: '2016-05-01',
          name: '王小虎',
          province: '上海',
          city: '普陀区',
          address: '上海市普陀区金沙江路 1518 弄',
          zip: 200333
        }, {
          date: '2016-05-08',
          name: '王小虎',
          province: '上海',
          city: '普陀区',
          address: '上海市普陀区金沙江路 1518 弄',
          zip: 200333
        }, {
          date: '2016-05-06',
          name: '王小虎',
          province: '上海',
          city: '普陀区',
          address: '上海市普陀区金沙江路 1518 弄',
          zip: 200333
        }, {
          date: '2016-05-07',
          name: '王小虎',
          province: '上海',
          city: '普陀区',
          address: '上海市普陀区金沙江路 1518 弄',
          zip: 200333
        }]
      };
    },
    methods: {
      handleClick(tab, event) {
        // console.log(tab, event);
      },
      deleteRow(index, rows) {//删除
          console.log(index)
        rows.splice(index, 1);
      },
      unread(index, rows){//未读标记
          console.log(index)
      },
      changeFun(val){
          
      },
      select(){
          console.log(1)
      }
    }
}
</script>

<style scoped>
h3{
    margin-top: 40px;
    font-size: 20px;
    text-align: center;
}
</style>
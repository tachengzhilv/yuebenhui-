<template>
    <div>
        <!-- 安全中心 -->
        <h3>个人中心</h3>
        <router-view></router-view>
    </div>
</template>

<script>
export default {
    name:'securityCenter'
}
</script>

<style scoped>

</style>

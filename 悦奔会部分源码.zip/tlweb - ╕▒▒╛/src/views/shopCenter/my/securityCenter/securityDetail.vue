<template>
    <div>
        <h3>安全中心</h3>
    </div>
</template>

<script>
export default {
    
}
</script>

<style scoped>
h3{
    margin-top: 40px;
    font-size: 20px;
    text-align: center;
}
</style>
<template>
    <div>
      <!-- 开通续费vip -->
      <h3>个人中心</h3>
      <router-view></router-view>
    </div>
</template>

<script>
    export default {
        name: "vip",
        data() {
            return {}
        },
        methods: {}
    }
</script>

<style scoped>

</style>

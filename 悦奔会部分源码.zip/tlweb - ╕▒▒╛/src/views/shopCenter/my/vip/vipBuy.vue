<template>
    <div>
        <h3>支付</h3>
        <div class="infoList">
            <div>
                当前等级：
                <div class="right">
                    <p class="top">VIP商家，会员有效期剩余59天</p>
                    <p class="bottom">到期时间：2019-08-12 22:05:49</p>
                </div>
            </div>
            <div>
                开通类型：<span>VIP商家</span>
            </div>
            <div>
                开通时长：1个月
            </div>
            <div>
                有效期至：2019年05月08日

            </div>
            <div>
                应付金额：279元

            </div>
            <div>
                支付方式：<el-radio v-model="radio" label="1">账户余额支付</el-radio>

            </div>
            <p class="security">安全设置检查成功！无需短信验证。</p>
            <div>
                支付密码：
                <el-input placeholder="请输入密码" v-model="input" show-password class="w140"></el-input>
                <span class="forget">忘记密码？</span>
                <p class="six">请输如6位数字支付密码</p>
            </div>
        </div>
        <div>
            <el-button class="confirm">确认付款</el-button>
        </div>
    </div>
</template>

<script>
export default {
    data(){
        return{
            radio:'1',
            input:''
        }
    }
}
</script>

<style scoped>
h3{
    font-size: 20px;
    text-align: center;
}
.infoList{
    position: relative;
    margin: 95px 0 0 320px;
}
.infoList>div{
    line-height: 55px;
}
.right{
    float: right;
}
.right p{
    margin: 0;
}
.right .top{
    position: absolute;
    left: 84px;
    font-size: 15px;
}
.right .bottom{
    position: absolute;
    top: 18px;
    left: 84px;
    color: #888;
    font-size: 13px;
}
.security{
    position: relative;
    top: -10px;
    font-size: 14px;
    color: #888;
}
.w140{
    width: 140px;
    /* border:1px solid #ddd; */
}
.forget{
    font-size: 14px;
    color: #9b9b9b;
}
.six{
    margin: 0;
    position: relative;
    top: -22px;
    left: 85px;
    font-size: 13px;
    color: #ddd;
}
.confirm{
    position: relative;
    left: 250px;
    width: 450px;
    height: 60px;
    font-size: 18px;
    color: #fff;
    border: none;
    background-color: #f18321;
    border-radius: 50px;
}
</style>
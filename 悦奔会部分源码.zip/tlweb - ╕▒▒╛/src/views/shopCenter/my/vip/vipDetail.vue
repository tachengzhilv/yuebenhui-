<template>
    <div>
        <h3>开通/续费VIP</h3>    
        <p class="look" @click="vipInfo">VIP特权介绍，查看>></p>
        <div class="vip">
            <div class="vleft">
                <div>
                    当前等级：<p class="day">VIP商家，会员有效期剩59天</p>
                             <p class="time">到期时间：2019-08-12  22:05:49</p>
                    <el-button class="history" @click="history">VIP购买记录</el-button>
                </div>
                <div>
                    开通类型：<el-radio v-model="radio" label="1">VIP商家</el-radio>
                </div>
                <div>
                    开通时常：
                        <el-radio v-model="radio2" label="2">1个月</el-radio>
                        <el-radio v-model="radio2" label="3">12个月</el-radio>
                </div>
                <div>
                    有效期至：2019年05月08日
                </div>
                <div>
                    原价：<span style="text-decoration:line-through">298元</span>
                </div>
                <div>
                    优惠：<span>20元</span>
                </div>
                <div>
                    应付金额：<span>279元</span>
                </div>
                <div>
                    支付方式：<el-radio v-model="radio3" label="4">账户余额支付 <span>860元</span></el-radio>
                        <el-button @click="balanceRecharge">充值</el-button>
                </div>
                <div>
                    <el-button v-if="show" class="btn">申请开通</el-button>
                    <el-button v-else class="btn gray">可用余额不足，请先充值</el-button>
                </div>
            </div>
            <div class="vright">
                <div class='vipno'>VIP提示</div>
                <p>1.悦奔会VIP服务以套餐的形式提供；</p>
                <p>2.支付会费后会员特权及时生效，如遇问题请联系客服；</p>
                <p>3.一旦加入悦奔会VIP会员，会员费套餐费不予退还；</p>
                <p>4.禁止洗钱、信用卡套现、虚假交易等行为，一经发现并确认，将直接终止该账号的试用；</p>
                <p>5.VIP服务期间，因不可抗力因素导致的会员服务异常情况，悦奔会有权采取相应调整措施；</p>
                <p>6.本次活动最终解释权归悦奔会所有。</p>
            </div>
        </div>
    </div>    
</template>

<script>
export default {
    data(){
        return{
            radio:'1',
            radio2:'2',
            radio3:'4',
            show:true
        }
    },
    methods:{
        vipInfo(){
            this.$router.push('/vipIntroduction')
        },
        history(){
            this.$router.push('/vipHistory')
        },
        balanceRecharge(){//余额充值
            console.log('余额充值')
            this.$router.push('/accountRecharge')
        }
    }
}
</script>

<style scoped>
h3{
    font-size: 20px;
    text-align: center;
}
.look{
    position: relative;
    left: 417px;
    font-size: 13px;
    color: red;
}
.vip{
    position: relative;
    display: flex;
    box-sizing: border-box;
    margin: 24px 20px 0;
    padding: 24px 0 0 36px;
    height: 665px;
    border:1px solid #ffead2;
    border-radius: 10px;
}
.vleft{
    display: flex;
    flex-direction: column;
    justify-content: space-around;
    width: 485px;
    border-right: 1px solid #ddd;
}
.vright{
    /* box-sizing: border-box; */
    padding: 13px;
    width: 348px;
    font-size: 14px;
}
.vright p{
    line-height: 36px;
    color: #666;
}
.day{
    position: absolute;
    top: 47px;
    left: 115px;
}
.time{
    position: absolute;
    top: 66px;
    left: 120px;
    font-size: 13px;
    color: #929292;
}
.history{
    position: absolute;
    top: 46px;
    left: 340px;
}
.vright .vipno{
    margin: 20px 0 40px;
    font-size: 17px;
    text-align: center;
}
.btn{
    width: 450px;
    height: 60px;
    border-radius: 50px;
    color: #fff;
    font-size: 18px;
    background-color: #f38c20;
}
.gray{
    background-color: #ccc;
    color: #888;
}
</style>
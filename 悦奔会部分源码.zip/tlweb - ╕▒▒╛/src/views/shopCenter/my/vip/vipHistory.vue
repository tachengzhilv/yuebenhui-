<template>
    <div>
        <h3>VIP购买记录</h3>
        <div class="message">
            <el-table
                :data="tableData"
                stripe
                style="width: 100%">
                <el-table-column
                prop="date"
                label="购买时间"
                width="180">
                </el-table-column>
                <el-table-column
                prop="name"
                label="开通类型"
                width="140">
                </el-table-column>
                <el-table-column
                prop="address"
                label="开通时长">
                </el-table-column>
                <el-table-column
                prop="reality"
                label="金额">
                </el-table-column>
                <el-table-column
                prop="time"
                label="到期时间"
                width="180">
                </el-table-column>
                <el-table-column
                prop="status"
                label="状态">
                </el-table-column>
            </el-table>
        </div>
    </div>
</template>

<script>
export default {
    data(){
        return{
            value1:'',
            value: '',
            options: [{
                value: '选项1',
                label: '黄金糕'
            }, {
                value: '选项2',
                label: '双皮奶'
            }, {
                value: '选项3',
                label: '蚵仔煎'
            }, {
                value: '选项4',
                label: '龙须面'
            }, {
                value: '选项5',
                label: '北京烤鸭'
            }],
            tableData: [{
                date: '2016-05-02 13:00:06',
                name: 'VIP商家',
                address: '1个月',
                reality:'450',
                time:'2017-05-02 13:00:06',
                status:'已完成'
                }, {
                date: '2016-05-04 13:00:06',
                name: 'VIP商家',
                address: '1个月',
                reality:'350',
                time:'2017-05-02 13:00:06',
                status:'待审核'
                }, {
                date: '2016-05-01 13:00:06',
                name: 'VIP商家',
                address: '1个月',
                reality:'850',
                time:'2017-05-02 13:00:06',
                status:'被驳回'
                }, {
                date: '2016-05-03 13:00:06',
                name: 'VIP商家',
                address: '1个月',
                reality:'900',
                time:'2017-05-02 13:00:06',
                status:'已完成'
            }]
        }
    }
}
</script>

<style scoped>
h3{
    font-size: 20px;
    text-align: center;
}
.message{
    box-sizing: border-box;
    margin-top: 60px;
    padding-left: 20px;
}
</style>

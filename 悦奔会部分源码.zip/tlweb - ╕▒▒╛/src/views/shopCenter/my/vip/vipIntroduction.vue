<template>
  <div class="vip">
      <h3>VIP介绍</h3>
      <table cellspacing='0'>
          <tr>
              <th colspan="2" class="w250 h80 red tf">会员权益</th>
              <th class="w365 orange">功能解析</th>
              <th class="w96 green">普通商家</th>
              <th class="w96 green">VIP商家</th>
              <th class="w96 green tr">
                  <!-- 一次性支付12个月(赠送积分) -->
                  <p style="height:22px;margin:0">一次性支付</p>
                  <p style="height:22px;margin:0">12个月</p>
                  <p style="height:22px;margin:0">(赠送积分)</p>
              </th>
          </tr>
          <tr>
              <td colspan="2">绑定店铺</td>
              <td class="textl">1个账号可免费绑定3个，可绑定京东、淘宝、天猫、拼多多</td>
              <td>3</td>
              <td>4</td>
              <td>5</td>
          </tr>
          <tr>
              <td rowspan="4">基础任务</td>
              <td>基础权重</td>
              <td class="textl">关键词优化/重复进店</td>
              <td>4</td>
              <td>5</td>
              <td>6</td>
          </tr>
          <tr>
              <td>人群打标</td>
              <td class="textl">根据使用商品的类目，对试客进行打标</td>
              <td>4</td>
              <td>5</td>
              <td>6</td>
          </tr>
          <tr>
              <td>活动置顶</td>
              <td class="textl">将活动置顶到所有列表前面</td>
              <td>4</td>
              <td>5</td>
              <td>6</td>
          </tr>
          <tr>
              <td>安全防护</td>
              <td class="textl">设置黑名单，禁止老客中奖/防IP防小号，每月赠送名额5个</td>
              <td>4</td>
              <td>5</td>
              <td style="font-size:12px">
                  <!-- 开通当月赠送10个黑名单名额 -->
                 <p style="margin:0">开通当月赠送</p>
                 <p style="margin:0">10个黑名单名额</p>
              </td>
          </tr>
          <tr>
              <td rowspan="7">试客账号控制</td>
              <td>实名认证</td>
              <td class="textl">支付宝、银行卡、淘宝买号</td>
              <td>4</td>
              <td>5</td>
              <td>6</td>
          </tr>
          <tr>
              <td>试客信用等级匹配</td>
              <td class="textl">杜绝恶意试客</td>
              <td>4</td>
              <td>5</td>
              <td>6</td>
          </tr>
          <tr>
              <td>试客淘气值匹配</td>
              <td class="textl">匹配优质试客</td>
              <td>4</td>
              <td>5</td>
              <td>6</td>
          </tr>
          <tr>
              <td>试客消费能力</td>
              <td class="textl">匹配优质试客</td>
              <td>4</td>
              <td>5</td>
              <td>6</td>
          </tr>
          <tr>
              <td>试客购物偏好</td>
              <td class="textl">分析试客购买偏好，匹配优质试客</td>
              <td>4</td>
              <td>5</td>
              <td>6</td>
          </tr>
          <tr>
              <td>试客基础属性</td>
              <td class="textl">系统根据试客性别、年龄、收入、地区等筛选优质试客</td>
              <td>4</td>
              <td>5</td>
              <td>6</td>
          </tr>
          <tr>
              <td>定期账号安全检查</td>
              <td class="textl">定期排查试客账号，防止不安全账号</td>
              <td>4</td>
              <td>5</td>
              <td>6</td>
          </tr>
          <tr>
              <td rowspan="4" class="bl">服务</td>
              <td>入驻咨询</td>
              <td class="textl">全方位解决入驻问题</td>
              <td>4</td>
              <td>5</td>
              <td>6</td>
          </tr>
          <tr>
              <td>一对一客服</td>
              <td class="textl">专属客服，全程指导辅助</td>
              <td>4</td>
              <td>5</td>
              <td>6</td>
          </tr>
          <tr>
              <td>7*15小时在线客服</td>
              <td class="textl">随时随地解决问题</td>
              <td>4</td>
              <td>5</td>
              <td>6</td>
          </tr>
          <tr>
              <td>免费培训</td>
              <td class="textl">增加商家能力，提升销量</td>
              <td>4</td>
              <td>5</td>
              <td class="br">6</td>
          </tr>
      </table>
      <el-button class="open" @click="open">开通会员</el-button>
  </div>
</template>

<script>
  export default {
    data(){
        return{

        }
    },
    methods:{
        open(){
            this.$router.push('/vipBuy')
        }
    }
  }
</script>

<style scoped>
h3{
    font-size: 20px;
    text-align: center;
}
.vip{
    padding: 0 20px;
}
.open{
    margin: 50px 0 100px 250px;
    width: 450px;
    line-height: 60px;
    font-size: 20px;
    color: #fff;
    background-color: #f28f22;
    border: none;
    border-radius: 40px;
}
.tf{
    border-top-left-radius: 10px;
}
.tr{
    border-top-right-radius: 10px;
}
.bl{
    border-bottom-left-radius: 10px;
}
.br{
    border-bottom-right-radius: 10px;
}
table{
    margin-top: 50px;
    border: 1px solid #ffe9d4;
    border-radius: 10px;
}
th{
    width: 50px;
    border: 1px solid #ddd;
    text-align: center;
}
td{
    height: 55px;
    border: 1px solid #ddd;
    text-align: center;
}
.w250{
    width: 250px;
}
.w365{
    width: 365px;
}
.w96{
    width: 96px;
}
.h80{
    height: 80px;
}
.textl{
    text-align: left;
}
.red{
    color: #fff;
    background-color:#f31e1d;
}
.orange{
    color: #fff;
    background-color: #f28b1d;
}
.green{
    color: #fff;
    background-color: #61cb0a;
}
</style>
<template>
    <div>
      <!-- 图片轮播-->
      <el-carousel class="banner" arrow="never">
        <el-carousel-item v-for="(item,index) in this.swiper" :key="index">
          <img :src="item"/>
        </el-carousel-item>
      </el-carousel>

      <!-- 卡片 -->
      <div class="card">
        <div class="count">
          <p class="title">
            <span @click="isShow=true" :class="isShow== true ? 'active': ''">用户注册</span>
            <span  @click="isShow=false;auth_time = 0" :class="isShow == false ? 'active': ''"> 用户登录 </span>
          </p>
          <div class="register" v-if="isShow">
            <el-form  label-width="110px" class="demo-ruleForm" :model="ruleForm" :rules="rules" ref="ruleForm" >
              <el-form-item label="手机号码:" prop="tel">
                <el-input placeholder="请输入手机号" v-model="ruleForm.tel"></el-input>
              </el-form-item>
              <!--             <el-gt></el-gt>-->
              <el-form-item label="验 证 码 :" prop="code">
                <el-input placeholder="请输入验证码" v-model="ruleForm.code" style="width: 215px;"></el-input>
                <send-code :mobile="ruleForm.tel"></send-code>
              </el-form-item>
              <el-form-item label="密 码 :" prop="pwd">
                <el-input placeholder="请输入密码" type="passWord" v-model="ruleForm.pwd" show-password></el-input>
<!--                <i class="newLook"><img src="./../../../assets/reg/ivew.png"> </i>-->
                <p class="el-form-item__error"  v-if="isTip== true">密码由6-25个字符，有字母，数字特殊符号组成</p>
              </el-form-item>
              <el-form-item label="确认密码:" prop="checkPass">
                <el-input placeholder="请确认密码" type="passWord"  v-model="ruleForm.checkPass" ></el-input>
              </el-form-item>
              <el-form-item label="联系qq:" prop="qq">
                <el-input placeholder="请输入联系qq" v-model="ruleForm.qq"></el-input>
              </el-form-item>
              <el-form-item label="邀 请 码：" prop="intweCode">
                <el-input placeholder="请输入邀请码" v-model="ruleForm.intweCode"></el-input>
              </el-form-item>
            </el-form>
            <p class="centerP">
              <el-checkbox v-model="checked">我已仔细阅读并同意接受《商家服务协议》</el-checkbox>
            </p>
            <div class="btn" @click="loginBtn('ruleForm')">
              <img src="./../../../assets/reg/btn.png">
            </div>
          </div>
          <logIn v-else></logIn>
        </div>
      </div>
    </div>
</template>

<script>
  import logIn from './../../../components/logIn'
  import  sendCode from './../../../components/authCode'
  export default {
    name: 'shopLogin',
    components:{logIn,sendCode},
    data () {
      // 判断手机号是否正确
      var checkPhone = (rule, value, callback) => {
        if (!value) {
          return callback(new Error('手机号不能为空'));
        } else {
          const reg = /^1[3|4|5|7|8][0-9]\d{8}$/
          console.log(reg.test(value));
          if (reg.test(value)) {
            callback();
          } else {
            return callback(new Error('请输入正确的手机号'));
          }
        }
      };
      // 判断密码是否正确
      var checkPwd = (rule, value, callback) => {
        if (!value) {
          this.isTip=false
          return callback(new Error(' 密码由6-25个字符，有字母，数字特殊符号组成'));
        }else {
          const regPwd = /^(?=.*[a-zA-Z])(?=.*\d)(?=.*[~!@#$%^&*()_+`\-={}:";'<>?,.\/]).{6,25}$/
          console.log(regPwd.test(value))
          if (regPwd.test(value)) {
            if (this.ruleForm.checkPass!== '') {
              this.$refs.ruleForm.validateField('checkPass');
            }
            callback();
          } else {
            this.isTip=false
            return callback(new Error('密码由6-25个字符，有字母，数字特殊符号组成'));
          }
        }
      };
      // 判断确认密码是否和第一次输入的一样
      var validatePass2 = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请再次输入密码'));
        } else if (value !== this.ruleForm.pwd) {
          callback(new Error('两次输入密码不一致!'));
        } else {
          callback();
        }
      };
      return {
        swiper:[
          'http://b-ssl.duitang.com/uploads/item/201707/05/20170705181254_ajZYC.jpeg'
        ],
        ruleForm: {
          tel: '',
          code: '',
          pwd: '',
          checkPass: '',
          qq: '',
          intweCode: ''
        },
        checked: true,
        isShow:true,
        isCode: true,
        sendAuthCode: true,
        auth_time: 0,
        isTip: true,
        rules:{
          tel:[
            { required: true,validator: checkPhone, trigger: 'blur'}
          ],
          code:[
            { required: true,message: '请输入验证码', trigger: 'blur' }
          ],
          pwd:[
            { required: true, validator: checkPwd, trigger: 'blur' }
          ],
          checkPass:[
            { required: true, validator: validatePass2, trigger: 'blur' }
          ],
          qq:[
            { required: true, message: '请输入qq', trigger: 'blur' }
          ]

        }
      }
    },
    mounted () {
    },
    methods: {
       // 商家注册
       loginBtn(ruleForm){
         if (this.checked == false){
           this.$message({
             message: '请先同意注册协议',
             type: 'error'
           })
         }else {
           this.$refs[ruleForm].validate((valid) =>{
             let that = this
             if (valid) {
               that.$http.post('/merchant/login/regist' ,{
                 mobile :that.ruleForm.tel,
                 code: that.ruleForm.code,
                 pass: that.ruleForm.pwd,
                 repeatPass: that.ruleForm.checkPass,
                 qq:that.ruleForm.qq,
                 invite_code:that.ruleForm.intweCode
               }).then(function (res){
                 console.log(res)
                 if(res.code == 1){
                   that.$message({
                     message:res.message,
                     showClose: true,
                     type: 'success',
                     onClose:function () {
                       that.isShow = false
                     }
                   })
                 }else if(res.code == 2) {
                   that.$message({
                     message:res.message,
                     showClose: true,
                     type: 'error'
                   })
                 }
               })
             }else {
               console.log('error submit!!');
               return false;
             }
           })
         }
      }
    }
  }
</script>

<style scoped>
  .card {
    position: absolute;
    width: 600px;
    height: 880px;
    top: 90px;
    right: 385px;
    background: url('./../../../assets/reg/login.png') no-repeat;
    background-size: 100%;
    z-index: 100;
  }
  .count {
    width: 80%;
    margin: 0 auto;
    margin-top: 100px;
  }
  .title{
    width: 70%;
    margin:0 auto;
    display: flex;
    display: -webkit-flex;
  }
  .title span{
    display: inline-block;
    flex:1 ;
    -webkit-flex: 1;
    cursor: pointer;
    text-align: center;
    font-size: 22px;
    line-height: 21px;
    color: #333;

  }
  .title span:nth-of-type(1){
    border-right: 2px solid #666;
  }
  .newLook{
    position: absolute;
    top:5px;
    right: 50px;
    cursor: pointer;
  }
  .demo-ruleForm{
    margin-top: 40px;
    position: relative;
    z-index: 110;
  }
  .centerP {
    text-align: center;
  }
  .btn,.loginBtn{
    width: 450px;
    height: 60px;
    margin: 0 auto;
    margin-top: 55px;
    cursor: pointer;
  }
  .btn img,.loginBtn img {
    display: block;
    width: 100%;
  }
  .el-input  {
    width: 90%;
  }
  .title span.active {
    color:#f28b1d !important;
  }
  .el-form-item__error{
    font-size: 12px;
    color:#CCCCCC !important;
  }
</style>

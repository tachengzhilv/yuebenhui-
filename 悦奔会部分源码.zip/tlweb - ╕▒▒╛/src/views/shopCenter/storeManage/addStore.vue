<template>
    <div class="addStore">
        <h3>店铺管理</h3>
        <div class="newStore">
          <p class="shops">绑定新店铺</p>
          <i class="tip">请仔细核对店铺信息，一经提交，无法修改</i>
          <div class="main-count">
            <el-form :model="ruleForm" :rules="rules" ref="ruleForm"   label-width="120px">
              <el-form-item label="选择平台:" prop="radio">
                  <el-radio v-model="ruleForm.radio" label="1">天猫</el-radio>
                  <el-radio v-model="ruleForm.radio" label="5">淘宝</el-radio>
              </el-form-item>
              <el-form-item label="店铺地址:" prop="address">
                <el-input v-model="ruleForm.address" @change="getAddress"></el-input>
              </el-form-item>
              <el-form-item label="店铺名称:">
                <el-input v-model="shopName" :disabled="true"></el-input>
              </el-form-item>
              <el-form-item label="店铺客服:" >
                <el-input v-model="shopService" :disabled="true"></el-input>
              </el-form-item>
              <el-form-item label="卖家中心截图:" prop="imageUrl">
                <el-upload
                  class="avatar-uploader"
                  action="http://upload-z2.qiniup.com"
                  :data="qn"
                  :show-file-list="false"
                  :on-success="handleAvatarSuccess"
                  :before-upload="beforeAvatarUpload">
                  <img v-if="ruleForm.imageUrl" :src="ruleForm.imageUrl" class="avatar">
                  <i v-else class="el-icon-plus avatar-uploader-icon">
                    <p class="uploadTip">上传照片</p>
                  </i>
                </el-upload>
                <p class="lookdemo" @click="dialogVisible = true">点击查看案例</p>
              </el-form-item>
              <el-form-item label="负责人微信:" prop="WeChat">
                <el-input v-model="ruleForm.WeChat"></el-input>

              </el-form-item>
              <el-form-item label="负责人QQ:" prop="qq">
                <el-input v-model="ruleForm.qq"></el-input>
                <p class="el-form-item__error" v-if="isTip==true">为避免用户在旺旺上直接联系商家，请填写一个可及时与店铺联系的QQ</p>
              </el-form-item>
              <el-form-item label="负责人手机号:" prop="tel">
                <el-input v-model="ruleForm.tel" ></el-input>
              </el-form-item>
              <div class="addSub" @click="addSub('ruleForm')">
                <img src="./../../../assets/webIndex/sub.png" v-if="isShow== true">
                <img src="./../../../assets/webIndex/disable.png" v-else>
              </div>
            </el-form>
          </div>
        </div>
      <el-dialog
        title="查看示例图"
        :visible.sync="dialogVisible"
        width="42%"
        :before-close="handleClose">
        <img src="./../../../assets/webIndex/demo.png">
      </el-dialog>
      <div class="success" v-if="isSuccess == false">
        <div class="pwdRight">
          <img src="./../../../assets/reg/success.png">
          <p>绑定成功，正在跳转中...</p>
        </div>
      </div>
    </div>
</template>

<script>
    export default {
        name: "addStore",
        data() {
          // 判断手机号是否正确
          var checkPhone = (rule, value, callback) => {
            if (!value) {
              return callback(new Error('手机号不能为空'));
            } else {
              const reg = /^1[3|4|5|7|8][0-9]\d{8}$/
              console.log(reg.test(value));
              if (reg.test(value)) {
                callback();
              } else {
                return callback(new Error('请输入正确的手机号'));
              }
            }
          };
            return {
              ruleForm:{
                radio: "1",
                address: '',
                imageUrl: '',
                WeChat: '',
                qq: '',
                tel: ''
              },
              qn:{
                token: ''
              },
              isShow: true,
              imageDataUrl: '',
              isTip: true,
              isSuccess: true,
              shopName: '',
              shopService: '',
              dialogVisible: false,
              rules:{
                radio: [
                  { required: true, message: '请选择平台', trigger: 'change' }
                ],
                address: [
                  { required: true, message: '请填写店铺地址', trigger: 'blur' }
                ],
                WeChat: [
                  { required: true, message: '请填写负责人微信', trigger: 'blur' }
                ],
                qq: [
                  {required: true, message: '请填写负责人qq', trigger: 'blur'}
                ],
                tel: [
                  {required: true, validator: checkPhone, message: '请填写负责人手机号', trigger: 'blur' }
                ],
                imageUrl: [
                  { required: true, message: '请上传图片', trigger: 'change' }
                ],
              }
            }
        },
         mounted(){
            let  shopNum = sessionStorage.getItem('shopNum');
            if(shopNum ==3) {
              this.isShow = false
                this.$message({
                  message:'您的店铺已经绑定超过三个了。',
                  showClose: true,
                  type: 'error'
                })
            }else{
              this.isShow = true
              this.getQiniuToken();
            }

         },
        methods: {
          /****上传图片****/
          handleAvatarSuccess(res, file) {
            this.ruleForm.imageUrl = URL.createObjectURL(file.raw);
            this.param = new FormData();
            this.param.append('file', file, file.name);
            this.imageDataUrl = "http://pqi8u88r7.bkt.clouddn.com/"+res.key  //上传图片的路径
            console.log(this.imageDataUrl)
            return false;
          },
          beforeAvatarUpload(file) {

          },
          /***  输入地址获取店铺信息  ***/
          getAddress(){
            console.log(sessionStorage.getItem('userTel'));
            console.log(this.ruleForm.address)
            this.$http.post('/apicreep/getShopUrl', {url:this.ruleForm.address}).then((res)=>{
              console.log(res , '获取数据')
              if (res.code == 1) {
                this.shopName = res.datas.vendorName
                this.shopService = res.datas.wangName
              }
            }).then((err)=>{
              console.log(err)
            })
          },
          //获取上传图片的token
          getQiniuToken() {
            this.$http.post("/common/getQiNiuPicToken")
              .then(response => {
                if (response.code == 1) {
                  this.qn.token=response.datas;
                }

              })
              .catch(error => {
                console.log(error)
              });
          },
          /*******查看案例图********/
          handleClose() {
            this.dialogVisible = false
          },
          /******提交数据*********/
          addSub (ruleForm){
            this.$refs[ruleForm].validate((valid) => {
              if (valid) {
                let that = this;
                let radios = this.ruleForm.radio;
                console.log(radios)
                that.$http.post('/merchant/shop/saveShop',{
                  platform_id: radios,
                  shop_url: that.ruleForm.address,
                  shop_name: that.shopName,
                  shop_service: that.shopService,
                  shop_core_url: that.imageDataUrl,
                  shop_wx: that.ruleForm.WeChat,
                  shop_qq : that.ruleForm.qq,
                  shop_mobile: that.ruleForm.tel,
                  merchant_id:sessionStorage.getItem('id')
                }).then((res) =>{
                    console.log(res)
                    this.isSuccess=true
                  if (res.code== 1) {
                     that.$message({
                       message:res.message,
                       showClose: true,
                       type: 'success',
                       onClose:function () {
                         that.$router.push({path:'/storeList'})

                       }
                     })
                  }else {
                    that.$message({
                      message:res.message,
                      showClose: true,
                      type: 'error'
                    })
                  }
                })
              } else {
                this.isTip = false
                console.log('error submit!!');
                return false;
              }
            });
          },

        }
    }
</script>

<style scoped>
.addStore h3{
  font-size: 24px;
  color: #333333;
  margin-top: 46px;
  margin-left: 17px;
}
.newStore{
  width: 100%;
}
.shops {
  margin-top: 40px;
  font-size:20px;
  text-align: center;
  color: #333333;
}
.tip {
  text-align: center;
  font-size: 14px;
  line-height: 21px;
  color: #f28b1d;
  display: block;
  margin-top: 12px;
}
.main-count {
  width: 630px;
  margin: 50px auto;
}
.main-count p i{
  margin-right:27px ;
}

.avatar-uploader .el-upload:hover {
  border-color: #409EFF;
}
.avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  margin-top: 50px;
  /*width: 178px;*/
  /*height: 178px;*/
  /*line-height: 178px;*/
  text-align: center;
}
.avatar {
  width: 140px;
  height: 140px;
  display: block;
}
.uploadTip {
  font-size: 14px;
  margin-top: 20px;
  color: #666666;
}
.lookdemo {
  font-size: 14px;
  color: #cccccc;
  cursor: pointer;
}
.addSub img{
  display: block;
  margin: 20px auto;
  cursor: pointer;
}

.success{
  position: relative;
  z-index: 11;
  display: flex;
  display: -webkit-flex;
  justify-content:center;
  top: 45%;
}
.pwdRight{
  width: 220px;
  height: 220px;
  border-radius:10px;
  background: rgba(0,0,0,0.5);

}
.pwdRight img{
  width: 100px;
  height: 80px;
  margin: 45px 60px ;
}
.pwdRight p{
  color:#ffffff;
  font-size: 16px;
  line-height: 21px;
  text-align: center;
}
</style>

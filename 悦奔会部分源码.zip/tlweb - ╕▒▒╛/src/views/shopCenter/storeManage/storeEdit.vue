<template>
    <div class="storeedit">
      <h3>店铺管理</h3>
      <div class="editMain">
        <p class="shops" v-if="isShow">修改店铺信息</p>
        <p class="shops" v-else>绑定新店铺</p>
        <i class="tip" v-if="isShow">请仔细核对店铺信息，一经提交，无法修改</i>
        <div class="main-count">
          <p class="refuse" v-if="isShow== false">{{shopInfo.status_show}}</p>
          <div class="el-form" v-if="isShow">
            <p>
              <label class="el-form-item__label">平台：</label>
              <span v-if="shopInfo.platform_id == '1'">淘宝</span>
              <span v-else>天猫</span>
            </p>
            <p>
              <label class="el-form-item__label">店铺地址：</label>
              <span style="width:500px;overflow:hidden;text-overflow:ellipsis;"><nobr>{{shopInfo.shop_url}}</nobr></span>
            </p>
            <p>
              <label class="el-form-item__label">店铺名称：</label>
              <span>{{shopInfo.shop_name}}</span>
            </p>
            <p>
              <label class="el-form-item__label">店铺客服号：</label>
              <span>{{shopInfo.shop_service}}</span>
            </p>
            <p style="width: 300px;height: 200px;">
              <label class="el-form-item__label">卖家中心截图：<img :src="shopInfo.shop_core_url" style="margin-top: -30px;margin-left: 120px;"></label>
            </p>
            <p>
              <label class="el-form-item__label">状态：</label>
              <span v-if="shopInfo.shop_status == 13" style="color: #60cb09">
                  已绑定
              </span>
              <span v-if="shopInfo.shop_status == 16" style="color: #f28b1d">
                  审核中
              </span>
              <span v-if="shopInfo.shop_status == 17" style="color: #f21d1d">
                  已拒绝
              </span>
            </p>
            <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="120px" >
              <el-form-item label="负责人微信:" prop="WeChat">
                <el-input v-model="ruleForm.WeChat"></el-input>
              </el-form-item>
              <el-form-item label="负责人QQ:" prop="qq">
                <el-input v-model="ruleForm.qq"></el-input>
                <p class="el-form-item__error" v-if="isTip==true">为避免用户在旺旺上直接联系商家，请填写一个可及时与店铺联系的QQ</p>
              </el-form-item>
              <el-form-item label="负责人手机号:" prop="tel">
                <el-input v-model="ruleForm.tel" ></el-input>
              </el-form-item>
              <div class="addSub" @click="addSub('ruleForm')">
                <img src="./../../../assets/webIndex/sub.png">
              </div>
            </el-form>
          </div>
          <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="120px" v-else>
            <el-form-item label="选择平台:" prop="radio">
              <el-radio-group v-model="ruleForm.radio">
                <el-radio :label="1">天猫</el-radio>
                <el-radio :label="5">淘宝</el-radio>
              </el-radio-group>
            </el-form-item>
            <el-form-item label="店铺地址:" prop="address">
              <el-input v-model="ruleForm.address" @change="getAddress"></el-input>
            </el-form-item>
            <el-form-item label="店铺名称:">
              <el-input v-model="shopName" :disabled="true"></el-input>
            </el-form-item>
            <el-form-item label="店铺客服:" >
              <el-input v-model="shopService" :disabled="true"></el-input>
            </el-form-item>
            <el-form-item label="卖家中心截图:" prop="imageUrl">
              <img :src="shop_core_url" class="oldPic">
              <el-upload
                class="upload-demo"
                :show-file-list="false"
                action="http://upload-z2.qiniup.com"
                :data="qn"
                :on-success="handleAvatarSuccess"
                :on-preview="handlePreview"
                :on-remove="handleRemove"
                >
                <el-button size="small">重新上传</el-button>
              </el-upload>
              <p class="lookdemo" @click="dialogVisible = true">点击查看案例</p>
            </el-form-item>
            <div class="el-form-item">
                <label class="el-form-item__label">状态:</label>
                <span class="reject">已拒绝</span>
            </div>
            <el-form-item label="负责人微信:" prop="WeChat">
              <el-input v-model="ruleForm.WeChat"></el-input>
            </el-form-item>
            <el-form-item label="负责人QQ:" prop="qq">
              <el-input v-model="ruleForm.qq"></el-input>
              <p class="el-form-item__error" v-if="isTip==true">为避免用户在旺旺上直接联系商家，请填写一个可及时与店铺联系的QQ</p>
            </el-form-item>
            <el-form-item label="负责人手机号:" prop="tel">
              <el-input v-model="ruleForm.tel" ></el-input>
            </el-form-item>
            <div class="addSub" @click="addSub('ruleForm')">
              <img src="./../../../assets/webIndex/sub.png">
            </div>
          </el-form>
        </div>
      </div>
      <el-dialog
        title="查看示例图"
        :visible.sync="dialogVisible"
        width="50%"
        :before-close="handleClose">
        <img src="./../../../assets/webIndex/demo.png">
      </el-dialog>
      <div class="success" v-if="isSuccess == false">
        <div class="pwdRight">
          <img src="./../../../assets/reg/success.png">
          <p>修改成功，正在跳转中...</p>
        </div>
      </div>
    </div>
</template>

<script>
import ElSlPanel from "element-ui/packages/color-picker/src/components/sv-panel";
export default {
  name: "storeEdit",
  components: {ElSlPanel},
  data() {
    return {
          ruleForm:{
            radio: '1',
            address: '',
            imageUrl: '',
            WeChat: '',
            qq: '',
            tel: ''
          },
          qn:{
            token: ''
          },
          isTip: true,
          isShow: true,
          shopName: '',
          shopService: '',
          dialogVisible: false,
          isSuccess: true,
          status : '',
          shopInfo:{},
          platform_id: '',
          imageDataUrl :'',
          shop_core_url:'',
          rules:{
            radio: [
              { required: true, message: '请选择平台', trigger: 'change' }
            ],
            address: [
              { required: true, message: '请填写店铺地址', trigger: 'blur' }
            ],
            WeChat: [
              { required: true, message: '请填写负责人微信', trigger: 'blur' }
            ],
            qq: [
              { required: true, message: '请填写负责人qq', trigger: 'blur'}
            ],
            tel: [
              { required: true, message: '请填写负责人手机号', trigger: 'blur' }
            ],
            imageUrl: [
              { required: true, message: '请上传图片', trigger: 'change' }
            ],
          }
        }
  },
  mounted(){
    this.status = this.$route.query.id;
    console.log(this.status)
    if (this.status == 17) {
      this.isShow = false
    } else {
      this.isShow = true
    }
    this. getList();
    this.getQiniuToken();
  },
  methods: {
    getList(){
      let id = this.$route.query.status
      console.log(id)
      this.$http.post('/merchant/shop/selectShopByUrl',{
        id:  id
      }).then((res) =>{
        console.log(res)
        if (res.code == 1){
          this.shopInfo = res.datas;
          this.ruleForm.WeChat =  this.shopInfo.shop_wx
          this.ruleForm.qq =  this.shopInfo.shop_qq
          this.ruleForm.tel =  this.shopInfo.shop_mobile
          this.platform_id = this.shopInfo.platform_id
          this.ruleForm.imageUrl = this.shopInfo.shop_core_url
          this.ruleForm.radio = this.shopInfo.platform_id;
          this.ruleForm.address = this.shopInfo.shop_url;
          this.shopName =  this.shopInfo.shop_name;
          this.shopService =  this.shopInfo.shop_service;
          this.shop_service =  this.shopInfo.shop_service;
          this.shop_core_url = this.shopInfo.shop_core_url;  // 已拒绝时获取图片的url
        } else if (res.code == 2) {
          this.$message({
            message: res.message,
            type: 'error'
          })
        }
      })
    },
    // 上传图片
    handleAvatarSuccess(res, file) {
      this.ruleForm.imageUrl = URL.createObjectURL(file.raw);
      this.param = new FormData();
      this.param.append('file', file, file.name);
      this.imageDataUrl = "http://pqi8u88r7.bkt.clouddn.com/"+res.key  //上传图片的路径
      this.shop_core_url = this.imageDataUrl
      console.log(this.shop_core_url)
      return false;
    },
    handleRemove(file, fileList) {
      console.log(file, fileList);
    },
    handlePreview(file) {
      console.log(file);
    },
    //获取上传图片的token
    getQiniuToken() {
      this.$http.post("/common/getQiNiuPicToken")
        .then(response => {
          if (response.code == 1) {
            this.qn.token=response.datas;
          }
        })
        .catch(error => {
          console.log(error)
        });
    },
      /***  输入地址获取店铺信息  ***/
      getAddress(){
        console.log(sessionStorage.getItem('userTel'));
        console.log(this.ruleForm.address)
        this.$http.post('/apicreep/getShopUrl', {shop_url:this.ruleForm.address}).then((res)=>{
          console.log(res , '获取数据')
          if (res.code == 1) {
            this.shopName = res.datas.shop_name
            this.shopService = res.datas.shop_service
          }
        }).then((err)=>{
          console.log(err)
        })
      },
      /*******查看案例图********/
      handleClose(done) {
        this.dialogVisible = false
      },
      /******提交数据*********/
      addSub (ruleForm){
        let id = this.$route.query.status
        console.log(id)
        this.$refs[ruleForm].validate((valid) => {
          if (valid) {
               //判断是否是  已拒绝的 审核，
            if ( this.status == 13 || this.status == 16) {
              let that = this;
              that.$http.post('/merchant/shop/updateShopById',{
                platform_id:that.platform_id ,
                shop_url: that.ruleForm.address,
                shop_name: that.shopName,
                shop_service: that.shopService,
                shop_core_url: that.ruleForm.imageUrl,
                shop_wx: that.ruleForm.WeChat,
                shop_qq : that.ruleForm.qq,
                shop_mobile: that.ruleForm.tel,
                id: id,
                merchant_id: sessionStorage.getItem('id')
              }).then((res) =>{
                console.log(res)
                if (res.code == 1) {
                  that.isSuccess=true
                  that.$message({
                    type:'success',
                    message:res.message,
                    showClose: true,
                    onClose:function () {
                      that.$router.push({path: '/storeList'})
                    }
                  })
                }
              })
            }else {
              //判断是否是  已拒绝的 审核，
              let that = this;
              that.$http.post('/merchant/shop/updateShopById',{
                platform_id:that.ruleForm.radio ,
                shop_url: that.ruleForm.address,
                shop_name: that.shopName,
                shop_service: that.shopService,
                shop_core_url: that.shop_core_url,
                shop_wx: that.ruleForm.WeChat,
                shop_qq : that.ruleForm.qq,
                shop_mobile: that.ruleForm.tel,
                id: id,
                merchant_id: sessionStorage.getItem('id')
              }).then((res) =>{
                console.log(res)
                if (res.code == 1) {
                  that.isSuccess=true
                  that.$message({
                    type:'success',
                    message:res.message,
                    showClose: true,
                    onClose:function () {
                      that.$router.push({path: '/storeList'})
                    }
                  })
                }
              })
            }
          } else {
            this.isTip = false
            console.log('error submit!!');
            return false;
          }
        });
      },

    }

}
</script>

<style scoped>
  .storeedit h3{
    font-size: 24px;
    color: #333333;
    margin-top: 46px;
    margin-left: 17px;
  }

  .editMain{
    width: 100%;
  }
  .shops {
    margin-top: 40px;
    font-size:20px;
    text-align: center;
    color: #333333;
  }
  .tip {
    text-align: center;
    font-size: 14px;
    line-height: 21px;
    color: #f28b1d;
    display: block;
    margin-top: 12px;
  }
  .el-form{
    width:100% ;
  }
  .el-form p{
    display: block;
    height: 40px;
    /*line-height: 40px;*/
    clear: both;

  }
  .el-form p label{
    width: 125px;
    padding: 0 12px 0 0;
    box-sizing: border-box;
  }
  .el-form p span{
    display: inline-block;
    line-height: 40px;
    color: #666666;
    font-size: 14px;
  }
  .main-count {
    width: 630px;
    margin: 50px auto;
  }
  .main-count p i{
    margin-right:27px ;
  }

  .avatar-uploader .el-upload:hover {
    border-color: #409EFF;
  }
  .avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    margin-top: 50px;
    /*width: 178px;*/
    /*height: 178px;*/
    /*line-height: 178px;*/
    text-align: center;
  }
  .avatar {
    width: 178px;
    height: 178px;
    display: block;
  }
  .uploadTip {
    font-size: 14px;
    margin-top: 20px;
    color: #666666;
  }
  .lookdemo {
    font-size: 14px;
    color: #cccccc;
    cursor: pointer;
  }
  .addSub img{
    display: block;
    margin: 20px auto;
    cursor: pointer;
  }
  .refuse{
    line-height:21px;
    font-size: 16px;
    color: #f21d1d;
    width: 311px;
    margin-left: 36px;
    margin-bottom: 15px;
  }
  .el-form-item__label{
    width: 120px;
  }
  .reject{
    font-size:14px;
    color: #f21d1d;
    padding: 0 12px 0 0;
    line-height: 40px;
  }
  .oldPic{
    width: 301px;
    height: 201px;
    border-radius: 5px;
  }
  .upload-demo {
    display: inline-block;
    vertical-align: top;
  }
  .el-button--small{
    width: 100px;
    height: 50px;
    border-radius: 5px;
    font-size: 16px;
    margin-top: 70px;
    margin-left: 30px;


  }

  .success{
    position: relative;
    z-index: 11;
    display: flex;
    display: -webkit-flex;
    justify-content:center;
    top: 45%;
  }
  .pwdRight{
    width: 220px;
    height: 220px;
    border-radius:10px;
    background: rgba(0,0,0,0.5);

  }
  .pwdRight img{
    width: 100px;
    height: 80px;
    margin: 45px 60px ;
  }
  .pwdRight p{
    color:#ffffff;
    font-size: 16px;
    line-height: 21px;
    text-align: center;
  }
</style>

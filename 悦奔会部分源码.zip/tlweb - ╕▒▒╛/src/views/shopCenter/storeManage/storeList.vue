<template>
    <div class="headList">
      <h3>店铺管理</h3>
      <div class="storeList">
        <p class="shops">绑定列表</p>
        <i class="tip">最多同时绑定3个店铺</i>
        <div class="tabWidth">
          <el-table
            :data="tableData"
            stripe
            style="width:100%">
            <el-table-column
              prop="date"
              label="序号"
              align="center"
              width="80"
              type="index">
            </el-table-column>
            <el-table-column
              prop="shop_name"
              align="center"
              label="店铺名称">
            </el-table-column>
            <el-table-column
              prop="shop_service"
              align="center"
              label="店铺客服号">
            </el-table-column>
            <el-table-column
              prop="merchant_id"
              align="center"
              label="店铺类型">
              <template slot-scope="scope">
                <img src="./../../../assets/webIndex/tb.png" v-if="scope.row.platform_id== 1" class="imgTab"/>
                <img src="./../../../assets/webIndex/tm.png" v-else class="imgTab">
                {{scope.row.platform_id | stateParam}}
              </template>
            </el-table-column>
            <el-table-column
              prop="create_time"
              align="center"
              label="绑定时间">
              <template slot-scope="scope">
                <div v-if="scope.row.create_time"> {{scope.row.create_time}}</div>
                <div v-else>暂未绑定</div>
              </template>
            </el-table-column>
            <el-table-column
              prop="address"
              align="center"
              label="状态">
              <template slot-scope="scope">
                <div v-if="scope.row.shop_status==13" class="green">已绑定</div>
                <div v-if="scope.row.shop_status==16" class="org">审核中</div>
                <div v-if="scope.row.shop_status==17" class="red">已拒绝</div>
              </template>
            </el-table-column>
            <el-table-column
              prop="address"
              align="center"
              label="操作">
              <template slot-scope="scope">
                 <div v-if="scope.row.shop_status==17" class="cursor" @click="editStore(scope.row.shop_status,)">
                   重新提交
                 </div>
                <div v-else class="cursor" @click="editStore(scope.row.shop_status,scope.row.id)">
                   修改
                </div>
              </template>
            </el-table-column>
          </el-table>
        </div>
        <div class="addNewStore" v-if="isShow" @click="addStroe">
          <img src="./../../../assets/webIndex/newbtn.png">
        </div>
      </div>
    </div>
</template>

<script>
    export default {
        name: "storeList",
        data() {
            return {
              tableData: [],
              isShow: true
            }
        },
        mounted(){
          this.dataList()
        },
        methods: {
           dataList(){
             let  id = sessionStorage.getItem('id');
             console.log(id)
             this.$http.post('/merchant/shop/selectShopByMerchant',{
               merchant_id: id
             }).then((res)=>{
               let  that= this
                console.log(res)
               //判断绑定的店铺 是否超过3 个
               if(res.datas.length == 3){

                 that.isShow = false
               }else{
                 that.isShow = true
               }
               that.tableData  = res.datas
             })
           },
          // 点击按钮跳转到新增店铺
          addStroe(){
             this.$router.push({path: '/addStore'})
          },
          // 点击修改跳转到编辑页面 (需要传状态值过去)
          editStore(id,status) {
            this.$router.push({path:'/storeEdit' ,query:{id:id,status:status}})
          }

        },
        filters:{
          stateParam (str) {
            if (str == '1') {
              return '淘宝'
            }else if(str == '5') {
              return '天猫'
            }
          }
        }
    }
</script>

<style scoped>
.headList{
  font-size: 24px;
  color: #333333;
  margin-top: 46px;
  margin-left: 17px;
}
.storeList{
  width: 100%;
}
.shops {
  margin-top: 40px;
  font-size:20px;
  text-align: center;
  color: #333333;
}
.tip {
  text-align: center;
  font-size: 14px;
  line-height: 21px;
  color: #f28b1d;
  display: block;
  margin-top: 12px;
}
.tabWidth{
  width: 790px;
  margin: 45px auto;
}
.tabWidth{
  border: 1px solid #ffe9d4;
  border-radius: 2px;
}
.tabWidth .el-table::before{
  background-color: initial;
}
.addNewStore img{
  display: block;
  margin: 60px auto;
  cursor: pointer;
}

.imgTab{
  vertical-align: sub;
}
.org{
  color: #f28b1d;
}
.green {
  color: #60cb09;
}
.red {
  color: #f21d1d;

}
.cursor{
  cursor: pointer;
}
</style>
